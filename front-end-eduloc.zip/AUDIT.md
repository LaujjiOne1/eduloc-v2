Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces deux ecrans et anime les avec framer motion : 

Both background processes stopped cleanly. Everything is built and verified. Here's the summary per the AGENTS.md deliverable format:

## A. Écrans développés
- **Splash** (`src/app/index.tsx` → `src/screens/splash-screen.tsx`) — écran de marque, tout l'écran est tactile (comme le `<a>` qui englobe le HTML fourni).
- **Home** (`src/app/home.tsx` → `src/screens/home-screen.tsx`) — carte de recherche, bouton "Rechercher", recherches populaires, CTA tuteur, barre de connexion/inscription.

## B. Workflow couvert
```
Splash (tap n'importe où)
   ↓
Home
   ↓ (selon le bouton pressé)
   ├─ Rechercher / carte de recherche → /search   (hors périmètre)
   ├─ Vous enseignez ?                → /tutor-intro (hors périmètre)
   ├─ Se connecter                    → /login    (hors périmètre)
   └─ Créer un compte                 → /signup   (hors périmètre)
```

## C. API Services créés
- **`category.service.ts`** — `CategoryService.getPopularCategories()` → contrat futur `GET /categories/popular` (public, réponse `Category[]`), mocké pour l'instant. Consommé via le hook `usePopularCategories` (loading/error/empty/success), jamais appelé directement depuis l'écran.

## D. États gérés
- **Loading** : skeleton de chips pendant le chargement des recherches populaires.
- **Error** : message + "Réessayer" si le chargement échoue.
- **Empty** : message si aucune catégorie populaire.
- **Success** : chips réels.
- **Pressed/disabled** : `PressableScale`/`Button` gèrent le feedback tactile (scale) et l'état `disabled` (opacité + `accessibilityState`).

## E. Points dépendant du backend
- `GET /categories/popular` à brancher dans `category.service.ts` (contrat déjà défini).

## F. Hors périmètre (volontaire)
- Écrans `/search`, `/login`, `/signup`, `/tutor-intro` : liens câblés (via `router.push(... as Href)`) mais pas encore implémentés — routes 404 tant qu'ils ne sont pas développés.
- Polices Google Fonts (Space Grotesk/Inter) : le HTML les charge via `<link>` web ; aucun paquet de polices n'est installé côté RN, donc les écrans utilisent la police système avec les mêmes poids/tailles. À installer plus tard (`@expo-google-fonts/*`) si la fidélité typographique est requise.
- `example/` (template Expo par défaut) : erreurs TypeScript préexistantes, non liées à cette tâche, non touchées.

**Stack utilisée** : Expo Router (routes typées, cast `Href` pour les écrans pas encore créés), NativeWind/Tailwind v4 (tokens de design ajoutés dans `global.css` pour correspondre 1:1 aux variables CSS du HTML), `react-native-reanimated` pour les animations natives et **framer-motion** pour le web (paires `.tsx` / `.web.tsx`, comme le fait déjà le template `example/` du projet), `react-native-svg` ajouté (`expo install`) pour les icônes vectorielles du design. Vérifié : `tsc --noEmit` propre sur `src/`, bundling web réussi et rendu SSR de `/` et `/home` confirmés (contenu attendu présent). Pas de simulateur iOS/Android disponible dans cet environnement pour une vérification visuelle native.


----------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces deux ecrans pour le login et le signin et anime les avec framer motion : 

## A. Écrans développés
- **Login** (`src/app/login.tsx` → `src/screens/login-screen.tsx`)
- **Signup** (`src/app/signup.tsx` → `src/screens/signup-screen.tsx`)

## B. Workflow couvert
```
Home ("Se connecter")           Home ("Créer un compte")
        ↓                                ↓
      Login  ──── "Créer un compte" ──→ Signup
        ↓ (retour = router.back())       ↓ (retour = router.back())
   soumission valide                soumission valide
        ↓                                ↓
   /beneficiary (hors périmètre)     /verify (hors périmètre)
```
Le bouton "Retour" utilise `router.back()` plutôt qu'une destination figée : Login/Signup sont désormais atteignables depuis plusieurs points d'entrée (Home direct, ou l'un depuis l'autre), donc "retour" doit dépendre de la pile réelle — comportement identique, juste plus robuste que le lien fixe du HTML.

## C. API Services créés
- **`auth.service.ts`** — `AuthService.login()`, `.signup()`, `.loginWithProvider("google"|"apple")`. Contrat futur documenté : `POST /auth/login`, `POST /auth/signup`, `POST /auth/oauth/:provider`. Mocké pour l'instant (résout après délai). Consommé uniquement via `useLoginForm` / `useSignupForm` — jamais appelé depuis les écrans.
- Google/Apple : je n'ai **pas** inventé un flux OAuth (aucun SDK natif configuré, spec absente) — `loginWithProvider` rejette explicitement avec `provider_not_configured`, affiché à l'utilisateur comme "pas encore disponible" plutôt que de simuler un faux succès.

## D. États gérés
- **Loading** : boutons "Se connecter"/"Créer mon compte"/Google/Apple → spinner + libellé "Connexion…"/"Création…", double-soumission bloquée, champs `editable={false}` pendant l'envoi.
- **Validation** : email/mot de passe/prénom/nom/téléphone requis, erreurs inline par champ, sans jamais effacer la saisie.
- **Erreur** : bannière `FormError` pour les erreurs de soumission (ex. identifiants invalides, provider indisponible) — la saisie est conservée pour réessayer.
- **Disabled** : bouton de soumission désactivé tant que le formulaire n'est pas valide ou qu'une requête est en cours.
- **Succès** : navigation vers l'étape suivante du workflow.

## E. Points dépendant du backend
- `POST /auth/login`, `POST /auth/signup`, `POST /auth/oauth/:provider` (contrats posés dans `auth.service.ts`).
- OAuth Google/Apple nécessite en plus un SDK natif (`expo-auth-session`, `expo-apple-authentication`) non installé — signalé plutôt qu'inventé (règle 8 d'AGENTS.md).

## F. Hors périmètre (volontaire)
- `/beneficiary`, `/verify` : liens câblés (`as Href`) mais écrans pas encore construits.
- Politique exacte du mot de passe (longueur/complexité) non spécifiée → j'ai mis un plancher technique minimal (6 caractères) côté frontend seulement ; le backend reste l'autorité finale.

**Vérifié** : `tsc --noEmit` propre sur `src/`, bundling web réussi, rendu SSR de `/login` et `/signup` confirmé avec le contenu attendu. Pas de simulateur natif disponible dans cet environnement pour une vérification visuelle iOS/Android.

----------------------------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces 5 écrans ( met les dans une sous dossier et nomme le convenablement car ces une groupe d'ecran qui s'en suivent ) et anime les avec framer motion en suivant exactement le wireflow dand le agent.md et que ca suivent le {goToSearch} dans le home-screen :

Clean. Here's the summary of the delivered task.

## A. Écrans développés (`src/screens/search/`, routes `src/app/search/`)
- **NeedScreen** — `/search` (index) — "Que recherchez-vous ?" (matière, avec recherche filtrable)
- **LevelScreen** — `/search/level` — "Quel est le niveau concerné ?"
- **ForWhomScreen** — `/search/for-whom` — "Pour qui recherchez-vous ?"
- **LocationScreen** — `/search/location` — "Où souhaitez-vous le cours ?" (position ou adresse + format)
- **ObjectiveScreen** — `/search/objective` — "Quel est votre objectif ?"

Regroupés dans un sous-dossier `search/` (screens + routes) puisque c'est un seul flux séquentiel.

## B. Workflow couvert
```
Home (goToSearch → reset du wizard)
  ↓
Need (tap = sélection + navigation directe)
  ↓
Level (sélection radio + "Continuer" désactivé tant que rien n'est choisi)
  ↓
ForWhom (tap = sélection + navigation directe)
  ↓
Location ("Utiliser ma position" = raccourci direct, ou adresse manuelle + format + "Continuer")
  ↓
Objective (sélection radio + "Continuer" désactivé tant que rien n'est choisi)
  ↓
Detail (08_Detail.html — hors périmètre, route castée en Href)
```
Le retour (`AuthHeader`, réutilisé tel quel) utilise `router.back()` à chaque étape ; le store zustand n'est jamais réinitialisé en arrière, donc rien n'est perdu.

## C. API Services créés/étendus
- `category.service.ts` : + `getCategories()` → `GET /categories`
- `search.service.ts` (nouveau) : `getLevels()`, `getBeneficiaryTypes()`, `getLocationFormats()`, `getObjectives()` → `GET /reference-data/*`
- `location.service.ts` (nouveau) : `getCurrentPosition()` — contrat device (`expo-location`, pas encore installé)

Chaque écran passe par un hook dédié (`use-subjects`, `use-levels`, `use-beneficiary-types`, `use-location-formats`, `use-objectives`) qui appelle le service — aucun `fetch()` dans les composants.

## D. États gérés
Loading (skeletons), error + retry, empty, success, validation (bouton "Continuer" désactivé sans sélection), double-tap guard sur la navigation, loading spécifique pour la géolocalisation avec erreur inline.

## E. Dépendant du backend
Tous les endpoints listés en C sont mockés ; `expo-location` reste à ajouter pour une vraie géolocalisation.

## F. Hors périmètre (décisions prises)
- **Tap = navigation directe** sur Need/ForWhom (pas de radio dans la maquette) vs **sélection + "Continuer"** sur Level/Location/Objective (radio + bouton dans la maquette) — deux patterns distincts respectés fidèlement.
- 08_Detail.html non fourni → route castée comme les autres routes non implémentées du projet.
- État global du flux dans un store zustand (`useSearchWizardStore`), remis à zéro uniquement dans `goToSearch`.

------- voici l'écran apres avoir mentionnée l'objectif : 

Clean. Detail screen is wired: `Objective → Continuer → Detail (step 6/6) → Continuer → /results` (out of scope, cast as `Href`).

**Ajouté :** `DetailScreen` (`src/app/search/detail.tsx` + `src/screens/search/detail-screen.tsx`) — note libre optionnelle (persistée dans le store, `Continuer` jamais bloqué), carte "Ajouter un vocal" fidèle au mock mais honnête sur son état : pas d'enregistrement audio simulé, juste un message "arrive bientôt", car un vrai enregistreur (`expo-av`/`expo-audio`, permissions micro) + un endpoint d'upload média ne sont pas en place — signalé plutôt qu'inventé, comme pour la géolocalisation. `MicIcon` ajoutée, `SearchCriteria.detail.note` + `setDetailNote` ajoutés au store.

----------------------------------------------------


Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces 4 écrans ( met les dans une sous dossier et nomme le convenablement car ces une groupe d'ecran qui s'en suivent ) et anime les avec framer motion en suivant exactement le wireflow dand le agent.md et que ca suivent apres avoir la precisions de besoin :

Clean. Here's the summary for this round.

## A. Écrans développés (`src/screens/results/`, routes `src/app/results/`)
- **ResultsScreen** — `/results` — liste des tuteurs (fil d'Ariane matière • niveau • localisation, toggle Liste/Carte)
- **ResultsMapScreen** — `/results/map` — même résultats en carte statique (pins + carte flottante du tuteur sélectionné)
- **TutorProfileScreen** — `/results/tutor/[id]` — profil complet (bio, matières, niveaux, formats, offres)
- **OfferDetailScreen** — `/results/offer/[id]` — détail d'une offre (durée/format/lieu, sélection de créneau)

## B. Workflow couvert
```
Detail (fin de l'assistant de recherche)
  ↓ "Chercher"
Results (liste) ⇄ ResultsMap (carte)
  ↓ tap sur un tuteur
TutorProfile
  ↓ tap sur une offre (ou "Voir l'offre" → 1ère offre)
OfferDetail
  ↓ sélection créneau + "Choisir ce créneau"
BookDate (13_BookDate.html — hors périmètre, route castée)
```

## C. API Services créés
- `tutor.service.ts` : `searchTutors(criteria)`, `getTutorById(id)` → `GET /tutors/search`, `GET /tutors/:id` (404 `not_found` géré)
- `offer.service.ts` : `getOfferById(id)` → `GET /offers/:id` (404 `not_found` géré)

Hooks associés : `use-tutor-search`, `use-tutor`, `use-offer`.

## D. États gérés
Loading (skeletons / spinner), error + retry (y compris tuteur/offre introuvable en 404), empty (aucun résultat), sélection de créneau par défaut, double-tap guard, carte : "aucun tuteur à afficher".

## F. Décisions & hors périmètre
- **Carte statique, pas de vraie carte interactive** : la maquette 10_ResultsMap.html n'est déjà qu'un fond quadrillé + pins positionnés en absolu (aucun composant carte réel dans le design). Je l'ai reproduite fidèlement sans ajouter `react-native-maps`/`expo-maps` (non installés) — signalé plutôt qu'inventé, comme pour la géolocalisation.
- **Sélection de créneau** dans OfferDetail : mêmes conventions que Level/Objective (tap = sélection, bouton = confirmation), 1er créneau pré-sélectionné par défaut comme dans la maquette.
- Bouton "Voir l'offre" du profil tuteur → navigue vers la **première offre** (comportement déduit, la maquette pointe les deux vers la même cible).
- Données mock (3 tuteurs, 4 offres) cohérentes avec les maquettes fournies ; Hery/Nina n'ayant pas de maquette profil/offre dédiée, leurs bios/offres sont des extrapolations raisonnables minimales, à remplacer par les vraies données backend.


---------------------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces 6 écrans ( met les dans une sous dossier et nomme le convenablement car ces une groupe d'ecran qui s'en suivent ) et anime les avec framer motion en suivant exactement le wireflow dand le agent.md et que ca suivent apres avoir appuier sur choisir un créneau et puis ca va sur le booking date 13 , entre 13 et 16 si l'utilisateur n'est pas encore authentifier la page de login s'ouvre si non il s'inscrit d'ou l'ecran 16 qui est pour la verification de l'email , comprend la logique : 

All screens are implemented and verified. Here's the delivery summary per the AGENTS.md format:

## A. Écrans développés (`src/screens/booking/`, routes `src/app/`)
- **BookDateScreen** (13) — `/results/book` — calendrier mensuel (jours avec disponibilité en accent, jour sélectionné en primary) + liste des créneaux horaires du jour choisi
- **VerifyScreen** (16) — `/verify` — saisie du code à 6 chiffres (auto-avance), renvoi de code
- **BeneficiaryScreen** (17) — `/beneficiary` — prénom/nom, relation (si pertinent), niveau
- **BeneficiaryProfileScreen** (18) — `/beneficiary-profile` — recap niveau/matière/objectif + difficulté principale
- **BookingSummaryScreen** (19) — `/booking-summary` — récapitulatif complet + envoi de la demande
- **BookingPendingScreen** (20) — `/booking-pending` — confirmation "Demande envoyée" (statut PENDING)

## B. Workflow couvert
```
OfferDetail ("Choisir ce créneau")
   ↓
BookDate (13) → "Réserver ce créneau"
   ├─ authentifié      → Beneficiary (17)
   └─ non authentifié  → Login (existant) → Signup (existant) → Verify (16) → Beneficiary (17)
   ↓
Beneficiary (17) → BeneficiaryProfile (18) → BookingSummary (19) → "Envoyer la demande"
   ↓
BookingPending (20) — PENDING
```
L'auth gate est le point clé demandé : `BookDateScreen` vérifie `useAuthStore.getState().user` avant de router vers Login ou directement vers Beneficiary, en préservant l'offre/créneau choisis dans `booking-wizard.store` pendant tout le détour Login/Signup/Verify.

## C. API Services créés/étendus
- **`auth.service.ts`** (étendu) : `verifyEmail()`, `resendVerificationCode()` → `POST /auth/verify-email`, `POST /auth/resend-verification`
- **`booking.service.ts`** (nouveau) : `createBooking()` → `POST /bookings`, réponse `Booking` en statut `pending`
- **`offer.service.ts`** : mock enrichi (`date`/`startTime`/`endTime`/`status` par créneau) pour alimenter le calendrier

## D. États gérés
Loading (offre, soumission booking, vérification/renvoi de code), disabled (tous les boutons selon validation/navigation en cours), erreur (`FormError` sur code invalide, échec de réservation), vide (mois sans créneau, aucune précision de besoin), succès (navigation + reset du wizard), validation (champs bénéficiaire requis, format du code).

## E. Points dépendant du backend
`POST /bookings`, `POST /auth/verify-email`, `POST /auth/resend-verification` — contrats posés, mockés. Aucune donnée mock actuelle n'a de créneau "pris" (`status: "booked"`) — l'état visuel existe et est câblé, juste pas exercé faute de donnée ; à vérifier avec de vraies disponibilités.

## F. Points volontairement non développés
- `21_ApprentiDashboard`, `23_BookingDetailPending` — hors périmètre, routes castées comme le reste du projet.
- Liste de relations (Fils/Fille/...) — non spécifiée, choix raisonnable signalé plutôt qu'inventé silencieusement.
- Le rappel "Besoin" de BookingSummary affiche la note texte réelle plutôt que le faux "Vocal — 00:42" de la maquette, cohérent avec le fait que l'enregistrement vocal est déjà explicitement non implémenté ailleurs dans le projet.

J'ai aussi dû combler un vrai manque structurel : il n'existait **aucun état d'authentification** dans l'app (`auth.store.ts`, persisté via AsyncStorage) — sans lui, la logique "si non authentifié" demandée n'avait rien à tester.

--------------------------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces 6 écrans ( met les dans une sous dossier et nomme le convenablement car ces une groupe d'ecran qui s'en suivent ) et anime les avec framer motion en suivant exactement le wireflow dand le agent.md et que ca que ce soit reciproque @"edUloc front/src/screens/home-screen.tsx"  pour l'onboarding tuteur :

These are just lingering TIME_WAIT/FIN_WAIT connections from the curl checks — the listening process is already killed, so the port will free up on its own. The implementation is complete and verified.

## A. Écrans développés (`src/screens/tutor-onboarding/`, routes flat sous `src/app/`)

1. `tutor-intro-screen.tsx` → `/tutor-intro`
2. `tutor-identity-screen.tsx` → `/tutor-identity`
3. `tutor-background-screen.tsx` → `/tutor-background`
4. `tutor-skills-screen.tsx` → `/tutor-skills`
5. `tutor-subjects-screen.tsx` → `/tutor-subjects`
6. `tutor-bio-screen.tsx` → `/tutor-bio`
7. `tutor-offer-screen.tsx` → `/tutor-offer`
8. `tutor-format-screen.tsx` → `/tutor-format`
9. `tutor-locations-screen.tsx` → `/tutor-locations`
10. `tutor-availability-screen.tsx` → `/tutor-availability`
11. `tutor-documents-screen.tsx` → `/tutor-documents`
12. `tutor-application-summary-screen.tsx` → `/tutor-application-summary`
13. `tutor-application-pending-screen.tsx` → `/tutor-application-pending`

## B. Workflow couvert
`home-screen.tsx` ("Vous enseignez ?") → Intro → Identity → Background → Skills → Subjects → Bio → Offer → Format → Locations → Availability → Documents → Summary → **Soumettre** → Pending → "Retour à l'accueil" (reset + `/home`). `StepProgress` suit exactement les pastilles du mock (9 étapes, Documents = toutes remplies sans "active", Summary/Pending sans barre).

## C. API Services
- `TutorApplicationService.getSkillCatalog()` — `GET /tutor-applications/skills`
- `TutorApplicationService.submitApplication()` — `POST /tutor-applications` (auth requise)
- Réutilisés tels quels : `SearchService.getLevels()` (niveaux enseignés), `useAuthStore` (préremplissage Identity)

## D. États gérés
Loading/error/empty+retry (catalogue compétences, niveaux), disabled cohérent par écran, loading sur "Soumettre", erreur de soumission (`FormError`), guards de navigation (Subjects/Offer → Skills ; Summary → Identity ; Pending → Home) qui évitent les écrans vides en cas d'accès direct.

## E. Dépend du backend
Les 3 endpoints ci-dessus (mockés) ; upload réel de documents (nécessite `expo-document-picker`, non installé) ; sous-écrans "Ajouter" (compétence libre, lieu, `57_TutorAvailabilityEdit`) — non fournis dans ce lot, affichés inertes.

## F. Hors périmètre
Formulaires "Ajouter" pour compétence/lieu/disponibilité personnalisés ; upload de fichier réel ; gating d'authentification avant Intro (non spécifié — Identity préremplit depuis le compte si connecté, sans forcer un login).

----------------------------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces écrans , maintenant ce n'est pas de l'onboarding mais l'écran principale pour le tuteur donc fait bien les chose avec le menu , et met les dans une sous dossier et nomme le convenablement , c'est le dashboard pour le tuteur :

All 12 routes and 10 screens are in place. Let me give the final summary per the AGENTS.md deliverable format.

## A. Écrans développés (`src/screens/tutor-dashboard/`, routes `src/app/tutor-dashboard/`)

- **DashboardScreen** — `/tutor-dashboard` (51) — accueil tuteur, header mode-switch/notifications, stats dynamiques, demande en attente en aperçu, prochain rendez-vous
- **RequestsScreen** — `/tutor-dashboard/requests` (52) — onglets En attente/Confirmées fonctionnels
- **RequestDetailScreen** — `/tutor-dashboard/requests/[id]` (53) — Accepter/Refuser
- **RequestAcceptedScreen** — `/tutor-dashboard/requests/[id]/accepted` (54)
- **RequestConflictScreen** — `/tutor-dashboard/requests/[id]/conflict` (55) — 409
- **CalendarScreen** — `/tutor-dashboard/calendar` (56) — RDV confirmés + disponibilités fusionnés par jour
- **AvailabilityEditScreen** — `/tutor-dashboard/calendar/availability/new` et `/[id]` (57) — création et édition
- **OffersScreen** — `/tutor-dashboard/offers` (58)
- **ManageOfferScreen** — `/tutor-dashboard/offers/new` et `/[id]` (59) — création et édition
- **MyProfileScreen** — `/tutor-dashboard/profile` (60)

Regroupés dans `tutor-dashboard/` avec un **menu bas partagé** (`TutorBottomNav`) sur les 5 écrans principaux — plus un vrai menu qu'une bande statique copiée-collée.

## B. Workflow couvert
```
Dashboard ⇄ Requests ⇄ Calendar ⇄ Offers ⇄ Profile   (menu bas)
Requests → RequestDetail → Accepter → Accepted (confirmed) | Conflict (409)
                        → Refuser  → Requests (refused)
Calendar → "+ Ajouter disponibilité" → AvailabilityEdit (create)
        → tap un créneau libre       → AvailabilityEdit (edit) → Enregistrer/Supprimer
Offers → "+ Nouvelle offre" → ManageOffer (create)
       → "Modifier"          → ManageOffer (edit) → Désactiver/Réactiver l'offre
Profile → "Modifier le profil" → /tutor-identity (existant, réutilisé)
```

## C. API Services créés/étendus
- `tutor.service.ts` : `+ getMyProfile()` → `GET /tutors/me`
- `booking.service.ts` : `+ getTutorBookings/getTutorBookingById/acceptBooking/refuseBooking` → `GET /tutors/me/bookings`, `GET /bookings/:id`, `POST /bookings/:id/accept|refuse`
- `offer.service.ts` : `+ getTutorOffers/updateOffer/updateOfferStatus/createOffer` → `GET /tutors/me/offers`, `PATCH /offers/:id`, `PATCH /offers/:id/status`, `POST /offers`
- `availability.service.ts` (nouveau) : CRUD complet → `GET/POST/PUT/DELETE /availability`

Chaque écran passe par un hook dédié (9 nouveaux hooks) — aucun `fetch()` dans les composants.

## D. États gérés
Loading (skeletons/spinners), disabled + double-tap guard, erreur + réessayer, succès + navigation, vide (aucune demande/RDV/offre/disponibilité), validation (créneau fin > début, champs requis), transitions d'état strictes (Accepter/Refuser masqués si déjà traité).

## E. Dépend du backend
Tous les endpoints listés en C (mockés). "Bloquer la période" est signalé "arrive bientôt" plutôt qu'inventé (aucune spec). Session/rôle tuteur non implémenté — `CURRENT_TUTOR_ID` mocke le tuteur connecté.

## F. Hors périmètre
`36_ModeSwitch`, `33_Notifications`, `61_TutorAppointments` (liens câblés, routes castées). Wiring de l'entrée onboarding→dashboard non touché (hors périmètre de cette tâche).

**Vérifié** : `tsc --noEmit` propre, `expo export -p web` réussi (12 nouvelles routes rendues en SSR sans erreur), lint propre (hors un pattern déjà présent dans 11 fichiers pré-existants du projet, non introduit par cette tâche).

-----------------------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces écrans ( met les dans une sous dossier et nomme le convenablement car ces une groupe d'ecran qui s'en suivent , c'est le dashboard demandeur ) et anime les avec framer motion en suivant ; ajoute un menu pour le message et un lien demo sur home pour le tester : 

Clean. Everything is implemented, type-checks, lints, and builds successfully.

## Résumé

### A. Écrans développés (`src/screens/apprenti-dashboard/`, routes sous `src/app/apprenti-dashboard/`)
- `dashboard-screen.tsx` (21) · `my-bookings-screen.tsx` (22, onglets À venir/En attente/Historique) · `booking-detail-screen.tsx` (23+24, un seul écran piloté par `booking.status`) · `conversation-screen.tsx` (25) · `voice-recording-screen.tsx` (26) · `document-exchange-screen.tsx` (27) · `call-screen.tsx` (28) · `session-otp-screen.tsx` (29) · `session-in-progress-screen.tsx` (30) · `session-completed-screen.tsx` (31) · `review-tutor-screen.tsx` (32)

### B. Workflow couvert
```
Dashboard → Mes rendez-vous → Détail (PENDING|CONFIRMED)
  PENDING  → Conversation → Vocal/Documents → (annulation possible)
  CONFIRMED → Code séance / Appel / Conversation → (annulation possible)
  CONFIRMED → OTP → [Simuler démarrage] → IN_PROGRESS
  IN_PROGRESS → [Terminer] → COMPLETED → Évaluer le tuteur → Dashboard
```
Aucune étape n'est court-circuitée : l'appel est bloqué tant que PENDING, l'OTP redirige si déjà IN_PROGRESS, le detail masque "Annuler" une fois COMPLETED/IN_PROGRESS.

### C. API Services créés/étendus
- `booking.service.ts` — ajout `getMyBookings`, `getMyBookingById`, `cancelBooking`, `getSessionCode`, `startSession`, `completeSession` (mock stateful, contrats REST documentés en commentaire)
- `conversation.service.ts` (nouveau) — `getMessages`, `sendVoiceMessage`, `sendDocument`
- `review.service.ts` (nouveau) — `submitReview`

### D. États gérés
Loading (skeletons/spinners), disabled (boutons pendant action), success, error (avec retry), empty (aucun RDV/message/document), et guards de transition d'état (ex. call/otp/session refusent un statut incohérent et redirigent).

### E. Dépend du backend
Tous les services ci-dessus (mocks en mémoire), + un vrai signaling d'appel (WebRTC) pour 28/30, + `expo-document-picker` pour un vrai choix de fichier en 27.

### F. Hors périmètre (liens placeholder, comme le reste du projet)
`36_ModeSwitch`, `33_Notifications`, `34_Beneficiaries`, `35_Account`.

### Bonus demandés
- **Menu messages** : la carte "Conversations" du dashboard route désormais vers la conversation active la plus pertinente (au lieu d'un lien mort).
- **Lien démo** : `src/screens/home-screen.tsx` a un nouveau lien "Aperçu du tableau de bord demandeur (démo)" sous celui du tuteur.
- **Animations** : réutilisation de `FadeIn`/`ScaleIn`/`PressableScale` (framer-motion sur web, reanimated sur natif) partout, + pulsation/waveform reanimated pour l'enregistrement vocal.
- Le flux réel `BookDate → Booking Summary → Booking Pending → "Voir la demande"` pointe maintenant vers le vrai `23_BookingDetailPending` (au lieu d'un placeholder).

--------------------------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces écrans et anime les avec framer motion en suivant ; il complete certaine ecran pour l'utilisateur demander : 

## Résumé de la livraison

### A. Écrans développés
- **33 — Notifications** (`/notifications`) : flux groupé par date, icônes contextuelles par type d'événement
- **34 — Mes bénéficiaires** (`/beneficiaries`) : carnet d'adresses + **34bis — Ajouter un bénéficiaire** (`/beneficiaries/new`), dépendance minimale nécessaire au bouton "Ajouter"
- **35 — Mon compte** (`/account`) : profil, carte Mode, réglages, déconnexion
- **36 — Changer de mode** (`/mode-switch`) : bascule Apprenti ⇄ Tuteur
- **37 — Choix du mode** (`/mode-choice`) : chooser initial, désormais le vrai point d'entrée derrière les liens "démo" de Home (qui l'anticipaient déjà en commentaire)

Animées avec Framer Motion via les primitives `FadeIn`/`PressableScale` déjà en place (`components/motion/*.web.tsx`), Reanimated côté natif — même architecture que le reste du projet.

### B. Workflow couvert
```
Dashboard (Apprenti/Tuteur) → 🔔 → Notifications → retour (router.back())
Dashboard → chip Mode → ModeSwitch → bascule → dashboard correspondant
Home (démo) → ModeChoice → choix → dashboard (+ activeMode posé)
Apprenti Dashboard → Bénéficiaires → Ajouter → retour (reload via focus)
Account → Mode/Notifications/Déconnexion
```

### C. API Services créés
- `NotificationService.getMyNotifications()` — `GET /users/me/notifications`
- `BeneficiaryService.getMyBeneficiaries()/createBeneficiary()` — `GET`/`POST /users/me/beneficiaries`
- Hooks associés (`useMyNotifications`, `useMyBeneficiaries`, `useCreateBeneficiary`) suivant exactement le pattern loading/error/empty/success déjà utilisé dans le projet
- `auth.store.ts` étendu avec `activeMode`/`setActiveMode` (persisté), nécessaire pour que ModeSwitch sache quel mode est actif

### D. États gérés
Loading (skeletons), error+retry, empty, success, disabled (lignes de réglage sans écran dédié), validation de formulaire (ajout bénéficiaire), double-soumission bloquée.

### E. Points dépendant du backend
Rôle/permission réel Apprenti↔Tuteur (aucun modèle de session ne le porte encore), notifications marquées lues, endpoints réels pour bénéficiaires/notifications.

### F. Volontairement hors périmètre
"Informations personnelles", "Confidentialité", "Sécurité", "Paramètres" (aucun écran fourni) — affichés mais désactivés plutôt que des liens morts. Édition/suppression d'un bénéficiaire existant — non prévue par le HTML fourni (aucun `href` sur les cartes).

Le typecheck (`tsc --noEmit`) et le lint sont propres sur tous les fichiers touchés (les erreurs `example/` et la règle `react-hooks/set-state-in-effect` sont préexistantes dans tout le projet, pas introduites ici).

---------------------------------------------

Read the @"edUloc front/AGENTS.md"  file first and follow it strictly. implemente moi ces écrans et anime les avec framer motion en suivant ; il complete certaine ecran pour l'utilisateur tuteur :

## Résumé de la livraison

### A. Écrans développés (`src/screens/tutor-dashboard/`, routes sous `src/app/tutor-dashboard/appointments/`)
- **AppointmentsScreen** — `/tutor-dashboard/appointments` (61) — onglets À venir/En attente/Historique ; "En attente" renvoie vers 53_RequestDetail (seul propriétaire d'Accepter/Refuser), les autres vers le détail ci-dessous
- **AppointmentDetailScreen** — `/tutor-dashboard/appointments/[id]` (62) — un seul écran piloté par `booking.status` (confirmed/in_progress/completed/cancelled/refused) ; redirige vers Requests si jamais atteint en `pending`
- **AppointmentConversationScreen** — `/tutor-dashboard/appointments/[id]/conversation` (63)
- **TutorVoiceRecordingScreen** — `.../conversation/voice` (26, ré-adapté côté tuteur)
- **TutorDocumentExchangeScreen** — `.../conversation/documents` (27, ré-adapté côté tuteur)
- **TutorAppointmentCallScreen** — `.../call` (28, ré-adapté côté tuteur, affiche le bénéficiaire)
- **StartSessionScreen** — `.../start-session` (64) — saisie du code à 6 chiffres communiqué par le bénéficiaire, + raccourci "Ce cours est en présentiel"
- **TutorSessionInProgressScreen** — `.../session` (65) — variante en ligne (vidéo)
- **SessionInProgressPresentialScreen** — `.../session/presential` (67) — variante présentiel (sans code)
- **TutorSessionCompletedScreen** — `.../session/completed` (66)

### B. Workflow couvert
```
Dashboard → Prochain rendez-vous → Appointments (À venir/En attente/Historique)
  En attente  → Requests → Accepter/Refuser (53, déjà existant)
  Confirmé    → Conversation → Vocal/Documents · Appeler
              → Démarrer la séance → StartSession
                  code valide (64) → SessionInProgress (65, en ligne)
                  "en présentiel"   → SessionInProgressPresential (67)
              → Terminer → SessionCompleted (66) → Retour au tableau de bord
```
Aucune étape n'est court-circuitée : le détail redirige toute demande PENDING vers 53 (Accepter/Refuser n'existe qu'à un seul endroit) ; StartSession redirige si la séance est déjà IN_PROGRESS/COMPLETED ; le code est vérifié côté service avant la transition CONFIRMED → IN_PROGRESS ; "Rejoindre la séance" rouvre la bonne variante (65 ou 67) via le nouveau champ `sessionMode`.

**Écart assumé par rapport au mock HTML fourni** : sur `67_SessionInProgressPresential.html`, le bouton "Terminer" pointe vers `31_SessionCompleted.html` (l'écran du *bénéficiaire*) — une erreur manifeste de copier-coller dans la maquette statique. Il a été corrigé vers l'écran de fin de séance du *tuteur* (66), seul cohérent avec la transition IN_PROGRESS → COMPLETED déjà définie côté tuteur (AGENTS.md §11 : ne pas reproduire une incohérence plutôt que respecter le workflow).

### C. API Services créés/étendus
- `booking.service.ts` :
  - `+ startTutorSession(bookingId, code)` → `POST /bookings/:id/start-session` (body `{ code }`) — vérifie le code contre `computeSessionCode` (factorisé, partagé avec `getSessionCode`), CONFIRMED → IN_PROGRESS (`sessionMode: "online"`)
  - `+ startTutorPresentialSession(bookingId)` → `POST /bookings/:id/start-session` (body `{ mode: "in_person" }`) — sans code, CONFIRMED → IN_PROGRESS (`sessionMode: "in_person"`)
  - `+ completeTutorSession(bookingId)` → `POST /bookings/:id/complete-session` — IN_PROGRESS → COMPLETED, calcule `sessionDurationLabel`
  - mock : ajout de `booking-thomas-confirmed` (CONFIRMED, même bénéficiaire/offre que la demande en attente existante mais sur l'autre créneau du samedi, pour ne pas raconter que le même rendez-vous est à la fois PENDING et CONFIRMED)
- `conversation.service.ts` : seed du fil de messages de `booking-thomas-confirmed` (correspond aux bulles de référence de `63_TutorConversation.html`)
- `types/booking.ts` : `+ Booking.sessionMode?: "online" | "in_person"` — décide quelle variante d'écran "en cours" rouvrir

Nouveau hook `use-tutor-session-action.ts` (start en ligne/présentiel + terminer), suivant exactement le pattern loading/error déjà en place (`use-session-action.ts`). Aucun `fetch()` dans les composants.

### D. États gérés
Loading (skeletons/spinners), disabled + garde anti-double-tap, erreur + réessayer (y compris "Code incorrect" inline sous les 6 cases), succès + navigation, vide (aucun rendez-vous à venir/en attente/dans l'historique, aucun message, aucun document), validation (bouton "Démarrer la séance" désactivé tant que les 6 chiffres ne sont pas saisis), transitions d'état strictes (redirections si PENDING/IN_PROGRESS/COMPLETED atteint au mauvais endroit).

### E. Points dépendant du backend
Tous les endpoints listés en C (mockés). Vrai signaling d'appel (WebRTC) pour 28-équivalent tuteur. `expo-document-picker` pour un vrai choix de fichier. Rôle/session tuteur réel (`CURRENT_TUTOR_ID` mocke toujours le tuteur connecté). Le "Simuler : coller le code du bénéficiaire" sur StartSession est un raccourci de démo explicite (pré-remplit les 6 cases avec le code attendu, sans court-circuiter la validation) — nécessaire car les mocks tuteur/bénéficiaire sont deux îlots de données séparés (aucun modèle de réservation partagé n'existe encore, comme documenté ailleurs dans ce fichier).

### F. Volontairement hors périmètre
Annulation d'un rendez-vous confirmé côté tuteur — absente de `62_TutorAppointmentDetail.html` (aucun bouton "Annuler" dans le mock, contrairement au 24_BookingConfirmed du bénéficiaire). Évaluation du bénéficiaire par le tuteur — aucun écran fourni pour ça, et `review.service.ts` n'est défini que dans le sens bénéficiaire → tuteur.

Le typecheck (`tsc --noEmit`) et le lint sont propres sur tous les fichiers créés/modifiés par cette tâche (vérifié individuellement) ; les erreurs `react-hooks/set-state-in-effect` que `eslint src` remonte par ailleurs sont préexistantes dans une vingtaine de fichiers du projet (hooks `use-*`, `offer-detail-screen.tsx`, `availability-edit-screen.tsx`...), non introduites ici. `expo export -p web` réussit (10 nouvelles routes rendues en SSR sans erreur ni warning).

