const { getDefaultConfig } = require("expo/metro-config");
const { withNativewind } = require("nativewind/metro");

/** @type {import('expo/metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

config.server = {
  ...config.server,
  enhanceMiddleware: (metroMiddleware) => {
    return (req, res, next) => {
      if (req.headers.origin) {
        try {
          const originUrl = new URL(req.headers.origin);
          if (originUrl.host && !req.headers.host) {
            req.headers.host = originUrl.host;
          }
        } catch (_) {}
      }
      return metroMiddleware(req, res, next);
    };
  },
};

module.exports = withNativewind(config);
