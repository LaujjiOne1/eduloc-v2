import { create } from "zustand";

import type { Category } from "@/types/category";
import type {
  BeneficiaryType,
  EducationLevel,
  LearningObjective,
  LocationFormatId,
  SearchCriteria,
} from "@/types/search";

const INITIAL_CRITERIA: SearchCriteria = {
  subject: null,
  level: null,
  beneficiary: null,
  location: { query: "", useCurrentPosition: false, format: "in_person" },
  objective: null,
  detail: { note: "" },
};

interface SearchWizardStore {
  criteria: SearchCriteria;
  setSubject: (subject: Category) => void;
  setLevel: (level: EducationLevel) => void;
  setBeneficiary: (beneficiary: BeneficiaryType) => void;
  setLocationQuery: (query: string) => void;
  setCurrentPositionLabel: (label: string) => void;
  setLocationFormat: (format: LocationFormatId) => void;
  setObjective: (objective: LearningObjective) => void;
  setDetailNote: (note: string) => void;
  reset: () => void;
}

/**
 * Holds the selections made across the Need → Level → ForWhom → Location →
 * Objective wizard so that navigating back and forth between those steps
 * never loses previously entered data. `reset()` is called from the Home
 * screen's "goToSearch" so every fresh search starts from a clean state.
 */
export const useSearchWizardStore = create<SearchWizardStore>((set) => ({
  criteria: INITIAL_CRITERIA,

  setSubject: (subject) => set((s) => ({ criteria: { ...s.criteria, subject } })),

  setLevel: (level) => set((s) => ({ criteria: { ...s.criteria, level } })),

  setBeneficiary: (beneficiary) => set((s) => ({ criteria: { ...s.criteria, beneficiary } })),

  setLocationQuery: (query) =>
    set((s) => ({
      criteria: { ...s.criteria, location: { ...s.criteria.location, query, useCurrentPosition: false } },
    })),

  setCurrentPositionLabel: (label) =>
    set((s) => ({
      criteria: {
        ...s.criteria,
        location: { ...s.criteria.location, query: label, useCurrentPosition: true },
      },
    })),

  setLocationFormat: (format) =>
    set((s) => ({ criteria: { ...s.criteria, location: { ...s.criteria.location, format } } })),

  setObjective: (objective) => set((s) => ({ criteria: { ...s.criteria, objective } })),

  setDetailNote: (note) => set((s) => ({ criteria: { ...s.criteria, detail: { note } } })),

  reset: () => set({ criteria: INITIAL_CRITERIA }),
}));
