import { create } from "zustand";

import type { EducationLevel, LocationFormatId } from "@/types/search";
import type {
  TutorApplication,
  TutorAvailabilityEntry,
  TutorBackgroundFields,
  TutorDocumentEntry,
  TutorDocumentKind,
  TutorExperienceEntry,
  TutorIdentityFields,
  TutorLocationEntry,
  TutorOfferDraft,
  TutorSkill,
  TutorSubjectLevels,
  WeeklyDayAvailability,
} from "@/types/tutor-application";

const INITIAL_IDENTITY: TutorIdentityFields = {
  firstName: "",
  lastName: "",
  birthDate: "",
  phone: "",
  email: "",
};

const INITIAL_BACKGROUND: TutorBackgroundFields = {
  degree: null,
  field: "",
  institution: "",
  experience: "",
  experiences: [],
};

export const createDefaultOffer = (id = "offer-1"): TutorOfferDraft => ({
  id,
  skill: null,
  level: null,
  title: "",
  description: "",
  duration: { id: "1h", label: "1 heure", hours: 1 },
  hourlyRate: 30,
  priceCalculated: 30,
});

const INITIAL_DOCUMENTS: TutorDocumentEntry[] = [
  { kind: "proof_of_identity", label: "Pièce justificative (CNI / Passeport)", provided: false },
  { kind: "diploma", label: "Diplôme le plus élevé", provided: false },
  { kind: "other", label: "Autre document (CV / Certification)", provided: false },
];

const INITIAL_LOCATIONS: TutorLocationEntry[] = [
  { id: "loc-main", label: "Paris et alentours (Adresse principale)", radiusKm: 15, isPrimary: true },
];

export const INITIAL_WEEKLY_AVAILABILITY: WeeklyDayAvailability[] = [
  { dayId: "mon", dayLabel: "Lundi", active: true, slots: [{ id: "slot-mon-1", startTime: "17:00", endTime: "20:00", format: "in_person" }] },
  { dayId: "tue", dayLabel: "Mardi", active: true, slots: [{ id: "slot-tue-1", startTime: "17:00", endTime: "20:00", format: "in_person" }] },
  { dayId: "wed", dayLabel: "Mercredi", active: true, slots: [{ id: "slot-wed-1", startTime: "14:00", endTime: "19:00", format: "both" }] },
  { dayId: "thu", dayLabel: "Jeudi", active: true, slots: [{ id: "slot-thu-1", startTime: "17:00", endTime: "20:00", format: "in_person" }] },
  { dayId: "fri", dayLabel: "Vendredi", active: true, slots: [{ id: "slot-fri-1", startTime: "17:00", endTime: "21:00", format: "both" }] },
  { dayId: "sat", dayLabel: "Samedi", active: true, slots: [{ id: "slot-sat-1", startTime: "09:00", endTime: "18:00", format: "both" }] },
  { dayId: "sun", dayLabel: "Dimanche", active: false, slots: [] },
];

interface TutorApplicationStore {
  identity: TutorIdentityFields;
  background: TutorBackgroundFields;
  skills: TutorSkill[];
  subjectLevels: TutorSubjectLevels[];
  bio: string;
  offer: TutorOfferDraft;
  offers: TutorOfferDraft[];
  activeOfferIndex: number;
  formats: LocationFormatId[];
  locations: TutorLocationEntry[];
  availability: TutorAvailabilityEntry[];
  weeklyAvailability: WeeklyDayAvailability[];
  documents: TutorDocumentEntry[];
  application: TutorApplication | null;
  isPendingValidation: boolean;

  setIdentity: (fields: Partial<TutorIdentityFields>) => void;
  setBackground: (fields: Partial<TutorBackgroundFields>) => void;
  addExperience: (entry: Omit<TutorExperienceEntry, "id">) => void;
  updateExperience: (id: string, entry: Partial<TutorExperienceEntry>) => void;
  removeExperience: (id: string) => void;
  toggleSkill: (skill: TutorSkill) => void;
  addCustomSkill: (skill: TutorSkill) => void;
  toggleSubjectLevel: (skill: TutorSkill, level: EducationLevel) => void;
  setBio: (bio: string) => void;
  setOffer: (fields: Partial<TutorOfferDraft>) => void;
  updateOfferAtIndex: (index: number, fields: Partial<TutorOfferDraft>) => void;
  addNewOffer: () => void;
  removeOfferAtIndex: (index: number) => void;
  setActiveOfferIndex: (index: number) => void;
  toggleFormat: (format: LocationFormatId) => void;
  updatePrimaryRadius: (radiusKm: number) => void;
  addSecondaryLocation: (label: string, radiusKm: number) => void;
  removeLocation: (id: string) => void;
  toggleWeeklyDay: (dayId: string) => void;
  addWeeklySlot: (dayId: string, startTime: string, endTime: string, format?: LocationFormatId) => void;
  removeWeeklySlot: (dayId: string, slotId: string) => void;
  toggleDocument: (kind: TutorDocumentKind) => void;
  attachDocumentFile: (kind: TutorDocumentKind, fileName: string, fileSize: string) => void;
  setApplication: (application: TutorApplication) => void;
  setIsPendingValidation: (val: boolean) => void;
  reset: () => void;
}

export const useTutorApplicationStore = create<TutorApplicationStore>((set) => ({
  identity: INITIAL_IDENTITY,
  background: INITIAL_BACKGROUND,
  skills: [],
  subjectLevels: [],
  bio: "",
  offer: createDefaultOffer(),
  offers: [createDefaultOffer()],
  activeOfferIndex: 0,
  formats: ["in_person", "online"],
  locations: INITIAL_LOCATIONS,
  availability: [
    { id: "av-1", dateLabel: "Samedi 26 Septembre", timeRangeLabel: "14:00 - 15:00", format: "in_person", locationLabel: "Paris 11e" },
    { id: "av-2", dateLabel: "Mercredi 30 Septembre", timeRangeLabel: "16:00 - 17:00", format: "online", locationLabel: null },
  ],
  weeklyAvailability: INITIAL_WEEKLY_AVAILABILITY,
  documents: INITIAL_DOCUMENTS,
  application: null,
  isPendingValidation: false,

  setIdentity: (fields) => set((s) => ({ identity: { ...s.identity, ...fields } })),

  setBackground: (fields) => set((s) => ({ background: { ...s.background, ...fields } })),

  addExperience: (entry) =>
    set((s) => {
      const newEntry: TutorExperienceEntry = {
        ...entry,
        id: `exp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      };
      const experiences = [...(s.background.experiences ?? []), newEntry];
      return {
        background: {
          ...s.background,
          experiences,
          experience: experiences.map((e) => `${e.title} (${e.organization})`).join(", "),
        },
      };
    }),

  updateExperience: (id, fields) =>
    set((s) => {
      const experiences = (s.background.experiences ?? []).map((exp) =>
        exp.id === id ? { ...exp, ...fields } : exp
      );
      return {
        background: {
          ...s.background,
          experiences,
          experience: experiences.map((e) => `${e.title} (${e.organization})`).join(", "),
        },
      };
    }),

  removeExperience: (id) =>
    set((s) => {
      const experiences = (s.background.experiences ?? []).filter((exp) => exp.id !== id);
      return {
        background: {
          ...s.background,
          experiences,
          experience: experiences.map((e) => `${e.title} (${e.organization})`).join(", "),
        },
      };
    }),

  toggleSkill: (skill) =>
    set((s) => {
      const exists = s.skills.some((sk) => sk.id === skill.id);
      const newSkills = exists ? s.skills.filter((sk) => sk.id !== skill.id) : [...s.skills, skill];
      return {
        skills: newSkills,
        subjectLevels: exists ? s.subjectLevels.filter((sl) => sl.skill.id !== skill.id) : s.subjectLevels,
      };
    }),

  addCustomSkill: (skill) =>
    set((s) => {
      const exists = s.skills.some((sk) => sk.id === skill.id || sk.label.toLowerCase() === skill.label.toLowerCase());
      if (exists) return s;
      return { skills: [...s.skills, skill] };
    }),

  toggleSubjectLevel: (skill, level) =>
    set((s) => {
      const index = s.subjectLevels.findIndex((sl) => sl.skill.id === skill.id);
      if (index === -1) {
        return { subjectLevels: [...s.subjectLevels, { skill, levels: [level] }] };
      }
      const entry = s.subjectLevels[index];
      const hasLevel = entry.levels.some((l) => l.id === level.id);
      const levels = hasLevel ? entry.levels.filter((l) => l.id !== level.id) : [...entry.levels, level];
      const next = [...s.subjectLevels];
      next[index] = { ...entry, levels };
      return { subjectLevels: next };
    }),

  setBio: (bio) => set({ bio }),

  setOffer: (fields) =>
    set((s) => {
      const updated = { ...s.offer, ...fields };
      const hours = updated.duration?.hours ?? 1;
      const rate = updated.hourlyRate ?? 30;
      updated.priceCalculated = Math.round(hours * rate);
      const newOffers = [...s.offers];
      newOffers[s.activeOfferIndex] = updated;
      return { offer: updated, offers: newOffers };
    }),

  updateOfferAtIndex: (index, fields) =>
    set((s) => {
      const target = s.offers[index] ?? createDefaultOffer(`offer-${index + 1}`);
      const updated = { ...target, ...fields };
      const hours = updated.duration?.hours ?? 1;
      const rate = updated.hourlyRate ?? 30;
      updated.priceCalculated = Math.round(hours * rate);
      const newOffers = [...s.offers];
      newOffers[index] = updated;
      return {
        offers: newOffers,
        offer: index === s.activeOfferIndex ? updated : s.offer,
      };
    }),

  addNewOffer: () =>
    set((s) => {
      const newId = `offer-${s.offers.length + 1}`;
      const freshOffer = createDefaultOffer(newId);
      return {
        offers: [...s.offers, freshOffer],
        activeOfferIndex: s.offers.length,
        offer: freshOffer,
      };
    }),

  removeOfferAtIndex: (index) =>
    set((s) => {
      if (s.offers.length <= 1) return s;
      const newOffers = s.offers.filter((_, i) => i !== index);
      const nextIndex = Math.min(s.activeOfferIndex, newOffers.length - 1);
      return {
        offers: newOffers,
        activeOfferIndex: nextIndex,
        offer: newOffers[nextIndex],
      };
    }),

  setActiveOfferIndex: (index) =>
    set((s) => {
      if (index >= 0 && index < s.offers.length) {
        return { activeOfferIndex: index, offer: s.offers[index] };
      }
      return s;
    }),

  toggleFormat: (format) =>
    set((s) => ({
      formats: s.formats.includes(format) ? s.formats.filter((f) => f !== format) : [...s.formats, format],
    })),

  updatePrimaryRadius: (radiusKm) =>
    set((s) => ({
      locations: s.locations.map((loc) => (loc.isPrimary ? { ...loc, radiusKm } : loc)),
    })),

  addSecondaryLocation: (label, radiusKm) =>
    set((s) => ({
      locations: [...s.locations, { id: `loc-${Date.now()}`, label, radiusKm, isPrimary: false }],
    })),

  removeLocation: (id) =>
    set((s) => ({
      locations: s.locations.filter((loc) => loc.id !== id || loc.isPrimary),
    })),

  toggleWeeklyDay: (dayId) =>
    set((s) => ({
      weeklyAvailability: s.weeklyAvailability.map((d) => (d.dayId === dayId ? { ...d, active: !d.active } : d)),
    })),

  addWeeklySlot: (dayId, startTime, endTime, format = "in_person") =>
    set((s) => ({
      weeklyAvailability: s.weeklyAvailability.map((d) =>
        d.dayId === dayId
          ? {
              ...d,
              active: true,
              slots: [...d.slots, { id: `slot-${Date.now()}`, startTime, endTime, format }],
            }
          : d,
      ),
    })),

  removeWeeklySlot: (dayId, slotId) =>
    set((s) => ({
      weeklyAvailability: s.weeklyAvailability.map((d) =>
        d.dayId === dayId ? { ...d, slots: d.slots.filter((slot) => slot.id !== slotId) } : d,
      ),
    })),

  toggleDocument: (kind) =>
    set((s) => ({
      documents: s.documents.map((d) => (d.kind === kind ? { ...d, provided: !d.provided } : d)),
    })),

  attachDocumentFile: (kind, fileName, fileSize) =>
    set((s) => ({
      documents: s.documents.map((d) =>
        d.kind === kind ? { ...d, provided: true, fileName, fileSize } : d,
      ),
    })),

  setApplication: (application) => set({ application }),

  setIsPendingValidation: (val) => set({ isPendingValidation: val }),

  reset: () =>
    set({
      identity: INITIAL_IDENTITY,
      background: INITIAL_BACKGROUND,
      skills: [],
      subjectLevels: [],
      bio: "",
      offer: createDefaultOffer(),
      offers: [createDefaultOffer()],
      activeOfferIndex: 0,
      formats: ["in_person", "online"],
      locations: INITIAL_LOCATIONS,
      availability: [],
      weeklyAvailability: INITIAL_WEEKLY_AVAILABILITY,
      documents: INITIAL_DOCUMENTS,
      application: null,
      isPendingValidation: false,
    }),
}));
