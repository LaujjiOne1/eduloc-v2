import { create } from "zustand";

import type { Offer, OfferSlot } from "@/types/offer";
import type { EducationLevel } from "@/types/search";

export interface BookingBeneficiaryFields {
  firstName: string;
  lastName: string;
  /** null when booking for yourself — "relation to yourself" is meaningless. */
  relation: { id: string; label: string } | null;
  level: EducationLevel | null;
}

const INITIAL_BENEFICIARY: BookingBeneficiaryFields = {
  firstName: "",
  lastName: "",
  relation: null,
  level: null,
};

interface BookingWizardStore {
  offer: Offer | null;
  slot: OfferSlot | null;
  beneficiary: BookingBeneficiaryFields;
  difficulty: string;
  /** Id of the Booking BookingSummary just created — lets BookingPending's "Voir la demande" open the real 23_BookingDetailPending. */
  createdBookingId: string | null;
  setBooking: (offer: Offer, slot: OfferSlot) => void;
  setBeneficiaryFields: (fields: Partial<BookingBeneficiaryFields>) => void;
  setDifficulty: (difficulty: string) => void;
  setCreatedBookingId: (id: string) => void;
  reset: () => void;
}

/**
 * Holds the offer/slot picked on BookDate plus the beneficiary details
 * gathered across Beneficiary → BeneficiaryProfile, so none of it is lost
 * while the user detours through Login/Signup/Verify (AGENTS.md §13:
 * navigation must never drop already-entered data). Reset once the request
 * has actually been sent (BookingPending's "Retour à l'accueil"), mirroring
 * how the search wizard is reset from Home's `goToSearch`.
 */
export const useBookingWizardStore = create<BookingWizardStore>((set) => ({
  offer: null,
  slot: null,
  beneficiary: INITIAL_BENEFICIARY,
  difficulty: "",
  createdBookingId: null,

  setBooking: (offer, slot) => set({ offer, slot }),

  setBeneficiaryFields: (fields) =>
    set((s) => ({ beneficiary: { ...s.beneficiary, ...fields } })),

  setDifficulty: (difficulty) => set({ difficulty }),

  setCreatedBookingId: (createdBookingId) => set({ createdBookingId }),

  reset: () => set({ offer: null, slot: null, beneficiary: INITIAL_BENEFICIARY, difficulty: "", createdBookingId: null }),
}));
