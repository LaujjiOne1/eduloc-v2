import { type Href, useRouter } from "expo-router";
import type { ComponentType } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  BellIcon,
  ChevronRightIcon,
  GraduationCapIcon,
  type IconProps,
  LockIcon,
  LogoutIcon,
  PersonIcon,
  TeachIcon,
  VerifiedBadgeIcon,
} from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { ApprentiBottomNav } from "@/components/ui/apprenti-bottom-nav";
import { TutorBottomNav } from "@/components/ui/tutor-bottom-nav";
import { AuthHeader } from "@/components/ui/auth-header";
import { useAuthStore } from "@/store/auth.store";

const MODE_SWITCH_ROUTE = "/mode-switch" as Href;
const NOTIFICATIONS_ROUTE = "/notifications" as Href;
const HOME_ROUTE = "/home" as Href;

// The reference screen shows a fixed "Tida Lauralien" persona, already
// pre-masked in the mock ("t•••@gmail.com") — like the sibling dashboard's
// hardcoded "Bonjour, Tida" greeting, this screen isn't wired to a real
// signed-in session (no such session exists for the demo dashboards yet,
// AGENTS.md §8).
const DISPLAY_NAME = "Tida Lauralien";
const DISPLAY_EMAIL_MASKED = "t•••@gmail.com";

export function AccountScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const activeMode = useAuthStore((s) => s.activeMode);
  const logout = useAuthStore((s) => s.logout);

  const initials = DISPLAY_NAME.split(" ")
    .map((part) => part.charAt(0))
    .join("")
    .slice(0, 2);
  const isApprenti = activeMode === "apprenti";

  const handleLogout = () => {
    logout();
    router.replace(HOME_ROUTE);
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 6, paddingBottom: Math.max(insets.bottom, 20) }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={30}>
          <View className="mb-[22px] flex-row items-center gap-[14px]">
            <View className="h-14 w-14 items-center justify-center rounded-full bg-primary-tint">
              <Text className="text-[19px] font-bold text-primary">{initials}</Text>
            </View>
            <View>
              <Text className="text-[17px] font-bold text-ink">{DISPLAY_NAME}</Text>
              <Text className="text-[13px] text-ink-soft">{DISPLAY_EMAIL_MASKED}</Text>
            </View>
          </View>
        </FadeIn>

        <FadeIn delay={70}>
          <Text className="mb-2 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">Mode</Text>
          <PressableScale
            onPress={() => router.push(MODE_SWITCH_ROUTE)}
            accessibilityLabel={`Mode ${isApprenti ? "Apprenti" : "Tuteur"} — changer de mode`}
          >
            <View className="mb-[22px] flex-row items-center gap-3 rounded-lg border border-line bg-surface p-4">
              <View className="flex-1 flex-row items-center gap-2">
                {isApprenti ? (
                  <GraduationCapIcon size={17} color="#332E86" />
                ) : (
                  <TeachIcon size={17} color="#332E86" />
                )}
                <Text className="text-[14.5px] font-bold text-ink">Mode {isApprenti ? "Apprenti" : "Tuteur"}</Text>
              </View>
              <View className="flex-row items-center gap-[6px] rounded-full border border-line bg-surface px-[14px] py-[9px]">
                <TeachIcon size={13} color="#585B78" />
                <Text className="text-[13.5px] font-semibold text-ink-soft">
                  Passer en {isApprenti ? "Tuteur" : "Apprenti"}
                </Text>
              </View>
            </View>
          </PressableScale>
        </FadeIn>

        <FadeIn delay={110}>
          <View className="rounded-lg border border-line bg-surface px-4">
            <SettingsRow
              Icon={PersonIcon}
              label="Informations personnelles"
              onPress={() => {}}
              disabled
              accessibilityLabel="Informations personnelles (bientôt disponible)"
            />
            <SettingsRow Icon={BellIcon} label="Notifications" onPress={() => router.push(NOTIFICATIONS_ROUTE)} />
            <SettingsRow
              Icon={VerifiedBadgeIcon}
              label="Confidentialité"
              onPress={() => {}}
              disabled
              accessibilityLabel="Confidentialité (bientôt disponible)"
            />
            <SettingsRow
              Icon={LockIcon}
              label="Sécurité"
              onPress={() => {}}
              disabled
              last
              accessibilityLabel="Sécurité (bientôt disponible)"
            />
          </View>
        </FadeIn>

        <FadeIn delay={150}>
          <PressableScale onPress={handleLogout} accessibilityLabel="Déconnexion">
            <View className="mt-[22px] flex-row items-center gap-[10px] py-2">
              <LogoutIcon size={18} color="#AC4A40" />
              <Text className="text-[14.5px] font-bold text-error">Déconnexion</Text>
            </View>
          </PressableScale>
        </FadeIn>
      </ScrollView>

      {isApprenti ? <ApprentiBottomNav active="profile" /> : <TutorBottomNav active="profile" />}
    </View>
  );
}

function SettingsRow({
  Icon,
  label,
  onPress,
  disabled,
  last,
  accessibilityLabel,
}: {
  Icon: ComponentType<IconProps>;
  label: string;
  onPress: () => void;
  disabled?: boolean;
  last?: boolean;
  accessibilityLabel?: string;
}) {
  return (
    <View>
      <PressableScale onPress={onPress} disabled={disabled} accessibilityLabel={accessibilityLabel ?? label}>
        <View className="flex-row items-center gap-[14px] py-[13px]">
          <Icon size={18} color="#585B78" />
          <Text className="flex-1 text-[14.5px] font-semibold text-ink">{label}</Text>
          <ChevronRightIcon size={16} color="#9799AF" />
        </View>
      </PressableScale>
      {last ? null : <View className="h-px bg-line-soft" />}
    </View>
  );
}
