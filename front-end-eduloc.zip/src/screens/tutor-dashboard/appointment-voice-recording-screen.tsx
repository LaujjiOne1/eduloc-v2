import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect } from "react";
import { Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from "react-native-reanimated";

import { MicIcon, SendIcon } from "@/components/icons";
import { Button } from "@/components/ui/button";
import { formatDuration, useElapsedSeconds } from "@/hooks/use-elapsed-seconds";
import { useSendMessage } from "@/hooks/use-send-message";

const BAR_COUNT = 10;

export function TutorVoiceRecordingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const seconds = useElapsedSeconds();
  const { state, sendVoice } = useSendMessage();
  const isSending = state.status === "sending";

  const handleCancel = () => router.back();

  const handleSend = async () => {
    if (!id) return;
    const message = await sendVoice(id, formatDuration(seconds));
    if (message) router.back();
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <View className="flex-row items-center gap-3 px-5 pb-[14px] pt-[18px]">
        <Text className="text-[21px] font-bold text-ink">
          Edu<Text className="text-primary">Loc</Text>
        </Text>
      </View>

      <View className="flex-1 items-center justify-center gap-[26px] px-5">
        <Text className="text-[13px] font-semibold text-ink-soft">Enregistrement en cours</Text>

        <View className="items-center justify-center">
          <PulseRing />
          <View className="h-[120px] w-[120px] items-center justify-center rounded-full bg-error-tint">
            <View className="h-[74px] w-[74px] items-center justify-center rounded-full bg-error">
              <MicIcon size={30} color="#fff" />
            </View>
          </View>
        </View>

        <Text className="text-[26px] font-bold text-ink">{formatDuration(seconds)}</Text>

        <View className="flex-row items-end gap-1" style={{ height: 30 }}>
          {Array.from({ length: BAR_COUNT }, (_, index) => (
            <WaveformBar key={index} index={index} />
          ))}
        </View>

        <Text className="text-[13px] text-ink-faint">Relâchez pour envoyer</Text>
      </View>

      <View className="flex-shrink-0 border-t border-line-soft bg-surface px-5 pt-4" style={{ paddingBottom: Math.max(insets.bottom, 22) }}>
        <View className="flex-row gap-[10px] justify-center">
          <Button label="Annuler" className="w-full" variant="ghost" disabled={isSending} onPress={handleCancel} />
          <Button
            label="Envoyer"
            disabled={isSending}
            loading={isSending}
            loadingLabel="Envoi..."
            icon={<SendIcon size={17} color="#fff" />}
            onPress={handleSend}
          />
        </View>
      </View>
    </View>
  );
}

/** Pulsing ring behind the mic — signals "recording" without relying on color alone. */
function PulseRing() {
  const pulse = useSharedValue(0);

  useEffect(() => {
    pulse.value = withRepeat(withTiming(1, { duration: 900 }), -1, false);
  }, [pulse]);

  const style = useAnimatedStyle(() => ({
    opacity: 0.9 - pulse.value * 0.9,
    transform: [{ scale: 1 + pulse.value * 0.35 }],
  }));

  return (
    <Animated.View
      pointerEvents="none"
      style={[{ position: "absolute", width: 140, height: 140, borderRadius: 70, borderWidth: 2, borderColor: "#F6E9E6" }, style]}
    />
  );
}

/** One bar of the decorative waveform, animating its own height on a loop staggered by index. */
function WaveformBar({ index }: { index: number }) {
  const height = useSharedValue(0.3);

  useEffect(() => {
    const duration = 260 + index * 30;
    const peakA = 0.3 + ((index * 37) % 70) / 100;
    const peakB = 0.3 + ((index * 53) % 70) / 100;
    height.value = withRepeat(withSequence(withTiming(peakA, { duration }), withTiming(peakB, { duration })), -1, true);
  }, [height, index]);

  const style = useAnimatedStyle(() => ({ transform: [{ scaleY: height.value }] }));

  return <Animated.View style={[{ width: 3, height: 30, borderRadius: 2, backgroundColor: "#332E86" }, style]} />;
}
