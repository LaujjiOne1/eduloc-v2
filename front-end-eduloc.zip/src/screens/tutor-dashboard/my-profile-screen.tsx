import { type Href, useRouter } from "expo-router";
import type { ReactNode } from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { StarIcon } from "@/components/icons";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Chip } from "@/components/ui/chip";
import { TutorBottomNav } from "@/components/ui/tutor-bottom-nav";
import { getTutorAvatarTone } from "@/components/ui/tutor-card";
import { useTutorOffers } from "@/hooks/use-tutor-offers";
import { useTutorProfile } from "@/hooks/use-tutor-profile";
import type { TutorProfileSummary } from "@/types/tutor-profile";

// Reuses the existing onboarding identity screen, matching the mock's own
// "Modifier le profil" → 39_TutorIdentity.html link.
const EDIT_PROFILE_ROUTE = "/tutor-identity" as Href;

export function MyProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state: profileState, retry } = useTutorProfile();
  const { state: offersState } = useTutorOffers();

  const activeOfferCount = offersState.status === "success" ? offersState.offers.filter((o) => o.isActive).length : null;

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      {profileState.status === "loading" ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator color="#332E86" />
        </View>
      ) : profileState.status === "error" ? (
        <View className="flex-1 items-center justify-center gap-3 px-8">
          <Text className="text-center text-[14px] text-error">{profileState.message}</Text>
          <PressableScale onPress={retry} accessibilityLabel="Réessayer">
            <Text className="text-[14px] font-semibold text-primary">Réessayer</Text>
          </PressableScale>
        </View>
      ) : (
        <ProfileContent
          profile={profileState.profile}
          activeOfferCount={activeOfferCount}
          onEdit={() => router.push(EDIT_PROFILE_ROUTE)}
        />
      )}

      <TutorBottomNav active="profile" />
    </View>
  );
}

function ProfileContent({
  profile,
  activeOfferCount,
  onEdit,
}: {
  profile: TutorProfileSummary;
  activeOfferCount: number | null;
  onEdit: () => void;
}) {
  const subjectLine = profile.subjects.map((s) => s.skill.label).join(" • ");
  const levelLabels = [...new Set(profile.subjects.flatMap((s) => s.levels.map((l) => l.label)))];
  const locationLine = profile.locations.map((l) => l.label).join(" • ");
  const avatarTone = getTutorAvatarTone(profile.avatarTone);

  return (
    <ScrollView className="flex-1" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }} showsVerticalScrollIndicator={false}>
      <View className="items-center pb-5 pt-[6px]">
        <View className={["mb-3 h-20 w-20 items-center justify-center rounded-full", avatarTone.bg].join(" ")}>
          <Text className={["text-[26px] font-bold", avatarTone.text].join(" ")}>{profile.avatarInitials}</Text>
        </View>
        <Text className="text-[19px] font-bold text-ink">
          {profile.firstName} {profile.lastName}
        </Text>
        <View className="mt-[6px] flex-row items-center gap-[6px]">
          <StarIcon size={13} color="#BD7E28" />
          <Text className="text-[13px] font-bold text-ink">{profile.rating.toFixed(1)}</Text>
        </View>
        <PressableScale onPress={onEdit} accessibilityLabel="Modifier le profil">
          <Text className="mt-[10px] text-[13px] font-bold text-primary">Modifier le profil</Text>
        </PressableScale>
      </View>

      <Section label="À propos">
        <Text className="text-[14px] leading-[20px] text-ink-soft" numberOfLines={3}>
          {profile.bio}
        </Text>
      </Section>

      <Section label="Compétences">
        <View className="flex-row flex-wrap gap-2">
          {profile.skills.map((skill) => (
            <Chip key={skill.id} label={skill.label} />
          ))}
        </View>
      </Section>

      <Section label="Matières">
        <Text className="text-[14px] font-semibold text-ink">
          {subjectLine}
          {levelLabels.length ? ` — ${levelLabels.join(", ")}` : ""}
        </Text>
      </Section>

      <Section label="Offres">
        <Text className="text-[14px] font-semibold text-ink">
          {activeOfferCount === null ? "…" : `${activeOfferCount} offre${activeOfferCount === 1 ? "" : "s"} active${activeOfferCount === 1 ? "" : "s"}`}
        </Text>
      </Section>

      <Section label="Lieux" last>
        <Text className="text-[14px] font-semibold text-ink">{locationLine || "Aucun lieu enregistré"}</Text>
      </Section>
    </ScrollView>
  );
}

function Section({ label, last, children }: { label: string; last?: boolean; children: ReactNode }) {
  return (
    <View className={last ? "" : "mb-5"}>
      <Text className="mb-[6px] ml-0.5 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">{label}</Text>
      {children}
    </View>
  );
}
