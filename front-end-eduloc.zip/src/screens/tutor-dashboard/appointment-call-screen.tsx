import { type Href, useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { MicIcon, PhoneIcon, VideoIcon } from "@/components/icons";
import { ScaleIn } from "@/components/motion/scale-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { Button } from "@/components/ui/button";
import { formatDuration, useElapsedSeconds } from "@/hooks/use-elapsed-seconds";
import { useTutorBooking } from "@/hooks/use-tutor-booking";
import type { Booking } from "@/types/booking";

function backRoute(booking: Booking): Href {
  return booking.status === "pending"
    ? (`/tutor-dashboard/requests/${booking.id}` as Href)
    : (`/tutor-dashboard/appointments/${booking.id}` as Href);
}

export function TutorAppointmentCallScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { state } = useTutorBooking(id);
  const seconds = useElapsedSeconds();
  const [muted, setMuted] = useState(false);
  const [videoOn, setVideoOn] = useState(false);

  if (state.status === "loading") {
    return (
      <View className="flex-1 items-center justify-center bg-ink" style={{ paddingTop: insets.top }}>
        <ActivityIndicator color="#fff" />
      </View>
    );
  }

  if (state.status === "error") {
    return (
      <View className="flex-1 items-center justify-center bg-ink px-8" style={{ paddingTop: insets.top }}>
        <Text className="text-center text-[14px] text-white">{state.message}</Text>
      </View>
    );
  }

  const { booking } = state;

  // A PENDING/closed booking has no call to join.
  if (booking.status === "pending" || booking.status === "cancelled" || booking.status === "refused") {
    return (
      <View className="flex-1 items-center justify-center gap-5 bg-ink px-8" style={{ paddingTop: insets.top, paddingBottom: insets.bottom }}>
        <Text className="text-center text-[15px] text-white">L&apos;appel sera disponible après confirmation.</Text>
        <Button label="Retour" variant="secondary" onPress={() => router.replace(backRoute(booking))} />
      </View>
    );
  }

  return (
    <View className="flex-1 bg-ink" style={{ paddingTop: insets.top, paddingBottom: Math.max(insets.bottom, 24) }}>
      <View className="flex-1 items-center justify-center gap-4">
        <ScaleIn delay={20}>
          <View className="h-24 w-24 items-center justify-center rounded-full bg-white/10">
            <Text className="text-[30px] font-bold text-white">{booking.beneficiary.firstName.slice(0, 2).toUpperCase()}</Text>
          </View>
        </ScaleIn>
        <Text className="text-[19px] font-bold text-white">{booking.beneficiary.firstName}</Text>
        <Text className="text-[13px] text-white/60">{formatDuration(seconds)}</Text>
      </View>

      <View className="flex-row justify-center gap-4 px-6">
        <PressableScale onPress={() => setMuted((m) => !m)} accessibilityLabel={muted ? "Réactiver le micro" : "Couper le micro"}>
          <View className={["h-[54px] w-[54px] items-center justify-center rounded-full", muted ? "bg-error" : "bg-white/12"].join(" ")}>
            <MicIcon size={22} color="#fff" />
          </View>
        </PressableScale>
        <PressableScale onPress={() => setVideoOn((v) => !v)} accessibilityLabel={videoOn ? "Désactiver la caméra" : "Activer la caméra"}>
          <View className={["h-[54px] w-[54px] items-center justify-center rounded-full", videoOn ? "bg-primary" : "bg-white/12"].join(" ")}>
            <VideoIcon size={22} color="#fff" />
          </View>
        </PressableScale>
        <PressableScale onPress={() => router.replace(backRoute(booking))} accessibilityLabel="Raccrocher">
          <View className="h-[54px] w-[54px] items-center justify-center rounded-full bg-error">
            <PhoneIcon size={22} color="#fff" />
          </View>
        </PressableScale>
      </View>
    </View>
  );
}
