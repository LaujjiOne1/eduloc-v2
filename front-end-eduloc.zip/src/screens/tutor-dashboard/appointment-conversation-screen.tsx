import { type Href, useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import { useCallback } from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ArrowLeftIcon, AttachIcon, FileIcon, MicIcon, PhoneIcon, PlayIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { useConversationMessages } from "@/hooks/use-conversation-messages";
import { useTutorBooking } from "@/hooks/use-tutor-booking";
import type { ConversationMessage } from "@/types/message";

function callRoute(id: string): Href {
  return `/tutor-dashboard/appointments/${id}/call` as Href;
}
function voiceRoute(id: string): Href {
  return `/tutor-dashboard/appointments/${id}/conversation/voice` as Href;
}
function documentsRoute(id: string): Href {
  return `/tutor-dashboard/appointments/${id}/conversation/documents` as Href;
}

export function TutorAppointmentConversationScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { state: bookingState } = useTutorBooking(id);
  const { state: messagesState, reload } = useConversationMessages(id);

  // Sending a voice note or a document happens on a separate screen — reload
  // the thread whenever Conversation regains focus so it shows up.
  useFocusEffect(
    useCallback(() => {
      reload();
    }, [reload]),
  );

  const booking = bookingState.status === "success" ? bookingState.booking : null;
  const canCall = booking ? booking.status !== "pending" && booking.status !== "cancelled" && booking.status !== "refused" : false;
  const initials = booking ? booking.beneficiary.firstName.slice(0, 2).toUpperCase() : "";

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <View className="flex-row items-center gap-3 border-b border-line-soft px-5 pb-[14px] pt-[18px]">
        <PressableScale onPress={() => router.back()} accessibilityLabel="Retour">
          <View className="h-9 w-9 items-center justify-center rounded-full border border-line">
            <ArrowLeftIcon color="#14162B" />
          </View>
        </PressableScale>
        <View className="h-[38px] w-[38px] items-center justify-center rounded-full bg-violet-tint">
          <Text className="text-[13px] font-bold text-violet">{initials}</Text>
        </View>
        <View className="flex-1">
          <Text className="text-[15px] font-bold text-ink">{booking?.beneficiary.firstName ?? "Conversation"}</Text>
          {booking ? (
            <Text className={["text-[11.5px] font-semibold", canCall ? "text-accent" : "text-warning"].join(" ")}>
              {canCall ? "Rendez-vous confirmé" : "En attente de confirmation"}
            </Text>
          ) : null}
        </View>
        {canCall && id ? (
          <PressableScale onPress={() => router.push(callRoute(id))} accessibilityLabel="Appeler">
            <View className="h-9 w-9 items-center justify-center rounded-full bg-primary-tint">
              <PhoneIcon size={16} color="#332E86" />
            </View>
          </PressableScale>
        ) : null}
      </View>

      <ScrollView className="flex-1" contentContainerStyle={{ padding: 20 }} showsVerticalScrollIndicator={false}>
        {messagesState.status === "loading" ? (
          <View className="items-center py-10">
            <ActivityIndicator color="#332E86" />
          </View>
        ) : messagesState.status === "error" ? (
          <Text className="text-center text-[13.5px] text-error">{messagesState.message}</Text>
        ) : messagesState.messages.length === 0 ? (
          <View className="items-center py-10">
            <Text className="text-center text-[13.5px] text-ink-soft">
              Aucun message pour le moment. Envoyez un vocal ou un document pour démarrer la conversation.
            </Text>
          </View>
        ) : (
          messagesState.messages.map((message, index) => (
            <FadeIn key={message.id} delay={Math.min(index * 40, 240)}>
              <MessageBubble message={message} />
            </FadeIn>
          ))
        )}
      </ScrollView>

      <View className="flex-shrink-0 flex-row items-center gap-3 border-t border-line-soft px-5 pb-[22px] pt-[14px]">
        {id ? (
          <PressableScale onPress={() => router.push(documentsRoute(id))} accessibilityLabel="Ajouter un document">
            <View className="h-11 w-11 items-center justify-center rounded-full border border-line">
              <AttachIcon size={18} color="#585B78" />
            </View>
          </PressableScale>
        ) : null}
        <PressableScale
          onPress={() => (id ? router.push(voiceRoute(id)) : undefined)}
          disabled={!id}
          accessibilityLabel="Maintenir pour enregistrer"
          style={{ flex: 1 }}
        >
          <View className="flex-row w-full items-center justify-center gap-[10px] rounded-md bg-primary px-[22px] py-[14px]">
            <MicIcon size={17} color="#fff" />
            <Text className="text-[15px] font-semibold text-white">Maintenir pour enregistrer</Text>
          </View>
        </PressableScale>
      </View>
      <Text className="pb-[14px] text-center text-[11px] text-ink-faint">
        Pas de message texte — vocal et documents uniquement
      </Text>
    </View>
  );
}

function MessageBubble({ message }: { message: ConversationMessage }) {
  const isMine = message.isMine;
  return (
    <View className={["mb-[14px]", isMine ? "items-end" : "items-start"].join(" ")}>
      <Text className="mb-1 px-1 text-[11px] text-ink-faint">{message.authorLabel}</Text>
      <View
        className={[
          "max-w-[250px] rounded-2xl p-[12px]",
          isMine ? "bg-primary" : "border border-line bg-surface",
        ].join(" ")}
      >
        {message.type === "voice" ? (
          <View className="flex-row items-center gap-[10px]">
            <View
              className={["h-[30px] w-[30px] items-center justify-center rounded-full", isMine ? "bg-white/20" : "bg-primary-tint"].join(" ")}
            >
              <PlayIcon size={13} color={isMine ? "#fff" : "#332E86"} />
            </View>
            <View className={["h-[3px] flex-1 rounded", isMine ? "bg-white/35" : "bg-line"].join(" ")} />
            <Text className={["text-[11.5px] font-semibold", isMine ? "text-white" : "text-ink"].join(" ")}>
              {message.durationLabel}
            </Text>
          </View>
        ) : (
          <View className="flex-row items-center gap-[10px]">
            <FileIcon size={18} color={isMine ? "#fff" : "#14162B"} />
            <Text className={["text-[13.5px] font-semibold", isMine ? "text-white" : "text-ink"].join(" ")}>
              {message.fileName}
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}
