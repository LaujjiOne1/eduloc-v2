import { type Href, useRouter } from "expo-router";
import { useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { TutorBottomNav } from "@/components/ui/tutor-bottom-nav";
import { TutorScheduleStrip } from "@/components/ui/tutor-schedule-strip";
import { useTutorAvailability } from "@/hooks/use-tutor-availability";
import { useTutorBookings } from "@/hooks/use-tutor-bookings";
import type { Booking } from "@/types/booking";
import type { TutorAvailabilitySlot } from "@/types/availability";

const NEW_AVAILABILITY_ROUTE = "/tutor-dashboard/calendar/availability/new" as Href;

function editAvailabilityRoute(id: string): Href {
  return `/tutor-dashboard/calendar/availability/${id}` as Href;
}

type DayItem =
  | { kind: "booking"; startTime: string; booking: Booking }
  | { kind: "availability"; startTime: string; entry: TutorAvailabilitySlot };

type Day = { date: string; dateLabel: string; items: DayItem[] };

function groupByDay(bookings: Booking[], availability: TutorAvailabilitySlot[]): Day[] {
  const days = new Map<string, Day>();

  for (const booking of bookings) {
    if (booking.status !== "confirmed") continue;
    const day = days.get(booking.slot.date) ?? {
      date: booking.slot.date,
      dateLabel: booking.slot.dateLabel,
      items: [],
    };
    day.items.push({ kind: "booking", startTime: booking.slot.startTime, booking });
    days.set(booking.slot.date, day);
  }

  for (const entry of availability) {
    const day = days.get(entry.date) ?? {
      date: entry.date,
      dateLabel: entry.dateLabel,
      items: [],
    };
    day.items.push({ kind: "availability", startTime: entry.startTime, entry });
    days.set(entry.date, day);
  }

  return [...days.values()]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((day) => ({
      ...day,
      items: day.items.sort((a, b) => a.startTime.localeCompare(b.startTime)),
    }));
}

function formatDateIso(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function CalendarScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state: bookingsState, retry: retryBookings } = useTutorBookings();
  const { state: availabilityState, retry: retryAvailability } = useTutorAvailability();

  const [selectedDateIso, setSelectedDateIso] = useState<string>(() => formatDateIso(new Date()));

  const isLoading = bookingsState.status === "loading" || availabilityState.status === "loading";
  const error =
    bookingsState.status === "error"
      ? bookingsState.message
      : availabilityState.status === "error"
      ? availabilityState.message
      : null;

  const rawBookings = bookingsState.status === "success" ? bookingsState.bookings : [];
  const rawAvailability = availabilityState.status === "success" ? availabilityState.availability : [];

  const days = groupByDay(rawBookings, rawAvailability);
  const selectedDay = days.find((d) => d.date === selectedDateIso) ?? null;
  const otherDays = days.filter((d) => d.date !== selectedDateIso);

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <View className="px-5 pb-3">
        <Text className="text-[25px] font-bold text-ink">Mon calendrier</Text>
        <Text className="mt-1 text-[13.5px] text-ink-soft">
          Consultez et gérez vos disponibilités et vos rendez-vous de cours
        </Text>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        {/* TutorScheduleStrip: Exactly as in Dashboard Home screen */}
        <FadeIn delay={20}>
          <TutorScheduleStrip
            availability={rawAvailability}
            bookings={rawBookings}
            selectedDate={selectedDateIso}
            onSelectDate={(iso) => setSelectedDateIso(iso)}
            showOpenBadge={false}
            onNewEventPress={() => router.push(NEW_AVAILABILITY_ROUTE)}
          />
        </FadeIn>

        {isLoading ? (
          <View className="gap-3 pt-2">
            {[0, 1].map((i) => (
              <View key={i} className="h-[96px] rounded-xl bg-line-soft" />
            ))}
          </View>
        ) : error ? (
          <View className="flex-row items-center gap-3 py-4">
            <Text className="flex-1 text-[13.5px] text-error">{error}</Text>
            <PressableScale
              onPress={() => {
                retryBookings();
                retryAvailability();
              }}
              accessibilityLabel="Réessayer"
            >
              <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
            </PressableScale>
          </View>
        ) : (
          <View className="pt-1">
            {/* Selected Date Details */}
            {selectedDay ? (
              <FadeIn delay={40}>
                <View className="mb-5">
                  <View className="flex-row items-center justify-between mb-2.5">
                    <Text className="text-[13px] font-bold uppercase tracking-wider text-ink-soft">
                      Programme du jour • {selectedDay.dateLabel}
                    </Text>
                    <PressableScale onPress={() => router.push(NEW_AVAILABILITY_ROUTE)}>
                      <Text className="text-[12.5px] font-bold text-primary">+ Créneau</Text>
                    </PressableScale>
                  </View>
                  <DayCard
                    day={selectedDay}
                    onEditAvailability={(id) => router.push(editAvailabilityRoute(id))}
                  />
                </View>
              </FadeIn>
            ) : (
              <FadeIn delay={40}>
                <View className="mb-6 rounded-2xl border border-line bg-surface p-5 items-center text-center">
                  <Text className="text-[15px] font-bold text-ink">Aucun créneau ce jour</Text>
                  <Text className="mt-1 text-[13px] text-ink-soft text-center max-w-[280px]">
                    Vous n&apos;avez pas encore de disponibilité ni de cours prévu pour cette date.
                  </Text>
                  <View className="mt-3.5">
                    <Button
                      label="Ajouter un créneau ce jour"
                      size="sm"
                      onPress={() => router.push(NEW_AVAILABILITY_ROUTE)}
                    />
                  </View>
                </View>
              </FadeIn>
            )}

            {/* Other Scheduled Days */}
            {otherDays.length > 0 ? (
              <View className="mt-2">
                <Text className="text-[13px] font-bold uppercase tracking-wider text-ink-soft mb-3">
                  Autres dates planifiées ({otherDays.length})
                </Text>
                {otherDays.map((day) => (
                  <DayCard
                    key={day.date}
                    day={day}
                    onEditAvailability={(id) => router.push(editAvailabilityRoute(id))}
                  />
                ))}
              </View>
            ) : null}
          </View>
        )}
      </ScrollView>

      <TutorBottomNav active="calendar" />
    </View>
  );
}

function DayCard({
  day,
  onEditAvailability,
}: {
  day: Day;
  onEditAvailability: (id: string) => void;
}) {
  return (
    <View className="mb-3 rounded-2xl border border-line bg-surface p-4 shadow-2xs">
      <View className="flex-row items-center justify-between mb-2">
        <Text className="text-[15px] font-bold text-ink">{day.dateLabel}</Text>
        <Text className="text-[12px] font-medium text-ink-soft">
          {day.items.length} {day.items.length > 1 ? "créneaux / cours" : "créneau"}
        </Text>
      </View>

      <View className="divide-y divide-line-soft">
        {day.items.map((item, index) => (
          <ItemRow key={index} item={item} onEditAvailability={onEditAvailability} />
        ))}
      </View>
    </View>
  );
}

function ItemRow({
  item,
  onEditAvailability,
}: {
  item: DayItem;
  onEditAvailability: (id: string) => void;
}) {
  if (item.kind === "booking") {
    return (
      <View className="flex-row items-center gap-[10px] py-2.5">
        <View className="w-[58px] rounded-md bg-accent-tint px-2 py-1 items-center">
          <Text className="text-[12.5px] font-bold text-accent">{item.startTime}</Text>
        </View>
        <View className="flex-1">
          <Text className="text-[13.5px] font-bold text-ink" numberOfLines={1}>
            {item.booking.offer.subjectLabel} — {item.booking.beneficiary.firstName}
          </Text>
          <Text className="text-[11.5px] text-ink-faint">Rendez-vous confirmé</Text>
        </View>
        <StatusBadge status="confirmed" />
      </View>
    );
  }

  return (
    <PressableScale
      onPress={() => onEditAvailability(item.entry.id)}
      accessibilityLabel={`Modifier la disponibilité de ${item.startTime}`}
    >
      <View className="flex-row items-center gap-[10px] py-2.5 hover:bg-slate-50 transition-colors rounded-lg px-1">
        <View className="w-[58px] rounded-md bg-primary-tint px-2 py-1 items-center">
          <Text className="text-[12.5px] font-bold text-primary">{item.startTime}</Text>
        </View>
        <View className="flex-1">
          <Text className="text-[13.5px] font-semibold text-ink">Créneau disponible</Text>
          <Text className="text-[11.5px] text-ink-faint">
            {item.entry.formats?.length ? item.entry.formats.join(", ") : "Disponible"}
          </Text>
        </View>
        <Text className="text-[12px] font-bold text-primary">Modifier →</Text>
      </View>
    </PressableScale>
  );
}
