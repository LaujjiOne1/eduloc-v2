import { type Href, useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  ClockIcon,
  HouseIcon,
  PlusIcon,
  VideoIcon,
  XIcon,
} from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { AvailabilityCalendar } from "@/components/ui/availability-calendar";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { FormError } from "@/components/ui/form-error";
import { type SelectOption, SelectField } from "@/components/ui/select-field";
import { TimeWheelPicker } from "@/components/ui/time-wheel-picker";
import { useAvailabilityActions } from "@/hooks/use-availability-actions";
import { useAvailabilityDetail } from "@/hooks/use-availability-detail";
import { useTutorProfile } from "@/hooks/use-tutor-profile";
import type { LocationFormatId } from "@/types/search";
import { formatDayLabel } from "@/utils/calendar";

const CALENDAR_ROUTE = "/tutor-dashboard/calendar" as Href;

type ConfiguredSlot = {
  id: string;
  startTime: string;
  endTime: string;
};

export function AvailabilityEditScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const isEditMode = !!id;

  const { state: detailState } = useAvailabilityDetail(id);
  const { state: profileState } = useTutorProfile();
  const { state: actionState, save, saveAll, remove } = useAvailabilityActions();

  // Date selection state
  const todayIso = useMemo(() => new Date().toISOString().split("T")[0], []);
  const [selectedDate, setSelectedDate] = useState<string>(todayIso);
  const [selectedDateLabel, setSelectedDateLabel] = useState<string>(formatDayLabel(todayIso));

  // Time wheel state (Start and End side by side)
  const [startTime, setStartTime] = useState<string>("09:00");
  const [endTime, setEndTime] = useState<string>("10:00");

  // Configured slots for this date (added via the top-right + button)
  const [configuredSlots, setConfiguredSlots] = useState<ConfiguredSlot[]>([]);
  const [slotError, setSlotError] = useState<string | null>(null);

  // Format selection with CHECKBOXES
  const [inPersonChecked, setInPersonChecked] = useState<boolean>(true);
  const [onlineChecked, setOnlineChecked] = useState<boolean>(false);

  // Location selector (when Présentiel is checked)
  const [locationOption, setLocationOption] = useState<SelectOption | null>(null);

  // Seed form in edit mode
  useEffect(() => {
    if (detailState.status !== "success") return;
    const entry = detailState.entry;
    setSelectedDate(entry.date);
    setSelectedDateLabel(entry.dateLabel);
    setStartTime(entry.startTime);
    setEndTime(entry.endTime);
    setConfiguredSlots([
      {
        id: entry.id,
        startTime: entry.startTime,
        endTime: entry.endTime,
      },
    ]);

    setInPersonChecked(entry.format === "in_person" || entry.format === "both");
    setOnlineChecked(entry.format === "online" || entry.format === "both");

    if (entry.locationLabel) {
      setLocationOption({ id: entry.locationLabel, label: entry.locationLabel });
    }
  }, [detailState]);

  // Locations registered by the tutor
  const locations = profileState.status === "success" ? profileState.profile.locations : [];
  const needsLocation = inPersonChecked;

  // Compute effective format
  const effectiveFormat: LocationFormatId | null =
    inPersonChecked && onlineChecked
      ? "both"
      : inPersonChecked
      ? "in_person"
      : onlineChecked
      ? "online"
      : null;

  // Add slot handler (+ button in top right of time section)
  const handleAddSlot = () => {
    setSlotError(null);
    if (!startTime || !endTime) {
      setSlotError("Veuillez sélectionner une heure de début et de fin.");
      return;
    }
    if (startTime >= endTime) {
      setSlotError("L'heure de fin doit être postérieure à l'heure de début.");
      return;
    }

    const duplicate = configuredSlots.some(
      (s) => s.startTime === startTime && s.endTime === endTime
    );
    if (duplicate) {
      setSlotError("Ce créneau horaire a déjà été ajouté.");
      return;
    }

    const newSlot: ConfiguredSlot = {
      id: `slot-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      startTime,
      endTime,
    };
    setConfiguredSlots((prev) => [...prev, newSlot]);

    // Advance wheel to next hour for convenience
    const [endH] = endTime.split(":");
    const nextStartH = Math.min(22, Number(endH));
    const nextEndH = Math.min(23, nextStartH + 1);
    const pad = (n: number) => String(n).padStart(2, "0");
    setStartTime(`${pad(nextStartH)}:00`);
    setEndTime(`${pad(nextEndH)}:00`);
  };

  const handleRemoveSlot = (slotId: string) => {
    setConfiguredSlots((prev) => prev.filter((s) => s.id !== slotId));
    setSlotError(null);
  };

  // Determine if valid to submit
  const hasValidTime =
    configuredSlots.length > 0 || (!!startTime && !!endTime && startTime < endTime);

  const canSubmit =
    !!selectedDate &&
    hasValidTime &&
    !!effectiveFormat &&
    (!needsLocation || !!locationOption);

  const isSaving = actionState.status === "saving";
  const isDeleting = actionState.status === "deleting";

  const handleSave = async () => {
    if (!canSubmit || !selectedDate || !effectiveFormat) return;

    // Slots to save: either the configured slots list or the active wheel slot
    const slotsToSave: { startTime: string; endTime: string }[] =
      configuredSlots.length > 0
        ? configuredSlots
        : [{ startTime, endTime }];

    if (isEditMode && id) {
      // In edit mode, update the single existing entry
      const firstSlot = slotsToSave[0];
      const entry = await save(id, {
        date: selectedDate,
        dateLabel: selectedDateLabel,
        startTime: firstSlot.startTime,
        endTime: firstSlot.endTime,
        format: effectiveFormat,
        locationLabel: needsLocation ? (locationOption?.label ?? null) : null,
      });
      if (entry) router.replace(CALENDAR_ROUTE);
    } else {
      // In create mode, save all configured slots for this date
      const drafts = slotsToSave.map((s) => ({
        date: selectedDate,
        dateLabel: selectedDateLabel,
        startTime: s.startTime,
        endTime: s.endTime,
        format: effectiveFormat,
        locationLabel: needsLocation ? (locationOption?.label ?? null) : null,
      }));

      const ok = await saveAll(drafts);
      if (ok) router.replace(CALENDAR_ROUTE);
    }
  };

  const handleDelete = async () => {
    if (!isEditMode || !id) return;
    const ok = await remove(id);
    if (ok) router.replace(CALENDAR_ROUTE);
  };

  const isLoadingDetail =
    (isEditMode && detailState.status === "loading") || profileState.status === "loading";
  const detailError =
    isEditMode && detailState.status === "error" ? detailState.message : null;

  // Format label for bottom summary
  const formatSummaryText =
    inPersonChecked && onlineChecked
      ? "Présentiel & En ligne"
      : inPersonChecked
      ? "Présentiel"
      : onlineChecked
      ? "En ligne"
      : "Format non choisi";

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      {isLoadingDetail ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator color="#332E86" />
        </View>
      ) : detailError ? (
        <View className="flex-1 items-center justify-center px-8">
          <Text className="text-center text-[14px] text-error">{detailError}</Text>
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{
            paddingHorizontal: 20,
            paddingBottom: Math.max(insets.bottom + 90, 110),
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Title Header */}
          <FadeIn delay={20}>
            <View className="mb-5 pt-1">
              <Text className="text-[25px] font-bold text-ink">
                {isEditMode ? "Modifier la disponibilité" : "Ajouter des disponibilités"}
              </Text>
              <Text className="mt-1 text-[13.5px] text-ink-soft">
                Définissez les dates, plages horaires et formats où vous pouvez enseigner
              </Text>
            </View>
          </FadeIn>

          {actionState.status === "error" ? (
            <View className="mb-4">
              <FormError message={actionState.message} />
            </View>
          ) : null}

          {/* Side-by-side or stacked layout matching user's design image */}
          <View className="flex-col lg:flex-row gap-5">
            {/* Left Section: Interactive Calendar */}
            <View className="flex-1 min-w-[300px]">
              <FadeIn delay={40}>
                <View className="mb-2 flex-row items-center justify-between">
                  <Text className="text-[14.5px] font-bold text-ink">1. Date</Text>
                  <Text className="text-[12.5px] font-medium text-primary">
                    {selectedDateLabel}
                  </Text>
                </View>
                <AvailabilityCalendar
                  selectedDate={selectedDate}
                  onSelectDate={(date, label) => {
                    setSelectedDate(date);
                    setSelectedDateLabel(label);
                  }}
                  minDate={todayIso}
                  onNewEventPress={handleAddSlot}
                />
              </FadeIn>
            </View>

            {/* Right Section: Time Wheels + Plus Button + Configured Slots */}
            <View className="flex-1 min-w-[300px]">
              <FadeIn delay={60}>
                {/* Header with Title and Plus Button in the top right */}
                <View className="mb-2 flex-row items-center justify-between">
                  <View className="flex-row items-center gap-1.5">
                    <Text className="text-[14.5px] font-bold text-ink">
                      2. Plage horaire (roue)
                    </Text>
                    <ClockIcon size={14} color="#9799AF" />
                  </View>

                  {/* Plus button at the top right */}
                  <PressableScale
                    onPress={handleAddSlot}
                    accessibilityLabel="Ajouter ce créneau horaire"
                    className="flex-row items-center gap-1.5 rounded-xl bg-primary px-3 py-1.5 shadow-2xs hover:bg-primary-strong active:scale-95"
                  >
                    <PlusIcon size={14} color="#ffffff" />
                    <Text className="text-[12.5px] font-bold text-white">Ajouter</Text>
                  </PressableScale>
                </View>

                {/* Time Wheel Picker: Start Time & End Time side by side */}
                <TimeWheelPicker
                  startTime={startTime}
                  endTime={endTime}
                  onChangeStart={(t) => {
                    setStartTime(t);
                    setSlotError(null);
                  }}
                  onChangeEnd={(t) => {
                    setEndTime(t);
                    setSlotError(null);
                  }}
                />

                {/* Error message for invalid time */}
                {slotError || (startTime && endTime && startTime >= endTime) ? (
                  <Text className="mt-2 text-[12.5px] font-medium text-error">
                    {slotError ?? "L'heure de fin doit être après l'heure de début."}
                  </Text>
                ) : null}

                {/* List of configured slots for this day (matching the image slots column) */}
                {configuredSlots.length > 0 ? (
                  <View className="mt-4 rounded-xl border border-line bg-surface p-3.5 shadow-2xs">
                    <Text className="mb-2.5 text-[12px] font-bold text-ink-soft uppercase tracking-wider">
                      Créneaux programmés pour le {selectedDateLabel} ({configuredSlots.length})
                    </Text>
                    <View className="gap-2">
                      {configuredSlots.map((slot) => (
                        <View
                          key={slot.id}
                          className="flex-row items-center justify-between rounded-lg border border-line-soft bg-paper px-3 py-2.5 hover:border-primary/30"
                        >
                          <View className="flex-row items-center gap-2">
                            <View className="h-6 w-6 items-center justify-center rounded-md bg-primary-tint">
                              <ClockIcon size={12} color="#332E86" />
                            </View>
                            <Text className="text-[14px] font-bold text-ink tabular-nums">
                              {slot.startTime} → {slot.endTime}
                            </Text>
                          </View>

                          <PressableScale
                            onPress={() => handleRemoveSlot(slot.id)}
                            accessibilityLabel={`Supprimer le créneau ${slot.startTime} à ${slot.endTime}`}
                            className="h-7 w-7 items-center justify-center rounded-md text-ink-faint hover:bg-error-tint hover:text-error"
                          >
                            <XIcon size={14} color="#DE3B40" />
                          </PressableScale>
                        </View>
                      ))}
                    </View>
                  </View>
                ) : null}
              </FadeIn>
            </View>
          </View>

          {/* Format Section with CHECKBOXES (au lieu de radio) */}
          <FadeIn delay={80}>
            <View className="mt-6 rounded-2xl border border-line bg-surface p-4 sm:p-5 shadow-2xs">
              <Text className="mb-3 text-[14.5px] font-bold text-ink">
                3. Format de cours (sélection multiple)
              </Text>

              <View className="flex-col sm:flex-row gap-3">
                <Checkbox
                  checked={inPersonChecked}
                  onCheckedChange={setInPersonChecked}
                  label="Présentiel"
                  description="Cours en face-à-face avec l'élève"
                  icon={<HouseIcon size={18} color="#332E86" />}
                />

                <Checkbox
                  checked={onlineChecked}
                  onCheckedChange={setOnlineChecked}
                  label="En ligne"
                  description="Séance à distance par visioconférence"
                  icon={<VideoIcon size={18} color="#0E9C82" />}
                />
              </View>

              {!inPersonChecked && !onlineChecked ? (
                <Text className="mt-2 text-[12.5px] font-medium text-error">
                  Veuillez cocher au moins un format (Présentiel et/ou En ligne).
                </Text>
              ) : null}

              {/* Lieu de cours (si Présentiel coché) */}
              {needsLocation ? (
                <View className="mt-4 pt-4 border-t border-line-soft">
                  <SelectField
                    label="Lieu d'enseignement (Présentiel)"
                    value={locationOption}
                    options={locations}
                    placeholder={
                      locations.length ? "Sélectionnez un lieu" : "Aucun lieu enregistré dans votre profil"
                    }
                    disabled={locations.length === 0}
                    onSelect={setLocationOption}
                  />
                  {locations.length === 0 ? (
                    <Text className="mt-1 text-[12px] text-ink-faint">
                      Ajoutez des lieux d&apos;intervention dans vos paramètres pour les sélectionner ici.
                    </Text>
                  ) : null}
                </View>
              ) : null}
            </View>
          </FadeIn>
        </ScrollView>
      )}

      {/* Sticky Bottom Summary Bar matching image.png */}
      <View
        className="absolute bottom-0 left-0 right-0 border-t border-line bg-surface/95 px-5 py-3.5 backdrop-blur-md shadow-lg"
        style={{ paddingBottom: Math.max(insets.bottom, 16) }}
      >
        <View className="flex-col sm:flex-row items-center justify-between gap-3 max-w-4xl mx-auto w-full">
          {/* Summary text */}
          <View className="flex-1">
            <Text className="text-[13px] text-ink-soft" numberOfLines={2}>
              Disponibilité pour le{" "}
              <Text className="font-bold text-ink">{selectedDateLabel}</Text>
              {" • "}
              <Text className="font-semibold text-primary">
                {configuredSlots.length > 0
                  ? `${configuredSlots.length} créneau(x)`
                  : `${startTime} à ${endTime}`}
              </Text>
              {" • "}
              <Text className="font-medium text-ink-faint">{formatSummaryText}</Text>
            </Text>
          </View>

          {/* Action buttons */}
          <View className="flex-row items-center gap-2.5 w-full sm:w-auto">
            {isEditMode ? (
              <Button
                label="Supprimer"
                variant="ghost"
                disabled={isSaving || isDeleting}
                loading={isDeleting}
                loadingLabel="Suppression..."
                onPress={handleDelete}
              />
            ) : null}

            <Button
              label={
                isEditMode
                  ? "Enregistrer les modifications"
                  : configuredSlots.length > 1
                  ? `Enregistrer (${configuredSlots.length} créneaux)`
                  : "Enregistrer la disponibilité"
              }
              disabled={!canSubmit || isSaving || isDeleting}
              loading={isSaving}
              loadingLabel="Enregistrement..."
              onPress={handleSave}
            />
          </View>
        </View>
      </View>
    </View>
  );
}
