import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ChevronRightIcon, MessageSquareIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { StatusBadge } from "@/components/ui/status-badge";
import { TutorBottomNav } from "@/components/ui/tutor-bottom-nav";
import { useTutorBookings } from "@/hooks/use-tutor-bookings";
import type { Booking } from "@/types/booking";

function conversationRoute(id: string): Href {
  return `/tutor-dashboard/appointments/${id}/conversation` as Href;
}

export function TutorConversationsListScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state } = useTutorBookings();

  // Active bookings with students eligible for conversation
  const bookings =
    state.status === "success"
      ? state.bookings.filter((b) => b.status !== "cancelled" && b.status !== "refused")
      : [];

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <View className="px-5 pb-3">
        <FadeIn delay={30}>
          <Text className="text-[25px] font-bold text-ink">Conversations</Text>
          <Text className="mt-1 text-[13.5px] text-ink-soft">
            Échangez des messages vocaux et des documents avec vos élèves
          </Text>
        </FadeIn>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: Math.max(insets.bottom + 20, 30),
        }}
        showsVerticalScrollIndicator={false}
      >
        {state.status === "loading" ? (
          <View className="gap-3 pt-2">
            {[0, 1, 2].map((i) => (
              <View key={i} className="h-[84px] rounded-xl bg-line-soft" />
            ))}
          </View>
        ) : state.status === "error" ? (
          <FadeIn delay={40}>
            <View className="items-center rounded-2xl border border-line bg-surface p-8 text-center my-6">
              <Text className="text-[14px] text-error">{state.message}</Text>
            </View>
          </FadeIn>
        ) : bookings.length === 0 ? (
          <FadeIn delay={60}>
            <View className="items-center rounded-2xl border border-line bg-surface p-8 text-center my-6">
              <View className="h-14 w-14 items-center justify-center rounded-full bg-primary-tint mb-3">
                <MessageSquareIcon size={26} color="#332E86" />
              </View>
              <Text className="text-[16px] font-bold text-ink">Aucune conversation</Text>
              <Text className="mt-1.5 text-center text-[13px] leading-5 text-ink-soft max-w-[280px]">
                Vous pourrez échanger avec vos élèves dès qu&apos;une demande de cours ou un rendez-vous sera accepté.
              </Text>
            </View>
          </FadeIn>
        ) : (
          <View className="gap-3 pt-1">
            {bookings.map((booking, index) => (
              <FadeIn key={booking.id} delay={50 + index * 30}>
                <ConversationRow
                  booking={booking}
                  onPress={() => router.push(conversationRoute(booking.id))}
                />
              </FadeIn>
            ))}
          </View>
        )}
      </ScrollView>

      <TutorBottomNav active="conversations" />
    </View>
  );
}

function ConversationRow({
  booking,
  onPress,
}: {
  booking: Booking;
  onPress: () => void;
}) {
  const initials = booking.beneficiary.firstName.slice(0, 2).toUpperCase();

  return (
    <PressableScale
      onPress={onPress}
      accessibilityLabel={`Conversation avec ${booking.beneficiary.firstName}`}
      accessibilityRole="button"
    >
      <View className="flex-row items-center gap-3.5 rounded-2xl border border-line bg-surface p-4 shadow-2xs hover:border-primary/40 transition-colors">
        {/* Avatar */}
        <View className="h-12 w-12 items-center justify-center rounded-full bg-primary-tint flex-shrink-0">
          <Text className="text-[15px] font-bold text-primary">{initials}</Text>
        </View>

        {/* Info */}
        <View className="flex-1 min-w-0">
          <View className="flex-row items-center justify-between gap-2 mb-1">
            <Text className="text-[15px] font-bold text-ink truncate">
              {booking.beneficiary.firstName}
            </Text>
            <StatusBadge status={booking.status} />
          </View>

          <Text className="text-[13px] text-ink-soft truncate font-medium">
            {booking.offer.title}
          </Text>

          <Text className="mt-1 text-[11.5px] text-ink-faint">
            {booking.slot.dateLabel} • {booking.slot.startTime}
          </Text>
        </View>

        {/* Chevron */}
        <View className="flex-shrink-0 text-ink-faint">
          <ChevronRightIcon size={18} color="#9799AF" />
        </View>
      </View>
    </PressableScale>
  );
}
