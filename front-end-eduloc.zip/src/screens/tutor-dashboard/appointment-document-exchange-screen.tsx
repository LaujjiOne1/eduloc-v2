import { useLocalSearchParams, useRouter } from "expo-router";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AttachIcon, FileIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/ui/form-error";
import { useConversationMessages } from "@/hooks/use-conversation-messages";
import { useSendMessage } from "@/hooks/use-send-message";
import type { ConversationMessage } from "@/types/message";

// No document-picker dependency is installed yet (see AGENTS.md §7) — this
// rotates through canned picks until one is added; the screen/hook won't
// need to change then, only ConversationService.sendDocument's mock body.
const MOCK_PICKS = [
  { fileName: "fiche-exercices.pdf", fileSizeLabel: "1.2 Mo" },
  { fileName: "corrige-devoir.pdf", fileSizeLabel: "850 Ko" },
  { fileName: "support-cours.pdf", fileSizeLabel: "3.0 Mo" },
];

export function TutorDocumentExchangeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { state: messagesState } = useConversationMessages(id);
  const { state: sendState, sendDocument } = useSendMessage();

  const isSending = sendState.status === "sending";
  const documents = messagesState.status === "success" ? messagesState.messages.filter((m) => m.type === "document") : [];

  const handleAddDocument = async () => {
    if (!id) return;
    const pick = MOCK_PICKS[Math.floor(Math.random() * MOCK_PICKS.length)];
    const message = await sendDocument(id, pick.fileName, pick.fileSizeLabel);
    if (message) router.back();
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <Text className="px-5 pb-4 text-[22px] font-bold text-ink">Documents partagés</Text>

      <ScrollView className="flex-1" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }} showsVerticalScrollIndicator={false}>
        {messagesState.status === "loading" ? (
          <View className="items-center py-10">
            <ActivityIndicator color="#332E86" />
          </View>
        ) : messagesState.status === "error" ? (
          <Text className="text-center text-[13.5px] text-error">{messagesState.message}</Text>
        ) : documents.length === 0 ? (
          <View className="items-center py-10">
            <Text className="text-center text-[13.5px] text-ink-soft">Aucun document partagé pour le moment.</Text>
          </View>
        ) : (
          documents.map((document, index) => (
            <FadeIn key={document.id} delay={40 + index * 40}>
              <DocumentRow document={document} />
            </FadeIn>
          ))
        )}
      </ScrollView>

      <View className="flex-shrink-0 border-t border-line-soft bg-surface px-5 pt-4" style={{ paddingBottom: Math.max(insets.bottom, 22) }}>
        {sendState.status === "error" ? <FormError message={sendState.message} /> : null}
        <Button
          label="Ajouter un document"
          fullWidth
          disabled={isSending}
          loading={isSending}
          loadingLabel="Envoi..."
          icon={<AttachIcon size={17} color="#fff" />}
          onPress={handleAddDocument}
        />
      </View>
    </View>
  );
}

function DocumentRow({ document }: { document: ConversationMessage }) {
  return (
    <View className="mb-[10px] flex-row items-center gap-3 rounded-lg border border-line bg-surface p-4">
      <View className="h-10 w-10 items-center justify-center rounded-md bg-primary-tint">
        <FileIcon size={18} color="#332E86" />
      </View>
      <View className="flex-1">
        <Text className="text-[14px] font-bold text-ink">{document.fileName}</Text>
        <Text className="mt-[2px] text-[12px] text-ink-soft">
          {document.authorLabel} • {document.fileSizeLabel}
        </Text>
      </View>
    </View>
  );
}
