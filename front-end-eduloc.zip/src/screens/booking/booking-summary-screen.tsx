import { type Href, useRouter } from "expo-router";
import type { ReactNode } from "react";
import { useEffect } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CalendarIcon, ClockIcon, HouseIcon, LocationIcon, MicIcon, VideoIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/ui/form-error";
import { StepProgress } from "@/components/ui/step-progress";
import { useCreateBooking } from "@/hooks/use-create-booking";
import { useBookingWizardStore } from "@/store/booking-wizard.store";
import { useSearchWizardStore } from "@/store/search-wizard.store";

const BOOKING_PENDING_ROUTE = "/booking-pending" as Href;
const BOOK_DATE_ROUTE = "/results/book" as Href;

const FORMAT_LABELS: Record<string, string> = { in_person: "Présentiel", online: "En ligne" };

export function BookingSummaryScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const offer = useBookingWizardStore((s) => s.offer);
  const slot = useBookingWizardStore((s) => s.slot);
  const beneficiary = useBookingWizardStore((s) => s.beneficiary);
  const difficulty = useBookingWizardStore((s) => s.difficulty);
  const setCreatedBookingId = useBookingWizardStore((s) => s.setCreatedBookingId);
  const note = useSearchWizardStore((s) => s.criteria.detail.note);
  const { state, submit } = useCreateBooking();

  // Guard: a full recap needs an offer, a slot, and a named beneficiary with
  // a level — i.e. BookDate + Beneficiary must both be completed already.
  const hasContext = !!offer && !!slot && beneficiary.firstName.trim().length > 0 && !!beneficiary.level;

  useEffect(() => {
    if (!hasContext) router.replace("/home");
  }, [hasContext, router]);

  if (!hasContext || !offer || !slot || !beneficiary.level) return null;

  const isSubmitting = state.status === "loading";
  const primaryFormat = offer.formats[0];
  const FormatIcon = primaryFormat === "online" ? VideoIcon : HouseIcon;

  const sendRequest = async () => {
    if (isSubmitting) return;
    const booking = await submit({
      offerId: offer.id,
      slotId: slot.id,
      beneficiary: {
        firstName: beneficiary.firstName.trim(),
        lastName: beneficiary.lastName.trim(),
        relationLabel: beneficiary.relation?.label ?? null,
        level: beneficiary.level!,
        difficulty: difficulty.trim(),
      },
      note,
    });
    if (booking) {
      setCreatedBookingId(booking.id);
      router.push(BOOKING_PENDING_ROUTE);
    }
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={3} total={3} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-[18px] text-[24px] font-bold text-ink">Votre demande</Text>
        </FadeIn>

        <FadeIn delay={80}>
          <View className="rounded-lg border border-line bg-surface p-4">
            <SummaryRow label="Tuteur" value={offer.tutorName} />
            <Divider />
            <SummaryRow label="Cours" value={offer.title} />
            <Divider />
            <SummaryRow label="Bénéficiaire" value={beneficiary.firstName} />
            <Divider />
            <SummaryRow label="Date" value={slot.dateLabel} icon={<CalendarIcon size={15} color="#9799AF" />} />
            <Divider />
            <SummaryRow label="Horaire" value={slot.timeRangeLabel} icon={<ClockIcon size={15} color="#9799AF" />} />
            <Divider />
            <SummaryRow label="Lieu" value={offer.location} icon={<LocationIcon size={15} color="#9799AF" />} />
            <Divider />
            <SummaryRow
              label="Format"
              value={FORMAT_LABELS[primaryFormat] ?? primaryFormat}
              icon={<FormatIcon size={15} color="#9799AF" />}
            />
          </View>
        </FadeIn>

        <FadeIn delay={120}>
          <View className="mt-[14px] flex-row items-center gap-3 rounded-lg border border-line bg-surface p-4">
            <View className="h-9 w-9 items-center justify-center rounded-full bg-accent-tint">
              <MicIcon size={16} color="#0E9C82" />
            </View>
            <View className="flex-1">
              <Text className="text-[12px] text-ink-soft">Besoin</Text>
              <Text className="text-[14px] font-bold text-ink" numberOfLines={2}>
                {note.trim() ? note.trim() : "Aucune précision ajoutée"}
              </Text>
            </View>
          </View>
        </FadeIn>

        <FadeIn delay={150}>
          <PressableScale onPress={() => router.push(BOOK_DATE_ROUTE)} accessibilityLabel="Modifier la date et l'heure">
            <Text className="mt-4 text-center text-[14px] font-bold text-primary">Modifier</Text>
          </PressableScale>
        </FadeIn>

        {state.status === "error" ? (
          <View className="mt-4">
            <FormError message={state.message} />
          </View>
        ) : null}
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label="Envoyer la demande"
          loading={isSubmitting}
          loadingLabel="Envoi..."
          disabled={isSubmitting}
          onPress={sendRequest}
        />
      </View>
    </View>
  );
}

function Divider() {
  return <View className="h-px bg-line-soft" />;
}

function SummaryRow({ label, value, icon }: { label: string; value: string; icon?: ReactNode }) {
  return (
    <View className="flex-row items-center justify-between py-[11px]">
      <Text className="text-[13.5px] text-ink-soft">{label}</Text>
      <View className="flex-row items-center gap-[6px]">
        <Text className="text-[14px] font-bold text-ink">{value}</Text>
        {icon}
      </View>
    </View>
  );
}
