import { type Href, useFocusEffect, useRouter } from "expo-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CheckIcon, ChevronRightIcon, ClockIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/store/auth.store";
import { useBookingWizardStore } from "@/store/booking-wizard.store";
import type { OfferSlot } from "@/types/offer";
import { type CalendarCell, addMonths, buildCalendarMonth, yearMonthFromIsoDate } from "@/utils/calendar";

// Existing routes — Login already exists (src/app/login.tsx); Beneficiary is
// built by this same task (src/app/beneficiary.tsx).
const LOGIN_ROUTE = "/login" as Href;
const BENEFICIARY_ROUTE = "/beneficiary" as Href;

const WEEKDAY_LABELS = ["L", "M", "M", "J", "V", "S", "D"];
const EMPTY_SLOTS: OfferSlot[] = [];

function lowerFirst(text: string): string {
  return text ? `${text.charAt(0).toLowerCase()}${text.slice(1)}` : text;
}

export function BookDateScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const offer = useBookingWizardStore((s) => s.offer);
  const preselectedSlot = useBookingWizardStore((s) => s.slot);
  const setBooking = useBookingWizardStore((s) => s.setBooking);

  const initialDate = preselectedSlot?.date ?? offer?.slots[0]?.date ?? null;
  const [selectedDate, setSelectedDate] = useState<string | null>(initialDate);
  const [selectedSlotId, setSelectedSlotId] = useState<string | null>(
    preselectedSlot?.id ?? offer?.slots[0]?.id ?? null,
  );
  const [viewedMonth, setViewedMonth] = useState(() =>
    yearMonthFromIsoDate(initialDate ?? new Date().toISOString().slice(0, 10)),
  );
  const [isNavigating, setIsNavigating] = useState(false);

  useFocusEffect(
    useCallback(() => {
      setIsNavigating(false);
    }, []),
  );

  const slots = offer?.slots ?? EMPTY_SLOTS;
  const availableDates = useMemo(
    () => new Set(slots.filter((s) => s.status === "available").map((s) => s.date)),
    [slots],
  );
  const calendarMonth = useMemo(
    () => buildCalendarMonth(viewedMonth.year, viewedMonth.month, availableDates),
    [viewedMonth, availableDates],
  );
  const daySlots = useMemo(() => slots.filter((s) => s.date === selectedDate), [slots, selectedDate]);
  const selectedSlot = daySlots.find((s) => s.id === selectedSlotId) ?? null;
  const monthHasAvailability = calendarMonth.cells.some((cell) => cell?.hasAvailability);

  // Guard: BookDate only makes sense once an offer has been picked
  // (OfferDetail's "Choisir ce créneau" sets it before navigating here).
  // Reaching this route without that context — e.g. a stale deep link —
  // bounces to Home instead of rendering a broken screen (AGENTS.md §13).
  useEffect(() => {
    if (!offer) router.replace("/home");
  }, [offer, router]);

  if (!offer) return null;

  const canReserve = !!selectedSlot && selectedSlot.status === "available" && !isNavigating;

  const selectDay = (cell: CalendarCell) => {
    if (!cell.hasAvailability) return;
    setSelectedDate(cell.date);
    const firstAvailable = slots.find((s) => s.date === cell.date && s.status === "available");
    setSelectedSlotId(firstAvailable?.id ?? null);
  };

  const reserve = () => {
    if (!canReserve || !selectedSlot) return;
    setIsNavigating(true);
    setBooking(offer, selectedSlot);
    const authenticated = useAuthStore.getState().user !== null;
    router.push(authenticated ? BENEFICIARY_ROUTE : LOGIN_ROUTE);
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Choisissez votre rendez-vous</Text>
          <Text className="mb-[18px] text-[13.5px] text-ink-soft">
            {offer.title} — avec {offer.tutorName}
          </Text>
        </FadeIn>

        <FadeIn delay={80}>
          <View className="rounded-lg border border-line bg-surface px-[14px] py-[18px]">
            <View className="flex-row items-center justify-between px-1 pb-[14px]">
              <PressableScale
                onPress={() => setViewedMonth((m) => addMonths(m.year, m.month, -1))}
                accessibilityLabel="Mois précédent"
              >
                <View style={{ transform: [{ rotate: "180deg" }] }}>
                  <ChevronRightIcon size={16} color="#9799AF" />
                </View>
              </PressableScale>
              <Text className="text-[15px] font-bold text-ink">{calendarMonth.label}</Text>
              <PressableScale
                onPress={() => setViewedMonth((m) => addMonths(m.year, m.month, 1))}
                accessibilityLabel="Mois suivant"
              >
                <ChevronRightIcon size={16} color="#14162B" />
              </PressableScale>
            </View>

            <View className="flex-row">
              {WEEKDAY_LABELS.map((label, i) => (
                <Text
                  key={i}
                  className="flex-1 text-center text-[11.5px] font-bold text-ink-faint"
                  style={{ paddingVertical: 6 }}
                >
                  {label}
                </Text>
              ))}
            </View>

            <View className="flex-row flex-wrap">
              {calendarMonth.cells.map((cell, i) => (
                <View key={i} className="items-center py-[2px]" style={{ width: `${100 / 7}%` }}>
                  {cell ? (
                    <CalendarDayCell cell={cell} selected={cell.date === selectedDate} onPress={() => selectDay(cell)} />
                  ) : (
                    <View style={{ height: 34 }} />
                  )}
                </View>
              ))}
            </View>

            {!monthHasAvailability ? (
              <Text className="mt-2 text-center text-[12.5px] text-ink-faint">
                Aucun créneau disponible ce mois-ci.
              </Text>
            ) : null}
          </View>
        </FadeIn>

        <FadeIn delay={120}>
          <View className="mt-[22px]">
            <Text className="mb-[6px] ml-0.5 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
              Créneaux{selectedDate && daySlots[0] ? ` — ${lowerFirst(daySlots[0].dateLabel)}` : ""}
            </Text>
            {slots.length === 0 ? (
              <Text className="text-[13.5px] text-ink-faint">Aucun créneau disponible pour le moment.</Text>
            ) : daySlots.length === 0 ? (
              <Text className="text-[13.5px] text-ink-faint">
                Sélectionnez une date disponible dans le calendrier.
              </Text>
            ) : (
              <View className="gap-[10px]">
                {daySlots.map((slot) => (
                  <TimeSlotRow
                    key={slot.id}
                    slot={slot}
                    selected={slot.id === selectedSlotId}
                    onPress={() => setSelectedSlotId(slot.id)}
                  />
                ))}
              </View>
            )}
          </View>
        </FadeIn>

        <FadeIn delay={160}>
          <Text className="mt-4 text-[12px] leading-[18px] text-ink-faint">
            La disponibilité est vérifiée par EduLoc en temps réel. Réservation possible jusqu&apos;à 2h avant le
            créneau.
          </Text>
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Réserver ce créneau" disabled={!canReserve} onPress={reserve} />
      </View>
    </View>
  );
}

type CalendarDayCellProps = {
  cell: CalendarCell;
  selected: boolean;
  onPress: () => void;
};

function CalendarDayCell({ cell, selected, onPress }: CalendarDayCellProps) {
  const bgClass = selected ? "bg-primary" : cell.hasAvailability ? "bg-accent-tint" : "bg-transparent";
  const textClass = selected ? "text-white" : cell.hasAvailability ? "text-accent" : "text-ink";

  const content = (
    <View className={["relative h-[34px] w-[34px] items-center justify-center rounded-[10px]", bgClass].join(" ")}>
      <Text className={["text-[14px]", selected ? "font-bold" : "font-medium", textClass].join(" ")}>
        {cell.day}
      </Text>
      {cell.hasAvailability ? (
        <View
          className={["absolute bottom-[3px] h-[4px] w-[4px] rounded-full", selected ? "bg-white" : "bg-accent"].join(
            " ",
          )}
        />
      ) : null}
    </View>
  );

  if (!cell.hasAvailability) return content;

  return (
    <PressableScale onPress={onPress} accessibilityLabel={`Jour ${cell.day}`}>
      {content}
    </PressableScale>
  );
}

type TimeSlotRowProps = {
  slot: OfferSlot;
  selected: boolean;
  onPress: () => void;
};

function TimeSlotRow({ slot, selected, onPress }: TimeSlotRowProps) {
  const booked = slot.status === "booked";

  return (
    <PressableScale
      onPress={onPress}
      disabled={booked}
      accessibilityLabel={`${slot.timeRangeLabel}${booked ? ", créneau pris" : ""}`}
    >
      <View
        className={[
          "flex-row items-center justify-between rounded-lg border p-4",
          !booked && selected ? "border-primary bg-primary-tint" : "border-line bg-surface",
        ].join(" ")}
      >
        <View className="flex-row items-center gap-[10px]">
          <ClockIcon size={16} color={!booked && selected ? "#332E86" : "#585B78"} />
          <Text className="text-[14.5px] font-bold text-ink">{slot.timeRangeLabel}</Text>
        </View>
        {booked ? (
          <Text className="text-[12px] font-semibold text-ink-faint">Pris</Text>
        ) : selected ? (
          <View className="h-5 w-5 items-center justify-center rounded-full bg-primary">
            <CheckIcon size={11} color="#fff" />
          </View>
        ) : (
          <View className="h-5 w-5 rounded-full border-2 border-line" />
        )}
      </View>
    </PressableScale>
  );
}
