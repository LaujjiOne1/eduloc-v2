import { type Href, useFocusEffect, useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { SelectField, type SelectOption } from "@/components/ui/select-field";
import { StepProgress } from "@/components/ui/step-progress";
import { TextField } from "@/components/ui/text-field";
import { useLevels } from "@/hooks/use-levels";
import { useBookingWizardStore } from "@/store/booking-wizard.store";
import { useSearchWizardStore } from "@/store/search-wizard.store";

const BENEFICIARY_PROFILE_ROUTE = "/beneficiary-profile" as Href;

// The spec doesn't define a relation list — a small fixed set covering the
// non-"myself" beneficiary types (child/relative/other) from the search
// wizard, flagged rather than invented as business rule (AGENTS.md §11).
// Exported so 34_Beneficiaries' "Ajouter un bénéficiaire" form (a different
// screen — the standalone address book, not this booking-flow step) reuses
// the same flagged list instead of inventing a second one.
export const RELATION_OPTIONS: SelectOption[] = [
  { id: "son", label: "Mon fils" },
  { id: "daughter", label: "Ma fille" },
  { id: "brother", label: "Mon frère" },
  { id: "sister", label: "Ma sœur" },
  { id: "spouse", label: "Mon conjoint / Ma conjointe" },
  { id: "other", label: "Autre proche" },
];

export function BeneficiaryScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const offer = useBookingWizardStore((s) => s.offer);
  const beneficiary = useBookingWizardStore((s) => s.beneficiary);
  const setBeneficiaryFields = useBookingWizardStore((s) => s.setBeneficiaryFields);
  const searchBeneficiary = useSearchWizardStore((s) => s.criteria.beneficiary);
  const searchLevel = useSearchWizardStore((s) => s.criteria.level);
  const { state: levelsState } = useLevels();
  const [isNavigating, setIsNavigating] = useState(false);

  useFocusEffect(
    useCallback(() => {
      setIsNavigating(false);
    }, []),
  );

  // "Relation to yourself" is meaningless — only ask it when the search
  // wizard's beneficiary type wasn't "myself".
  const needsRelation = searchBeneficiary?.id !== "myself";

  // Default the level select to whatever was picked during search, once.
  useEffect(() => {
    if (!beneficiary.level && searchLevel) setBeneficiaryFields({ level: searchLevel });
  }, [beneficiary.level, searchLevel, setBeneficiaryFields]);

  // Guard: Beneficiary only makes sense once an offer/slot has been picked
  // on BookDate — including the case of reaching here via Login/Signup/Verify
  // with no booking ever started (AGENTS.md §13).
  useEffect(() => {
    if (!offer) router.replace("/home");
  }, [offer, router]);

  if (!offer) return null;

  const levelOptions: SelectOption[] =
    levelsState.status === "success" ? levelsState.levels.map((l) => ({ id: l.id, label: l.label })) : [];

  const canContinue =
    beneficiary.firstName.trim().length > 0 &&
    beneficiary.lastName.trim().length > 0 &&
    !!beneficiary.level &&
    (!needsRelation || !!beneficiary.relation) &&
    !isNavigating;

  const continueToProfile = () => {
    if (!canContinue) return;
    setIsNavigating(true);
    router.push(BENEFICIARY_PROFILE_ROUTE);
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={1} total={3} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Qui va suivre le cours&nbsp;?</Text>
          {searchBeneficiary ? (
            <Text className="mb-5 text-[13.5px] text-ink-soft">Vous avez indiqué « {searchBeneficiary.label} »</Text>
          ) : (
            <View className="mb-5" />
          )}
        </FadeIn>

        <FadeIn delay={90}>
          <TextField
            label="Prénom"
            value={beneficiary.firstName}
            onChangeText={(firstName) => setBeneficiaryFields({ firstName })}
            placeholder="Thomas"
          />
          <TextField
            label="Nom"
            value={beneficiary.lastName}
            onChangeText={(lastName) => setBeneficiaryFields({ lastName })}
            placeholder="Rakoto"
          />
          {needsRelation ? (
            <SelectField
              label="Relation"
              value={beneficiary.relation}
              options={RELATION_OPTIONS}
              onSelect={(relation) => setBeneficiaryFields({ relation })}
            />
          ) : null}
          <SelectField
            label="Niveau"
            value={beneficiary.level ? { id: beneficiary.level.id, label: beneficiary.level.label } : null}
            options={levelOptions}
            placeholder={levelsState.status === "loading" ? "Chargement..." : "Sélectionner"}
            disabled={levelsState.status !== "success"}
            onSelect={(option) => {
              const level = levelsState.status === "success" ? levelsState.levels.find((l) => l.id === option.id) : undefined;
              if (level) setBeneficiaryFields({ level });
            }}
          />
          {levelsState.status === "error" ? (
            <Text className="text-[13px] text-error">{levelsState.message}</Text>
          ) : null}
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" disabled={!canContinue} onPress={continueToProfile} />
      </View>
    </View>
  );
}
