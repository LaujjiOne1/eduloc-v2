import { type Href, useRouter } from "expo-router";
import { useEffect, useRef } from "react";
import { Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { VerifiedBadgeIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/ui/form-error";
import { useVerifyForm } from "@/hooks/use-verify-form";
import { useAuthStore } from "@/store/auth.store";

const BENEFICIARY_ROUTE = "/beneficiary" as Href;
const CODE_LENGTH = 6;

function maskEmail(email: string): string {
  const [name, domain] = email.split("@");
  if (!name || !domain) return email;
  return `${name.charAt(0)}${"•".repeat(Math.max(name.length - 1, 3))}@${domain}`;
}

export function VerifyScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const pendingUser = useAuthStore((s) => s.pendingUser);
  const confirmPendingUser = useAuthStore((s) => s.confirmPendingUser);

  const email = pendingUser?.email ?? "";

  const { code, setCode, formError, isSubmitting, submit, resend, resendState, canSubmit } = useVerifyForm(
    email,
    () => {
      confirmPendingUser();
      router.push(BENEFICIARY_ROUTE);
    },
  );

  // Guard: reaching Verify without a just-completed signup means there's no
  // pending email to confirm — bounce back to Signup rather than showing a
  // masked "we sent a code to" for no one (AGENTS.md §13).
  useEffect(() => {
    if (!pendingUser) router.replace("/signup");
  }, [pendingUser, router]);

  if (!pendingUser) return null;

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <View className="flex-1 items-center px-6 pt-6">
        <FadeIn delay={30}>
          <View className="mb-5 h-14 w-14 items-center justify-center rounded-full bg-primary-tint">
            <VerifiedBadgeIcon size={26} color="#332E86" />
          </View>
        </FadeIn>

        <FadeIn delay={70}>
          <Text className="mb-2 text-center text-[23px] font-bold text-ink">Vérifiez votre compte</Text>
          <Text className="mb-[26px] text-center text-[14px] text-ink-soft">
            Nous avons envoyé un code à{"\n"}
            <Text className="font-bold text-ink">{maskEmail(email)}</Text>
          </Text>
        </FadeIn>

        <FadeIn delay={110}>
          {formError ? <FormError message={formError} /> : null}
          <OtpInput value={code} onChange={setCode} length={CODE_LENGTH} editable={!isSubmitting} />
        </FadeIn>

        <FadeIn delay={150}>
          <PressableScale onPress={resend} disabled={resendState !== "idle"} accessibilityLabel="Renvoyer le code">
            <Text className="mt-[22px] text-[13.5px] font-bold text-primary">
              {resendState === "sending"
                ? "Envoi..."
                : resendState === "sent"
                  ? "Code renvoyé ✓"
                  : "Renvoyer le code"}
            </Text>
          </PressableScale>
        </FadeIn>
      </View>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label="Vérifier"
          loading={isSubmitting}
          loadingLabel="Vérification..."
          disabled={!canSubmit}
          onPress={submit}
        />
      </View>
    </View>
  );
}

type OtpInputProps = {
  value: string;
  onChange: (value: string) => void;
  length: number;
  editable: boolean;
};

/** 6 auto-advancing single-digit boxes — the RN equivalent of the mock's OTP row. */
function OtpInput({ value, onChange, length, editable }: OtpInputProps) {
  const inputs = useRef<(TextInput | null)[]>([]);

  const handleChangeDigit = (index: number, text: string) => {
    const digit = text.replace(/\D/g, "").slice(-1);
    const next = value.split("");
    next[index] = digit;
    onChange(next.join("").slice(0, length));
    if (digit && index < length - 1) inputs.current[index + 1]?.focus();
  };

  const handleKeyPress = (index: number, key: string) => {
    if (key === "Backspace" && !value[index] && index > 0) {
      inputs.current[index - 1]?.focus();
    }
  };

  return (
    <View className="flex-row justify-center gap-2">
      {Array.from({ length }, (_, i) => (
        <TextInput
          key={i}
          ref={(ref) => {
            inputs.current[i] = ref;
          }}
          value={value[i] ?? ""}
          onChangeText={(text) => handleChangeDigit(i, text)}
          onKeyPress={({ nativeEvent }) => handleKeyPress(i, nativeEvent.key)}
          keyboardType="number-pad"
          maxLength={1}
          editable={editable}
          className="h-[52px] w-[42px] rounded-sm border border-line bg-surface text-center text-[20px] font-bold text-ink"
          accessibilityLabel={`Chiffre ${i + 1} du code`}
        />
      ))}
    </View>
  );
}
