import { type Href, useFocusEffect, useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { useBookingWizardStore } from "@/store/booking-wizard.store";
import { useSearchWizardStore } from "@/store/search-wizard.store";

const BOOKING_SUMMARY_ROUTE = "/booking-summary" as Href;

export function BeneficiaryProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const offer = useBookingWizardStore((s) => s.offer);
  const beneficiary = useBookingWizardStore((s) => s.beneficiary);
  const difficulty = useBookingWizardStore((s) => s.difficulty);
  const setDifficulty = useBookingWizardStore((s) => s.setDifficulty);
  const subject = useSearchWizardStore((s) => s.criteria.subject);
  const objective = useSearchWizardStore((s) => s.criteria.objective);
  const [isNavigating, setIsNavigating] = useState(false);

  useFocusEffect(
    useCallback(() => {
      setIsNavigating(false);
    }, []),
  );

  // Guard: this recap needs both an active booking and a beneficiary name,
  // i.e. Beneficiary (step 1/3) must have been completed first.
  const hasContext = !!offer && beneficiary.firstName.trim().length > 0;

  useEffect(() => {
    if (!hasContext) router.replace("/home");
  }, [hasContext, router]);

  if (!hasContext) return null;

  const continueToSummary = () => {
    if (isNavigating) return;
    setIsNavigating(true);
    router.push(BOOKING_SUMMARY_ROUTE);
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={2} total={3} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">À propos de {beneficiary.firstName}</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">Son profil pédagogique</Text>
        </FadeIn>

        <FadeIn delay={90}>
          <View className="mb-3 rounded-lg border border-line bg-surface p-4">
            <SummaryRow label="Niveau" value={beneficiary.level?.label ?? "—"} />
            <View className="h-px bg-line-soft" />
            <SummaryRow label="Matière" value={subject?.label ?? "—"} />
            <View className="h-px bg-line-soft" />
            <SummaryRow label="Objectif" value={objective?.label ?? "—"} />
          </View>
        </FadeIn>

        <FadeIn delay={130}>
          <Text className="mb-[6px] ml-0.5 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
            Difficulté principale
          </Text>
          <TextInput
            value={difficulty}
            onChangeText={setDifficulty}
            placeholder="Ex. les boucles et les listes…"
            placeholderTextColor="#9799AF"
            multiline
            textAlignVertical="top"
            className="h-[88px] rounded-sm border border-line bg-surface px-[14px] py-[13px] text-[15px] text-ink"
            accessibilityLabel="Difficulté principale"
          />
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" disabled={isNavigating} onPress={continueToSummary} />
      </View>
    </View>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <View className="flex-row items-center justify-between py-2">
      <Text className="text-[14px] text-ink-soft">{label}</Text>
      <Text className="text-[14px] font-bold text-ink">{value}</Text>
    </View>
  );
}
