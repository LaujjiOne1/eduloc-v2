import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  ChevronRightIcon,
  LevelIcon,
  LocationIcon,
  SearchIcon,
  SubjectIcon,
  TeachIcon,
} from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { Button } from "@/components/ui/button";
import { Chip, ChipSkeleton } from "@/components/ui/chip";
import { usePopularCategories } from "@/hooks/use-popular-categories";
import { useSearchWizardStore } from "@/store/search-wizard.store";

// Casting to Href keeps navigation wired per the reference workflow without
// waiting on expo-router's typed route generation, which only tracks routes
// that already exist under app/ as of the last dev-server run.
// /search resolves to the Need → Level → ForWhom → Location → Objective
// wizard (src/app/search/**). /tutor-intro resolves to the "devenir tuteur"
// onboarding wizard (src/app/tutor-*.tsx, src/screens/tutor-onboarding/**).
const SEARCH_ROUTE = "/search" as Href;
const TUTOR_INTRO_ROUTE = "/tutor-intro" as Href;
const LOGIN_ROUTE = "/login" as Href;
const SIGNUP_ROUTE = "/signup" as Href;
// 37_ModeChoice.html is the real entry point into either dashboard — there is
// still no auth/role state gating which modes a given user may enter
// (AGENTS.md §8), so this remains a clearly-labelled preview link rather than
// a true post-login redirect.
const MODE_CHOICE_ROUTE = "/mode-choice" as Href;

export function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state: popularCategories, retry } = usePopularCategories();
  const resetSearchWizard = useSearchWizardStore((s) => s.reset);

  const goToSearch = () => {
    resetSearchWizard();
    router.push(SEARCH_ROUTE);
  };
  const goToTutorIntro = () => router.push(TUTOR_INTRO_ROUTE);
  const goToLogin = () => router.push(LOGIN_ROUTE);
  const goToSignup = () => router.push(SIGNUP_ROUTE);
  const goToModeChoice = () => router.push(MODE_CHOICE_ROUTE);

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <View className="flex-row items-center justify-between px-5 pb-[14px] pt-5">
        <Text className="text-[21px] font-bold text-ink ">
          edU<Text className="text-primary">loc</Text>
        </Text>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 28, paddingTop: 4 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <View className="my-[10px] mb-[26px]">
            <Text className="text-[32px] font-bold leading-[37px] text-ink">
              Trouvez un accompagnement adapté à vos besoins
            </Text>
          </View>
        </FadeIn>

        <FadeIn delay={110}>
          <PressableScale onPress={goToSearch} accessibilityLabel="Que recherchez-vous ?">
            <View className="rounded-lg border border-primary bg-surface p-4">
              <View className="flex-row items-center gap-[10px]">
                <SearchIcon size={18} color="#9799AF" />
                <Text className="text-[15px] text-ink-faint">Que recherchez-vous&nbsp;?</Text>
              </View>
              <View className="my-[14px] h-px bg-line-soft" />
              <View className="gap-3">
                <View className="flex-row items-center gap-[10px]">
                  <SubjectIcon />
                  <Text className="text-[14.5px] text-ink-soft">Matière</Text>
                </View>
                <View className="flex-row items-center gap-[10px]">
                  <LevelIcon />
                  <Text className="text-[14.5px] text-ink-soft">Niveau</Text>
                </View>
                <View className="flex-row items-center gap-[10px]">
                  <LocationIcon />
                  <Text className="text-[14.5px] text-ink-soft">Localisation</Text>
                </View>
              </View>
            </View>
          </PressableScale>
        </FadeIn>

        <FadeIn delay={170}>
          <View className="mt-4">
            <Button
              label="Rechercher"
              onPress={goToSearch}
              icon={<SearchIcon size={17} color="#fff" />}
              fullWidth
            />
          </View>
        </FadeIn>

        <FadeIn delay={230}>
          <View className="mt-8">
            <Text className="mb-3 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
              Recherches populaires
            </Text>
            <PopularCategories state={popularCategories} onRetry={retry} />
          </View>
        </FadeIn>

        <FadeIn delay={300}>
          <PressableScale onPress={goToTutorIntro} accessibilityLabel="Vous enseignez ? Devenez tuteur validé sur EduLoc">
            <View className="mt-7 rounded-lg border border-primary-tint bg-primary-tint p-4">
              <View className="flex-row items-center gap-3">
                <View className="h-10 w-10 items-center justify-center rounded-md bg-white">
                  <TeachIcon color="#332E86" />
                </View>
                <View className="flex-1">
                  <Text className="text-[15px] font-bold text-ink">Vous enseignez&nbsp;?</Text>
                  <Text className="text-[13px] text-ink-soft">Devenez tuteur validé sur EduLoc</Text>
                </View>
                <ChevronRightIcon />
              </View>
            </View>
          </PressableScale>
        </FadeIn>

        <FadeIn delay={330}>
          <PressableScale onPress={goToModeChoice} accessibilityLabel="Aperçu de l'espace demandeur ou tuteur (démo)">
            <Text className="mt-3 text-center text-[13px] font-semibold text-primary">
              Aperçu de l&apos;espace demandeur ou tuteur (démo)
            </Text>
          </PressableScale>
        </FadeIn>
      </ScrollView>

      <View
        className="flex-row gap-[10px] border-t border-line-soft px-15 pt-[14px] items-center justify-center "
        style={{ paddingBottom: Math.max(insets.bottom, 20) }}
      >
        <Button label="Se connecter" variant="ghost" onPress={goToLogin} className="w-65"  />
        <Button label="Créer un compte" variant="primary" onPress={goToSignup} className="w-65"  />
      </View>
    </View>
  );
}

type PopularCategoriesProps = {
  state: ReturnType<typeof usePopularCategories>["state"];
  onRetry: () => void;
};

function PopularCategories({ state, onRetry }: PopularCategoriesProps) {
  if (state.status === "loading") {
    return (
      <View className="flex-row flex-wrap gap-2">
        <ChipSkeleton width={128} />
        <ChipSkeleton width={110} />
        <ChipSkeleton width={90} />
        <ChipSkeleton width={100} />
      </View>
    );
  }

  if (state.status === "error") {
    return (
      <View className="flex-row items-center gap-3">
        <Text className="flex-1 text-[13.5px] text-error">{state.message}</Text>
        <PressableScale onPress={onRetry} accessibilityLabel="Réessayer de charger les recherches populaires">
          <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
        </PressableScale>
      </View>
    );
  }

  if (state.status === "empty") {
    return <Text className="text-[13.5px] text-ink-faint">Aucune recherche populaire pour le moment.</Text>;
  }

  return (
    <View className="flex-row flex-wrap gap-2">
      {state.categories.map((category) => (
        <Chip key={category.id} label={category.label} />
      ))}
    </View>
  );
}
