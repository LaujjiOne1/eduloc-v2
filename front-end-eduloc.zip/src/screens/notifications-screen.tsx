import { useRouter } from "expo-router";
import type { ComponentType } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  CalendarIcon,
  CheckCircleIcon,
  type IconProps,
  MicIcon,
  XCircleIcon,
} from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { ApprentiBottomNav } from "@/components/ui/apprenti-bottom-nav";
import { TutorBottomNav } from "@/components/ui/tutor-bottom-nav";
import { AuthHeader } from "@/components/ui/auth-header";
import { useMyNotifications } from "@/hooks/use-my-notifications";
import { useAuthStore } from "@/store/auth.store";
import type { AppNotification, NotificationType } from "@/types/notification";

const NOTIFICATION_VISUAL: Record<NotificationType, { Icon: ComponentType<IconProps>; bgClass: string; color: string }> = {
  booking_accepted: { Icon: CheckCircleIcon, bgClass: "bg-accent-tint", color: "#0E9C82" },
  new_message: { Icon: MicIcon, bgClass: "bg-primary-tint", color: "#332E86" },
  reminder: { Icon: CalendarIcon, bgClass: "bg-warning-tint", color: "#BD7E28" },
  booking_refused: { Icon: XCircleIcon, bgClass: "bg-error-tint", color: "#AC4A40" },
};

function groupByDate(notifications: AppNotification[]): { label: string; items: AppNotification[] }[] {
  const groups: { label: string; items: AppNotification[] }[] = [];
  for (const notification of notifications) {
    const group = groups.find((g) => g.label === notification.dateGroup);
    if (group) group.items.push(notification);
    else groups.push({ label: notification.dateGroup, items: [notification] });
  }
  return groups;
}

export function NotificationsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const activeMode = useAuthStore((s) => s.activeMode);
  const { state, retry } = useMyNotifications();

  const isApprenti = activeMode === "apprenti";
  const groups = state.status === "success" ? groupByDate(state.notifications) : [];

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      {/* The mock's back arrow always points to 21_ApprentiDashboard, but this
          screen is also reached from 51_TutorDashboard's own bell icon —
          router.back() returns to whichever dashboard actually opened it. */}
      <AuthHeader onBack={() => router.back()} />
      <Text className="px-5 pb-2 text-[24px] font-bold text-ink">Notifications</Text>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: Math.max(insets.bottom, 20) }}
        showsVerticalScrollIndicator={false}
      >
        {state.status === "loading" ? (
          <View className="gap-3 pt-3">
            {[0, 1, 2].map((i) => (
              <View key={i} className="h-[62px] rounded-lg bg-line-soft" />
            ))}
          </View>
        ) : state.status === "error" ? (
          <View className="flex-row items-center gap-3 pt-3">
            <Text className="flex-1 text-[13.5px] text-error">{state.message}</Text>
            <PressableScale onPress={retry} accessibilityLabel="Réessayer">
              <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
            </PressableScale>
          </View>
        ) : state.status === "empty" ? (
          <View className="items-center py-10">
            <Text className="text-center text-[14px] text-ink-soft">Aucune notification pour le moment.</Text>
          </View>
        ) : (
          groups.map((group, groupIndex) => (
            <View key={group.label}>
              <Text className="mb-[2px] mt-[14px] text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
                {group.label}
              </Text>
              {group.items.map((notification, index) => (
                <FadeIn key={notification.id} delay={40 + (groupIndex * 3 + index) * 40}>
                  <NotificationRow notification={notification} />
                </FadeIn>
              ))}
            </View>
          ))
        )}
      </ScrollView>

      {isApprenti ? <ApprentiBottomNav active="notifications" /> : <TutorBottomNav active="home" />}
    </View>
  );
}

function NotificationRow({ notification }: { notification: AppNotification }) {
  const { Icon, bgClass, color } = NOTIFICATION_VISUAL[notification.type];
  return (
    <View className="flex-row gap-3 py-[14px]">
      <View className={["h-[38px] w-[38px] items-center justify-center rounded-md", bgClass].join(" ")}>
        <Icon size={17} color={color} />
      </View>
      <View className="flex-1">
        <Text className="text-[14px] font-bold text-ink">{notification.title}</Text>
        <Text className="mt-[2px] text-[13px] leading-[18px] text-ink-soft">{notification.message}</Text>
      </View>
      <Text className="text-[11px] text-ink-faint">{notification.timeLabel}</Text>
    </View>
  );
}
