import { ResultsScreen } from "@/screens/results/results-screen";

export function ResultsMapScreen() {
  return <ResultsScreen initialTab="map" />;
}
