import { type Href, useLocalSearchParams, useRouter } from "expo-router";
import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ChevronRightIcon, ClockIcon, LocationIcon, SubjectIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { useOffer } from "@/hooks/use-offer";
import { useBookingWizardStore } from "@/store/booking-wizard.store";
import type { Offer, OfferSlot } from "@/types/offer";

// Cast defensively since expo-router's typed-routes union is only refreshed
// when the dev server runs (same convention as every other route in this app).
const BOOK_DATE_ROUTE = "/results/book" as Href;

const FORMAT_LABELS: Record<string, string> = { in_person: "Présentiel", online: "En ligne" };

export function OfferDetailScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { state, retry } = useOffer(id);

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      {state.status === "loading" ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator color="#332E86" />
        </View>
      ) : state.status === "error" ? (
        <View className="flex-1 items-center justify-center gap-3 px-8">
          <Text className="text-center text-[14px] text-error">{state.message}</Text>
          <PressableScale onPress={retry} accessibilityLabel="Réessayer">
            <Text className="text-[14px] font-semibold text-primary">Réessayer</Text>
          </PressableScale>
        </View>
      ) : (
        <OfferDetailContent
          offer={state.offer}
          insetsBottom={insets.bottom}
          onBook={(slot) => {
            useBookingWizardStore.getState().setBooking(state.offer, slot);
            router.push(BOOK_DATE_ROUTE);
          }}
        />
      )}
    </View>
  );
}

type OfferDetailContentProps = {
  offer: Offer;
  insetsBottom: number;
  onBook: (slot: OfferSlot) => void;
};

function OfferDetailContent({ offer, insetsBottom, onBook }: OfferDetailContentProps) {
  const [selectedSlotId, setSelectedSlotId] = useState<string | null>(offer.slots[0]?.id ?? null);
  const selectedSlot = offer.slots.find((slot) => slot.id === selectedSlotId) ?? null;

  useEffect(() => {
    setSelectedSlotId(offer.slots[0]?.id ?? null);
  }, [offer.id, offer.slots]);

  const formatPrimary = offer.formats[0] ? FORMAT_LABELS[offer.formats[0]] : null;
  const formatSecondary = offer.formats[1] ? FORMAT_LABELS[offer.formats[1]] : null;

  return (
    <>
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={30}>
          <Text className="mb-1 text-[24px] font-bold text-ink">{offer.title}</Text>
          <View className="mb-5 flex-row items-center gap-2">
            <View className="h-[22px] w-[22px] items-center justify-center rounded-full bg-primary-tint">
              <Text className="text-[10px] font-bold text-primary">{offer.tutorInitial}</Text>
            </View>
            <Text className="text-[14px] text-ink-soft">avec {offer.tutorName}</Text>
          </View>
        </FadeIn>

        <FadeIn delay={70}>
          <Text className="mb-[6px] ml-0.5 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
            Description
          </Text>
          <Text className="mb-5 text-[14.5px] leading-[22px] text-ink-soft">{offer.description}</Text>
        </FadeIn>

        <FadeIn delay={100}>
          <View className="mb-5 flex-row gap-3">
            <StatCard icon={<ClockIcon size={18} color="#332E86" />} value={offer.durationLabel} label="Durée" />
            <StatCard
              icon={<SubjectIcon size={18} color="#332E86" />}
              value={formatPrimary ?? "—"}
              label={formatSecondary ? `/ ${formatSecondary}` : "Format"}
            />
            <StatCard icon={<LocationIcon size={18} color="#332E86" />} value={offer.location} label="Lieu" />
          </View>
        </FadeIn>

        <FadeIn delay={140}>
          <Text className="mb-[6px] ml-0.5 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
            Prochains créneaux
          </Text>
          {offer.slots.length === 0 ? (
            <Text className="text-[13.5px] text-ink-faint">Aucun créneau disponible pour le moment.</Text>
          ) : (
            offer.slots.map((slot) => (
              <SlotRow
                key={slot.id}
                slot={slot}
                selected={slot.id === selectedSlotId}
                onPress={() => setSelectedSlotId(slot.id)}
              />
            ))
          )}
        </FadeIn>
      </ScrollView>

      <View className="border-t border-line-soft bg-surface px-5 pt-4" style={{ paddingBottom: Math.max(insetsBottom, 22) }}>
        <Button
          label="Choisir ce créneau"
          disabled={!selectedSlot}
          onPress={() => selectedSlot && onBook(selectedSlot)}
        />
      </View>
    </>
  );
}

type StatCardProps = {
  icon: ReactNode;
  value: string;
  label: string;
};

function StatCard({ icon, value, label }: StatCardProps) {
  return (
    <View className="flex-1 items-center rounded-lg border border-line bg-surface p-[14px]">
      <View className="mb-[6px]">{icon}</View>
      <Text className="text-[14px] font-bold text-ink" numberOfLines={1}>
        {value}
      </Text>
      <Text className="text-[11.5px] text-ink-soft">{label}</Text>
    </View>
  );
}

type SlotRowProps = {
  slot: OfferSlot;
  selected: boolean;
  onPress: () => void;
};

function SlotRow({ slot, selected, onPress }: SlotRowProps) {
  return (
    <PressableScale onPress={onPress} accessibilityLabel={`${slot.dateLabel}, ${slot.timeRangeLabel}`}>
      <View
        className={[
          "mb-[10px] flex-row items-center justify-between rounded-lg border p-4",
          selected ? "border-primary bg-primary-tint" : "border-line bg-surface",
        ].join(" ")}
      >
        <View>
          <Text className="text-[14.5px] font-bold text-ink">{slot.dateLabel}</Text>
          <Text className="mt-[2px] text-[13px] text-ink-soft">{slot.timeRangeLabel}</Text>
        </View>
        <ChevronRightIcon size={17} color={selected ? "#332E86" : "#9799AF"} />
      </View>
    </PressableScale>
  );
}
