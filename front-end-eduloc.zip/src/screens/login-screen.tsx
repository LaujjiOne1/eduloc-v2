import { type Href, useRouter } from "expo-router";
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/ui/form-error";
import { TextField } from "@/components/ui/text-field";
import { useLoginForm } from "@/hooks/use-login-form";
import { useAuthStore } from "@/store/auth.store";

const BENEFICIARY_ROUTE = "/beneficiary" as Href;
const SIGNUP_ROUTE = "/signup" as Href;

export function LoginScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const setUser = useAuthStore((s) => s.setUser);

  const {
    email,
    setEmail,
    password,
    setPassword,
    fieldErrors,
    formError,
    isSubmitting,
    providerPending,
    submit,
    continueWithProvider,
    canSubmit,
  } = useLoginForm((user) => {
    setUser(user);
    router.push(BENEFICIARY_ROUTE);
  });

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-paper"
      style={{ paddingTop: insets.top }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <AuthHeader onBack={() => router.back()} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 8, paddingBottom: 20 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-[6px] text-[25px] font-bold text-ink">Connectez-vous pour continuer</Text>
          <Text className="mb-[26px] text-[14px] text-ink-soft">
            Votre créneau est réservé quelques minutes
          </Text>
        </FadeIn>

        <FadeIn delay={100}>
          <View className="mb-5 gap-[10px]">
            <Button
              label="Continuer avec Google"
              variant="ghost"
              icon={<View className="h-[18px] w-[18px] rounded bg-ink" />}
              loading={providerPending === "google"}
              loadingLabel="Connexion..."
              disabled={isSubmitting || (providerPending !== null && providerPending !== "google")}
              onPress={() => continueWithProvider("google")}
            />
            <Button
              label="Continuer avec Apple"
              variant="ghost"
              icon={<View className="h-[18px] w-[18px] rounded bg-ink" />}
              loading={providerPending === "apple"}
              loadingLabel="Connexion..."
              disabled={isSubmitting || (providerPending !== null && providerPending !== "apple")}
              onPress={() => continueWithProvider("apple")}
            />
          </View>
        </FadeIn>

        <FadeIn delay={150}>
          <View className="my-5 flex-row items-center gap-3">
            <View className="h-px flex-1 bg-line-soft" />
            <Text className="text-[12.5px] font-semibold text-ink-faint">ou</Text>
            <View className="h-px flex-1 bg-line-soft" />
          </View>
        </FadeIn>

        <FadeIn delay={200}>
          {formError ? <FormError message={formError} /> : null}

          <TextField
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="vous@email.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
            textContentType="emailAddress"
            error={fieldErrors.email}
            editable={!isSubmitting}
          />
          <TextField
            label="Mot de passe"
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••"
            secureTextEntry
            autoCapitalize="none"
            autoComplete="password"
            textContentType="password"
            error={fieldErrors.password}
            editable={!isSubmitting}
          />

          <View className="mt-2">
            <Button
              label="Se connecter"
              loading={isSubmitting}
              loadingLabel="Connexion..."
              disabled={!canSubmit}
              onPress={submit}
              fullWidth
            />
          </View>

          <View className="mt-[22px] flex-row justify-center">
            <Text className="text-[14px] text-ink-soft">Pas encore de compte&nbsp;? </Text>
            <PressableScale onPress={() => router.push(SIGNUP_ROUTE)} accessibilityLabel="Créer un compte">
              <Text className="text-[14px] font-bold text-primary">Créer un compte</Text>
            </PressableScale>
          </View>
        </FadeIn>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
