import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ChevronRightIcon, MessageSquareIcon, MicIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { ApprentiBottomNav } from "@/components/ui/apprenti-bottom-nav";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { getTutorAvatarTone } from "@/components/ui/tutor-card";
import { useMyBookings } from "@/hooks/use-my-bookings";
import type { Booking } from "@/types/booking";

function conversationRoute(id: string): Href {
  return `/apprenti-dashboard/bookings/${id}/conversation` as Href;
}

export function ConversationsListScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state } = useMyBookings();

  // Active bookings with tutors eligible for conversation
  const bookings =
    state.status === "success"
      ? state.bookings.filter((b) => b.status !== "cancelled" && b.status !== "refused")
      : [];

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <View className="px-5 pb-3">
        <FadeIn delay={30}>
          <Text className="text-[25px] font-bold text-ink">Conversations</Text>
          <Text className="mt-1 text-[13.5px] text-ink-soft">
            Échangez des messages vocaux et des documents avec vos tuteurs
          </Text>
        </FadeIn>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: Math.max(insets.bottom, 20),
        }}
        showsVerticalScrollIndicator={false}
      >
        {state.status === "loading" ? (
          <View className="gap-3 pt-2">
            {[0, 1, 2].map((i) => (
              <View key={i} className="h-[84px] rounded-xl bg-line-soft" />
            ))}
          </View>
        ) : bookings.length === 0 ? (
          <FadeIn delay={60}>
            <View className="items-center rounded-2xl border border-line bg-surface p-8 text-center my-6">
              <View className="mb-3.5 h-12 w-12 items-center justify-center rounded-full bg-primary-soft">
                <MessageSquareIcon size={24} color="#332E86" />
              </View>
              <Text className="text-[16px] font-bold text-ink">
                Aucune conversation active
              </Text>
              <Text className="mt-1.5 text-center text-[13.5px] text-ink-soft max-w-[280px]">
                Réservez un tuteur ou envoyez une demande pour échanger des vocaux et des documents.
              </Text>
              <View className="mt-5 w-full">
                <Button
                  label="Trouver un tuteur"
                  onPress={() => router.push("/search")}
                />
              </View>
            </View>
          </FadeIn>
        ) : (
          <View className="gap-2.5 pt-2">
            {bookings.map((booking, index) => (
              <FadeIn key={booking.id} delay={60 + index * 40}>
                <ConversationItem
                  booking={booking}
                  onPress={() => router.push(conversationRoute(booking.id))}
                />
              </FadeIn>
            ))}
          </View>
        )}
      </ScrollView>

      {/* 3-tab Bottom Nav: Accueil | Conversations | Profil */}
      <ApprentiBottomNav active="conversations" />
    </View>
  );
}

function ConversationItem({
  booking,
  onPress,
}: {
  booking: Booking;
  onPress: () => void;
}) {
  const toneClasses = getTutorAvatarTone((booking.offer as any)?.avatarTone ?? "primary");

  return (
    <PressableScale onPress={onPress} accessibilityLabel={`Conversation avec ${booking.offer.tutorName}`}>
      <View className="flex-row items-center gap-3.5 rounded-xl border border-line bg-surface p-4 shadow-2xs hover:border-primary/30">
        {/* Avatar */}
        <View className={["h-[46px] w-[46px] items-center justify-center rounded-full", toneClasses.bg].join(" ")}>
          <Text className={["text-[16px] font-bold", toneClasses.text].join(" ")}>
            {booking.offer.tutorName[0]}
          </Text>
        </View>

        {/* Content */}
        <View className="flex-1">
          <View className="flex-row items-center justify-between">
            <Text className="text-[15px] font-bold text-ink" numberOfLines={1}>
              {booking.offer.tutorName}
            </Text>
            <StatusBadge status={booking.status} />
          </View>

          <Text className="text-[12.5px] text-ink-soft mt-0.5" numberOfLines={1}>
            {booking.offer.subjectLabel ?? (booking.offer as any).subject ?? "Cours"} • {booking.beneficiary.firstName}
          </Text>

          <View className="mt-1.5 flex-row items-center gap-1.5">
            <View className="h-4 w-4 items-center justify-center rounded-full bg-primary-soft">
              <MicIcon size={10} color="#332E86" />
            </View>
            <Text className="text-[12px] font-medium text-primary" numberOfLines={1}>
              Messagerie vocale et documents
            </Text>
          </View>
        </View>

        <ChevronRightIcon size={16} color="#9799AF" />
      </View>
    </PressableScale>
  );
}
