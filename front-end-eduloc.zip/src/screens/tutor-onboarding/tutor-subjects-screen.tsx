import { type Href, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CheckIcon, SparklesIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { Chip } from "@/components/ui/chip";
import { StepProgress } from "@/components/ui/step-progress";
import { useLevels } from "@/hooks/use-levels";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { EducationLevel } from "@/types/search";

const TUTOR_BIO_ROUTE = "/tutor-bio" as Href;
const TUTOR_SKILLS_ROUTE = "/tutor-skills" as Href;
const TOTAL_STEPS = 9;

export function TutorSubjectsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state: levelsState, retry } = useLevels();
  const skills = useTutorApplicationStore((s) => s.skills);
  const background = useTutorApplicationStore((s) => s.background);
  const subjectLevels = useTutorApplicationStore((s) => s.subjectLevels);
  const toggleSubjectLevel = useTutorApplicationStore((s) => s.toggleSubjectLevel);

  const [filterByDegree, setFilterByDegree] = useState(true);

  // Guard: this step only makes sense once at least one skill was picked on TutorSkills
  useEffect(() => {
    if (skills.length === 0) router.replace(TUTOR_SKILLS_ROUTE);
  }, [skills.length, router]);

  if (skills.length === 0) return null;

  // Filter allowed/recommended levels according to degree
  // Degree: bac, licence, master, doctorat, other
  const degreeId = background.degree?.id ?? "licence";
  const degreeLabel = background.degree?.label ?? "votre diplôme";

  const isLevelRecommended = (levelId: string): boolean => {
    if (degreeId === "bac") {
      return ["primary", "middle_school", "high_school"].includes(levelId);
    }
    if (degreeId === "licence") {
      return ["primary", "middle_school", "high_school", "university"].includes(levelId);
    }
    // master, doctorat or other can teach all levels
    return true;
  };

  const canContinue = skills.every(
    (skill) => (subjectLevels.find((sl) => sl.skill.id === skill.id)?.levels.length ?? 0) > 0,
  );

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={4} total={TOTAL_STEPS} title="Niveaux enseignés" />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Matières et niveaux</Text>
          <Text className="mb-3 text-[13.5px] text-ink-soft">
            Pour chaque compétence, précisez les niveaux que vous souhaitez dispenser
          </Text>

          {/* Indication visuelle explicite de choix multiple */}
          <View className="mb-4 flex-row items-center gap-2 rounded-lg bg-accent-tint/40 px-3.5 py-2.5">
            <CheckIcon size={16} color="#0E9C82" />
            <Text className="flex-1 text-[12.5px] font-semibold text-accent">
              Choix multiple : vous pouvez sélectionner un ou plusieurs niveaux par matière.
            </Text>
          </View>

          {/* Filtre automatique selon le niveau d'études */}
          {background.degree ? (
            <View className="mb-4 flex-row items-center justify-between rounded-lg border border-line bg-surface p-3">
              <View className="flex-1 pr-2">
                <View className="flex-row items-center gap-1.5">
                  <SparklesIcon size={14} color="#332E86" />
                  <Text className="text-[13px] font-bold text-ink">
                    Filtrage selon cursus : {degreeLabel}
                  </Text>
                </View>
                <Text className="mt-0.5 text-[11.5px] text-ink-soft">
                  {filterByDegree
                    ? "Affichage des niveaux recommandés pour votre diplôme"
                    : "Affichage de tous les niveaux disponibles"}
                </Text>
              </View>
              <PressableScale
                onPress={() => setFilterByDegree(!filterByDegree)}
                accessibilityLabel="Basculer le filtre des niveaux"
              >
                <View
                  className={[
                    "rounded-full px-3 py-1.5",
                    filterByDegree ? "bg-primary text-white" : "border border-line bg-paper",
                  ].join(" ")}
                >
                  <Text
                    className={[
                      "text-[11.5px] font-bold",
                      filterByDegree ? "text-white" : "text-ink-soft",
                    ].join(" ")}
                  >
                    {filterByDegree ? "Recommandés" : "Tous"}
                  </Text>
                </View>
              </PressableScale>
            </View>
          ) : null}
        </FadeIn>

        {levelsState.status === "loading" ? (
          <View className="gap-3">
            {skills.map((skill) => (
              <View key={skill.id} className="h-[96px] rounded-lg bg-line-soft" />
            ))}
          </View>
        ) : levelsState.status === "error" ? (
          <View className="flex-row items-center gap-3">
            <Text className="flex-1 text-[13.5px] text-error">{levelsState.message}</Text>
            <PressableScale onPress={retry} accessibilityLabel="Réessayer de charger les niveaux">
              <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
            </PressableScale>
          </View>
        ) : levelsState.status === "empty" ? (
          <Text className="text-[13.5px] text-ink-faint">Aucun niveau disponible pour le moment.</Text>
        ) : (
          <View className="gap-3.5">
            {skills.map((skill, index) => {
              const chosenLevels = subjectLevels.find((sl) => sl.skill.id === skill.id)?.levels ?? [];
              const displayedLevels = filterByDegree
                ? levelsState.levels.filter((l) => isLevelRecommended(l.id))
                : levelsState.levels;

              return (
                <FadeIn key={skill.id} delay={90 + index * 40}>
                  <SubjectCard
                    label={skill.label}
                    levels={displayedLevels}
                    chosenLevels={chosenLevels}
                    isRecommended={isLevelRecommended}
                    onToggleLevel={(level) => toggleSubjectLevel(skill, level)}
                  />
                </FadeIn>
              );
            })}
          </View>
        )}
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label="Continuer"
          disabled={!canContinue}
          onPress={() => router.push(TUTOR_BIO_ROUTE)}
        />
      </View>
    </View>
  );
}

type SubjectCardProps = {
  label: string;
  levels: EducationLevel[];
  chosenLevels: EducationLevel[];
  isRecommended: (id: string) => boolean;
  onToggleLevel: (level: EducationLevel) => void;
};

function SubjectCard({ label, levels, chosenLevels, isRecommended, onToggleLevel }: SubjectCardProps) {
  const chosenIds = new Set(chosenLevels.map((l) => l.id));

  return (
    <View className="rounded-lg border border-line bg-surface p-4">
      <View className="mb-[10px] flex-row items-center justify-between">
        <Text className="text-[15.5px] font-bold text-ink">{label}</Text>
        <Text className="text-[12px] font-semibold text-primary">
          {chosenLevels.length} sélectionné{chosenLevels.length > 1 ? "s" : ""}
        </Text>
      </View>
      <View className="flex-row flex-wrap gap-2">
        {levels.map((level) => {
          const active = chosenIds.has(level.id);
          const recommended = isRecommended(level.id);
          return (
            <Chip
              key={level.id}
              label={recommended ? `${level.label} ★` : level.label}
              active={active}
              onPress={() => onToggleLevel(level)}
            />
          );
        })}
      </View>
    </View>
  );
}
