import { type Href, useRouter } from "expo-router";
import { useEffect } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ClockIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { ScaleIn } from "@/components/motion/scale-in";
import { Button } from "@/components/ui/button";
import { useTutorApplicationStore } from "@/store/tutor-application.store";

const HOME_ROUTE = "/home" as Href;
const TUTOR_DASHBOARD_ROUTE = "/tutor-dashboard" as Href;

export function TutorApplicationPendingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const application = useTutorApplicationStore((s) => s.application);

  // Guard: this confirmation only makes sense right after a dossier was just
  // submitted — a direct/stale visit bounces to Home instead of a blank recap.
  useEffect(() => {
    if (!application) router.replace(HOME_ROUTE);
  }, [application, router]);

  if (!application) return null;

  const goHome = () => {
    router.replace(HOME_ROUTE);
  };

  const goToDashboard = () => {
    router.replace(TUTOR_DASHBOARD_ROUTE);
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <View className="flex-row items-center justify-between px-5 pb-[14px] pt-5">
        <Text className="text-[21px] font-bold text-ink">
          edU<Text className="text-primary">loc</Text>
        </Text>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 24, paddingVertical: 20, alignItems: "center" }}
        showsVerticalScrollIndicator={false}
      >
        <ScaleIn delay={20}>
          <View className="mb-[22px] mt-3 h-[72px] w-[72px] items-center justify-center rounded-full bg-warning-tint">
            <ClockIcon size={32} color="#BD7E28" />
          </View>
        </ScaleIn>

        <FadeIn delay={90}>
          <Text className="mb-[10px] text-center text-[22px] font-bold text-ink">Dossier envoyé</Text>
        </FadeIn>

        <FadeIn delay={130}>
          <Text className="mb-[22px] text-center text-[14.5px] leading-[21px] text-ink-soft">
            Votre candidature est en cours de vérification par EduLoc.
          </Text>
        </FadeIn>

        <FadeIn delay={160}>
          <View className="mb-6 flex-row items-center gap-[6px] self-center rounded-full bg-warning-tint px-[11px] py-[5px]">
            <View className="h-[7px] w-[7px] rounded-full bg-warning" />
            <Text className="text-[12px] font-semibold text-warning">EN ATTENTE</Text>
          </View>
        </FadeIn>

        <FadeIn delay={200}>
          <Text className="text-center text-[12.5px] leading-[19px] text-ink-faint">
            Vous recevrez une notification lorsque votre dossier sera traité. Tant qu&apos;il n&apos;est
            pas approuvé, vous n&apos;apparaissez pas dans les résultats de recherche.
          </Text>
        </FadeIn>
      </ScrollView>

      <View
        className="gap-2 border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Accéder à mon tableau de bord" variant="primary" fullWidth onPress={goToDashboard} />
        <Button label="Retour à l'accueil" variant="ghost" fullWidth onPress={goHome} />
      </View>
    </View>
  );
}
