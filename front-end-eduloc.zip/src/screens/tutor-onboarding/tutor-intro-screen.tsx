import { type Href, useRouter } from "expo-router";
import { Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CheckIcon, TeachIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { Button } from "@/components/ui/button";

const TUTOR_IDENTITY_ROUTE = "/tutor-identity" as Href;

const HIGHLIGHTS = ["Profil et compétences", "Offres et disponibilités", "Vérification EduLoc"];

export function TutorIntroScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <View className="flex-1 justify-center gap-[22px] px-8">
        <FadeIn delay={30}>
          <View className="h-[60px] w-[60px] items-center justify-center rounded-[18px] bg-primary-tint">
            <TeachIcon size={28} color="#332E86" />
          </View>
        </FadeIn>

        <FadeIn delay={80}>
          <Text className="mb-3 text-[29px] font-bold leading-[35px] text-ink">
            Devenez tuteur sur EduLoc
          </Text>
          <Text className="text-[15px] leading-[21px] text-ink-soft">
            Partagez vos compétences avec des personnes qui ont besoin de vous. Votre dossier sera
            vérifié par notre équipe avant publication.
          </Text>
        </FadeIn>

        <FadeIn delay={140}>
          <View className="mt-[6px] gap-3">
            {HIGHLIGHTS.map((label) => (
              <View key={label} className="flex-row items-center gap-3">
                <CheckIcon size={18} color="#0E9C82" />
                <Text className="text-[13.5px] font-semibold text-ink">{label}</Text>
              </View>
            ))}
          </View>
        </FadeIn>
      </View>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Commencer" onPress={() => router.push(TUTOR_IDENTITY_ROUTE)} />
      </View>
    </View>
  );
}
