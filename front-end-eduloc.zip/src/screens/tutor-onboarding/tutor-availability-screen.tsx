import { type Href, useRouter } from "expo-router";
import { useState } from "react";
import { Modal, ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CheckIcon, ClockIcon, LocationIcon, PlusIcon, TrashIcon, VideoIcon, XIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { LocationFormatId } from "@/types/search";
import type { WeeklyDayAvailability } from "@/types/tutor-application";

const TUTOR_DOCUMENTS_ROUTE = "/tutor-documents" as Href;
const TOTAL_STEPS = 9;

export function TutorAvailabilityScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const weeklyAvailability = useTutorApplicationStore((s) => s.weeklyAvailability);
  const toggleWeeklyDay = useTutorApplicationStore((s) => s.toggleWeeklyDay);
  const addWeeklySlot = useTutorApplicationStore((s) => s.addWeeklySlot);
  const removeWeeklySlot = useTutorApplicationStore((s) => s.removeWeeklySlot);

  const [addSlotModal, setAddSlotModal] = useState<{ open: boolean; dayId: string; dayLabel: string }>({
    open: false,
    dayId: "",
    dayLabel: "",
  });
  const [startTime, setStartTime] = useState("14:00");
  const [endTime, setEndTime] = useState("18:00");
  const [slotFormat, setSlotFormat] = useState<LocationFormatId>("both");

  const openAddSlot = (day: WeeklyDayAvailability) => {
    setAddSlotModal({ open: true, dayId: day.dayId, dayLabel: day.dayLabel });
    setStartTime("14:00");
    setEndTime("17:00");
  };

  const handleSaveSlot = () => {
    if (!startTime || !endTime) return;
    addWeeklySlot(addSlotModal.dayId, startTime, endTime, slotFormat);
    setAddSlotModal({ open: false, dayId: "", dayLabel: "" });
  };

  const totalActiveSlots = weeklyAvailability
    .filter((d) => d.active)
    .reduce((sum, d) => sum + d.slots.length, 0);

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={9} total={TOTAL_STEPS} title="Grille hebdomadaire" />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Vos disponibilités récurrentes</Text>
          <Text className="mb-4 text-[13.5px] text-ink-soft">
            Grille hebdomadaire : activez vos jours et ajoutez vos plages horaires d&apos;enseignement
          </Text>
        </FadeIn>

        {/* Weekly grid container */}
        <View className="gap-3">
          {weeklyAvailability.map((day, index) => (
            <FadeIn key={day.dayId} delay={60 + index * 25}>
              <View
                className={[
                  "rounded-xl border p-4 transition-colors",
                  day.active ? "border-line bg-surface" : "border-line/60 bg-paper-alt/60 opacity-70",
                ].join(" ")}
              >
                {/* Header du jour */}
                <View className="flex-row items-center justify-between">
                  <PressableScale
                    onPress={() => toggleWeeklyDay(day.dayId)}
                    accessibilityLabel={`Activer ou désactiver ${day.dayLabel}`}
                    style={{ flex: 1 }}
                  >
                    <View className="flex-row items-center gap-3">
                      <View
                        className={[
                          "h-6 w-6 items-center justify-center rounded-md border",
                          day.active ? "border-primary bg-primary" : "border-line bg-surface",
                        ].join(" ")}
                      >
                        {day.active ? <CheckIcon size={14} color="#fff" /> : null}
                      </View>
                      <Text
                        className={[
                          "text-[15.5px] font-bold",
                          day.active ? "text-ink" : "text-ink-soft",
                        ].join(" ")}
                      >
                        {day.dayLabel}
                      </Text>
                      {day.active ? (
                        <View className="rounded bg-accent-tint/60 px-2 py-0.5">
                          <Text className="text-[11px] font-bold text-accent">
                            {day.slots.length} créneau{day.slots.length > 1 ? "x" : ""}
                          </Text>
                        </View>
                      ) : (
                        <Text className="text-[12px] text-ink-faint">Indisponible</Text>
                      )}
                    </View>
                  </PressableScale>

                  {day.active ? (
                    <PressableScale
                      onPress={() => openAddSlot(day)}
                      accessibilityLabel={`Ajouter une plage horaire pour ${day.dayLabel}`}
                    >
                      <View className="flex-row items-center gap-1 rounded-full border border-primary bg-primary-tint/30 px-3 py-1.5">
                        <PlusIcon size={13} color="#332E86" />
                        <Text className="text-[12px] font-bold text-primary">Ajouter</Text>
                      </View>
                    </PressableScale>
                  ) : null}
                </View>

                {/* Plages horaires associées au jour */}
                {day.active && day.slots.length > 0 ? (
                  <View className="mt-3.5 flex-row flex-wrap gap-2 border-t border-line-soft pt-3">
                    {day.slots.map((slot) => (
                      <View
                        key={slot.id}
                        className="flex-row items-center gap-2 rounded-lg border border-line bg-paper px-3 py-2"
                      >
                        <ClockIcon size={13} color="#332E86" />
                        <Text className="text-[13px] font-bold text-ink">
                          {slot.startTime} - {slot.endTime}
                        </Text>
                        <View className="flex-row items-center gap-1 rounded bg-surface px-1.5 py-0.5">
                          {slot.format === "online" ? (
                            <VideoIcon size={11} color="#585B78" />
                          ) : (
                            <LocationIcon size={11} color="#585B78" />
                          )}
                          <Text className="text-[10.5px] font-semibold text-ink-soft">
                            {slot.format === "online"
                              ? "Visio"
                              : slot.format === "in_person"
                              ? "Présentiel"
                              : "Les deux"}
                          </Text>
                        </View>
                        <PressableScale
                          onPress={() => removeWeeklySlot(day.dayId, slot.id)}
                          accessibilityLabel="Supprimer ce créneau"
                        >
                          <View className="ml-1">
                            <TrashIcon size={12} color="#E04F5F" />
                          </View>
                        </PressableScale>
                      </View>
                    ))}
                  </View>
                ) : day.active ? (
                  <Text className="mt-2.5 text-[12px] italic text-ink-faint">
                    Aucune plage définie pour ce jour. Cliquez sur « Ajouter » pour définir vos heures.
                  </Text>
                ) : null}
              </View>
            </FadeIn>
          ))}
        </View>
      </ScrollView>

      {/* Modal Ajout Créneau */}
      <Modal visible={addSlotModal.open} transparent animationType="slide">
        <View className="flex-1 justify-end bg-black/50">
          <View
            className="rounded-t-2xl bg-surface p-5"
            style={{ paddingBottom: Math.max(insets.bottom, 24) }}
          >
            <View className="mb-4 flex-row items-center justify-between">
              <Text className="text-[18px] font-bold text-ink">
                Ajouter un créneau ({addSlotModal.dayLabel})
              </Text>
              <PressableScale
                onPress={() => setAddSlotModal({ open: false, dayId: "", dayLabel: "" })}
                accessibilityLabel="Fermer"
              >
                <View className="h-8 w-8 items-center justify-center rounded-full bg-paper">
                  <XIcon size={16} color="#585B78" />
                </View>
              </PressableScale>
            </View>

            <View className="mb-4 flex-row gap-3">
              <View className="flex-1">
                <Text className="mb-1 text-[12px] font-semibold text-ink-soft">Début (ex: 14:00)</Text>
                <TextInput
                  value={startTime}
                  onChangeText={setStartTime}
                  placeholder="14:00"
                  className="rounded-lg border border-line bg-paper px-3.5 py-2.5 text-[14.5px] font-bold text-ink"
                />
              </View>
              <View className="flex-1">
                <Text className="mb-1 text-[12px] font-semibold text-ink-soft">Fin (ex: 18:00)</Text>
                <TextInput
                  value={endTime}
                  onChangeText={setEndTime}
                  placeholder="18:00"
                  className="rounded-lg border border-line bg-paper px-3.5 py-2.5 text-[14.5px] font-bold text-ink"
                />
              </View>
            </View>

            <Text className="mb-2 text-[12px] font-semibold text-ink-soft">Format d&apos;enseignement</Text>
            <View className="mb-5 flex-row gap-2">
              {[
                { id: "both", label: "Présentiel & En ligne" },
                { id: "in_person", label: "Présentiel uniquement" },
                { id: "online", label: "En ligne uniquement" },
              ].map((opt) => (
                <PressableScale
                  key={opt.id}
                  onPress={() => setSlotFormat(opt.id as LocationFormatId)}
                  accessibilityLabel={opt.label}
                  style={{ flex: 1 }}
                >
                  <View
                    className={[
                      "items-center justify-center rounded-lg border p-2",
                      slotFormat === opt.id ? "border-primary bg-primary-tint/30" : "border-line bg-paper",
                    ].join(" ")}
                  >
                    <Text
                      className={[
                        "text-center text-[11px] font-bold",
                        slotFormat === opt.id ? "text-primary" : "text-ink-soft",
                      ].join(" ")}
                    >
                      {opt.label}
                    </Text>
                  </View>
                </PressableScale>
              ))}
            </View>

            <Button label="Valider la plage horaire" onPress={handleSaveSlot} />
          </View>
        </View>
      </Modal>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label={`Continuer (${totalActiveSlots} créneau${totalActiveSlots > 1 ? "x" : ""})`}
          onPress={() => router.push(TUTOR_DOCUMENTS_ROUTE)}
        />
      </View>
    </View>
  );
}
