import { type Href, useRouter } from "expo-router";
import { KeyboardAvoidingView, Platform, ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { useTutorApplicationStore } from "@/store/tutor-application.store";

const TUTOR_OFFER_ROUTE = "/tutor-offer" as Href;
const TOTAL_STEPS = 9;

export function TutorBioScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const bio = useTutorApplicationStore((s) => s.bio);
  const setBio = useTutorApplicationStore((s) => s.setBio);

  const canContinue = bio.trim().length > 0;

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-paper"
      style={{ paddingTop: insets.top }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={5} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Parlez de vous</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">
            Cette présentation apparaît sur votre profil public
          </Text>
        </FadeIn>

        <FadeIn delay={90}>
          <TextInput
            value={bio}
            onChangeText={setBio}
            placeholder="Développeur spécialisé…"
            placeholderTextColor="#9799AF"
            multiline
            textAlignVertical="top"
            className="h-[150px] rounded-sm border border-line bg-surface px-[14px] py-[13px] text-[15px] text-ink"
            accessibilityLabel="Présentation"
          />
          <Text className="mt-[10px] text-[12px] text-ink-faint">
            Exemple : « Développeur spécialisé en Python, j&apos;accompagne étudiants et professionnels
            depuis 4 ans. »
          </Text>
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" disabled={!canContinue} onPress={() => router.push(TUTOR_OFFER_ROUTE)} />
      </View>
    </KeyboardAvoidingView>
  );
}
