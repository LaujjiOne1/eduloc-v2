import { type Href, useRouter } from "expo-router";
import { useState } from "react";
import { Modal, ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { LocationIcon, PlusIcon, TrashIcon, XIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { useTutorApplicationStore } from "@/store/tutor-application.store";

const TUTOR_AVAILABILITY_ROUTE = "/tutor-availability" as Href;
const TOTAL_STEPS = 9;

const RADIUS_OPTIONS = [5, 10, 15, 20, 30];

export function TutorLocationsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const locations = useTutorApplicationStore((s) => s.locations);
  const updatePrimaryRadius = useTutorApplicationStore((s) => s.updatePrimaryRadius);
  const addSecondaryLocation = useTutorApplicationStore((s) => s.addSecondaryLocation);
  const removeLocation = useTutorApplicationStore((s) => s.removeLocation);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newLabel, setNewLabel] = useState("");
  const [newRadius, setNewRadius] = useState(10);

  const primaryLocation = locations.find((l) => l.isPrimary) ?? locations[0];
  const secondaryLocations = locations.filter((l) => !l.isPrimary);

  const handleAddSecondary = () => {
    if (!newLabel.trim()) return;
    addSecondaryLocation(newLabel.trim(), newRadius);
    setNewLabel("");
    setNewRadius(10);
    setIsAddModalOpen(false);
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={8} total={TOTAL_STEPS} title="Lieux & Rayons d'activité" />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Vos lieux d&apos;intervention</Text>
          <Text className="mb-4 text-[13.5px] text-ink-soft">
            Définissez votre zone principale et vos lieux secondaires avec leur rayon d&apos;activité
          </Text>
        </FadeIn>

        {/* Lieu principal */}
        {primaryLocation ? (
          <FadeIn delay={80}>
            <View className="mb-4 rounded-xl border border-primary/40 bg-surface p-4">
              <View className="flex-row items-center gap-2">
                <View className="h-8 w-8 items-center justify-center rounded-full bg-primary">
                  <LocationIcon size={16} color="#fff" />
                </View>
                <View className="flex-1">
                  <Text className="text-[15px] font-bold text-ink">{primaryLocation.label}</Text>
                  <Text className="text-[12px] font-semibold text-primary">Position principale</Text>
                </View>
              </View>

              {/* Sélection du rayon d'activité */}
              <View className="mt-3.5 border-t border-line-soft pt-3">
                <Text className="mb-2 text-[12px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
                  Rayon d&apos;activité autour du lieu : {primaryLocation.radiusKm} km
                </Text>
                <View className="flex-row gap-2">
                  {RADIUS_OPTIONS.map((km) => {
                    const isSelected = primaryLocation.radiusKm === km;
                    return (
                      <PressableScale
                        key={km}
                        onPress={() => updatePrimaryRadius(km)}
                        accessibilityLabel={`${km} km`}
                      >
                        <View
                          className={[
                            "items-center justify-center rounded-lg border px-3 py-1.5",
                            isSelected
                              ? "border-primary bg-primary"
                              : "border-line bg-paper",
                          ].join(" ")}
                        >
                          <Text
                            className={[
                              "text-[12.5px] font-bold",
                              isSelected ? "text-white" : "text-ink",
                            ].join(" ")}
                          >
                            {km} km
                          </Text>
                        </View>
                      </PressableScale>
                    );
                  })}
                </View>
              </View>
            </View>
          </FadeIn>
        ) : null}

        {/* Lieux secondaires */}
        <FadeIn delay={120}>
          <Text className="mb-2.5 text-[14px] font-bold text-ink">
            Lieux secondaires ({secondaryLocations.length})
          </Text>

          {secondaryLocations.length === 0 ? (
            <View className="mb-3 rounded-lg border border-dashed border-line bg-surface/60 p-4">
              <Text className="text-center text-[13px] text-ink-soft">
                Aucun lieu secondaire ajouté. Vous pouvez par exemple ajouter une bibliothèque, un campus ou un tiers-lieu.
              </Text>
            </View>
          ) : (
            <View className="mb-3 gap-2.5">
              {secondaryLocations.map((loc) => (
                <View
                  key={loc.id}
                  className="flex-row items-center gap-3 rounded-lg border border-line bg-surface p-3.5"
                >
                  <View className="h-9 w-9 items-center justify-center rounded-md bg-paper-alt">
                    <LocationIcon size={16} color="#585B78" />
                  </View>
                  <View className="flex-1">
                    <Text className="text-[14.5px] font-bold text-ink">{loc.label}</Text>
                    <Text className="text-[12px] text-ink-soft">Rayon dédié : {loc.radiusKm} km</Text>
                  </View>
                  <PressableScale
                    onPress={() => removeLocation(loc.id)}
                    accessibilityLabel={`Supprimer ${loc.label}`}
                  >
                    <View className="p-1">
                      <TrashIcon size={16} color="#E04F5F" />
                    </View>
                  </PressableScale>
                </View>
              ))}
            </View>
          )}

          <PressableScale
            onPress={() => setIsAddModalOpen(true)}
            accessibilityLabel="Ajouter un lieu secondaire"
          >
            <View className="flex-row items-center gap-2 rounded-lg border border-dashed border-primary bg-primary-tint/30 p-3.5">
              <PlusIcon size={17} color="#332E86" />
              <Text className="text-[14px] font-bold text-primary">Ajouter un lieu secondaire</Text>
            </View>
          </PressableScale>
        </FadeIn>
      </ScrollView>

      {/* Modal Ajout Lieu Secondaire */}
      <Modal visible={isAddModalOpen} transparent animationType="slide">
        <View className="flex-1 justify-end bg-black/50">
          <View
            className="rounded-t-2xl bg-surface p-5"
            style={{ paddingBottom: Math.max(insets.bottom, 24) }}
          >
            <View className="mb-4 flex-row items-center justify-between">
              <Text className="text-[18px] font-bold text-ink">Nouveau lieu secondaire</Text>
              <PressableScale onPress={() => setIsAddModalOpen(false)} accessibilityLabel="Fermer">
                <View className="h-8 w-8 items-center justify-center rounded-full bg-paper">
                  <XIcon size={16} color="#585B78" />
                </View>
              </PressableScale>
            </View>

            <Text className="mb-1 text-[12.5px] font-semibold text-ink-soft">
              Nom ou adresse du lieu secondaire *
            </Text>
            <TextInput
              value={newLabel}
              onChangeText={setNewLabel}
              placeholder="Ex: Bibliothèque François-Mitterrand, Paris 13e"
              placeholderTextColor="#9799AF"
              className="mb-4 rounded-lg border border-line bg-paper px-3.5 py-2.5 text-[14.5px] text-ink"
            />

            <Text className="mb-2 text-[12.5px] font-semibold text-ink-soft">
              Rayon d&apos;activité dédié ({newRadius} km)
            </Text>
            <View className="mb-5 flex-row gap-2">
              {RADIUS_OPTIONS.map((km) => (
                <PressableScale key={km} onPress={() => setNewRadius(km)} accessibilityLabel={`${km} km`}>
                  <View
                    className={[
                      "rounded-lg border px-3 py-1.5",
                      newRadius === km ? "border-primary bg-primary" : "border-line bg-paper",
                    ].join(" ")}
                  >
                    <Text
                      className={[
                        "text-[12.5px] font-bold",
                        newRadius === km ? "text-white" : "text-ink",
                      ].join(" ")}
                    >
                      {km} km
                    </Text>
                  </View>
                </PressableScale>
              ))}
            </View>

            <Button
              label="Ajouter ce lieu"
              disabled={!newLabel.trim()}
              onPress={handleAddSecondary}
            />
          </View>
        </View>
      </Modal>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" onPress={() => router.push(TUTOR_AVAILABILITY_ROUTE)} />
      </View>
    </View>
  );
}
