import { type Href, useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Modal, ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CheckIcon, PlusIcon, SearchIcon, XIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { type TutorSkillCatalogState, useTutorSkillCatalog } from "@/hooks/use-tutor-skill-catalog";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { TutorSkill } from "@/types/tutor-application";

const TUTOR_SUBJECTS_ROUTE = "/tutor-subjects" as Href;
const TOTAL_STEPS = 9;

export function TutorSkillsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state, retry } = useTutorSkillCatalog();
  const skills = useTutorApplicationStore((s) => s.skills);
  const toggleSkill = useTutorApplicationStore((s) => s.toggleSkill);
  const addCustomSkill = useTutorApplicationStore((s) => s.addCustomSkill);

  const [searchQuery, setSearchQuery] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [customName, setCustomName] = useState("");
  const [customCategory, setCustomCategory] = useState("");
  const [customScope, setCustomScope] = useState("");

  const canContinue = skills.length > 0;

  const handleAddCustom = () => {
    if (!customName.trim()) return;
    const newSkill: TutorSkill = {
      id: `custom-${Date.now()}`,
      label: customName.trim(),
      category: customCategory.trim() || "Compétence personnalisée",
      description: "Compétence ajoutée par le tuteur.",
      scope: customScope.trim() || "Accompagnement et cours particuliers sur mesure.",
    };
    addCustomSkill(newSkill);
    toggleSkill(newSkill);
    setCustomName("");
    setCustomCategory("");
    setCustomScope("");
    setIsAddModalOpen(false);
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={3} total={TOTAL_STEPS} title="Compétences" />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Qu&apos;enseignez-vous&nbsp;?</Text>
          <Text className="mb-4 text-[13.5px] text-ink-soft">
            Recherchez et sélectionnez toutes vos compétences et le périmètre de vos cours
          </Text>
        </FadeIn>

        {/* Module de recherche avancée */}
        <FadeIn delay={80}>
          <View className="mb-4 flex-row items-center gap-[10px] rounded-lg border border-line bg-surface px-[14px] py-3">
            <SearchIcon size={17} color="#9799AF" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Rechercher une compétence, un domaine..."
              placeholderTextColor="#9799AF"
              className="flex-1 text-[14.5px] text-ink"
              accessibilityLabel="Rechercher une compétence"
            />
            {searchQuery ? (
              <PressableScale onPress={() => setSearchQuery("")} accessibilityLabel="Effacer la recherche">
                <XIcon size={16} color="#9799AF" />
              </PressableScale>
            ) : null}
          </View>
        </FadeIn>

        <SkillList
          state={state}
          query={searchQuery}
          onRetry={retry}
          selectedIds={new Set(skills.map((s) => s.id))}
          onToggle={toggleSkill}
        />

        <FadeIn delay={180}>
          <PressableScale onPress={() => setIsAddModalOpen(true)} accessibilityLabel="Ajouter une compétence personnalisée">
            <View className="mt-4 flex-row items-center gap-2 rounded-lg border border-dashed border-primary bg-primary-tint/30 p-3.5">
              <PlusIcon size={17} color="#332E86" />
              <Text className="text-[14px] font-bold text-primary">Ajouter une compétence personnalisée</Text>
            </View>
          </PressableScale>
        </FadeIn>
      </ScrollView>

      {/* Modal Ajout Compétence */}
      <Modal visible={isAddModalOpen} transparent animationType="slide">
        <View className="flex-1 justify-end bg-black/50">
          <View
            className="rounded-t-2xl bg-surface p-5"
            style={{ paddingBottom: Math.max(insets.bottom, 24) }}
          >
            <View className="mb-4 flex-row items-center justify-between">
              <Text className="text-[18px] font-bold text-ink">Ajouter une compétence</Text>
              <PressableScale onPress={() => setIsAddModalOpen(false)} accessibilityLabel="Fermer">
                <View className="h-8 w-8 items-center justify-center rounded-full bg-paper">
                  <XIcon size={16} color="#585B78" />
                </View>
              </PressableScale>
            </View>

            <Text className="mb-1 text-[12.5px] font-semibold text-ink-soft">Nom de la matière ou compétence *</Text>
            <TextInput
              value={customName}
              onChangeText={setCustomName}
              placeholder="Ex: Espagnol conversationnel, Chimie organique..."
              placeholderTextColor="#9799AF"
              className="mb-3 rounded-lg border border-line bg-paper px-3.5 py-2.5 text-[14.5px] text-ink"
            />

            <Text className="mb-1 text-[12.5px] font-semibold text-ink-soft">Domaine / Catégorie</Text>
            <TextInput
              value={customCategory}
              onChangeText={setCustomCategory}
              placeholder="Ex: Langues vivantes, Sciences..."
              placeholderTextColor="#9799AF"
              className="mb-3 rounded-lg border border-line bg-paper px-3.5 py-2.5 text-[14.5px] text-ink"
            />

            <Text className="mb-1 text-[12.5px] font-semibold text-ink-soft">Périmètre du service proposé</Text>
            <TextInput
              value={customScope}
              onChangeText={setCustomScope}
              placeholder="Ex: Préparation au baccalauréat, remise à niveau..."
              placeholderTextColor="#9799AF"
              multiline
              numberOfLines={2}
              className="mb-5 rounded-lg border border-line bg-paper px-3.5 py-2.5 text-[14.5px] text-ink"
            />

            <Button
              label="Ajouter et sélectionner"
              disabled={!customName.trim()}
              onPress={handleAddCustom}
            />
          </View>
        </View>
      </Modal>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label={`Continuer (${skills.length} sélectionnée${skills.length > 1 ? "s" : ""})`}
          disabled={!canContinue}
          onPress={() => router.push(TUTOR_SUBJECTS_ROUTE)}
        />
      </View>
    </View>
  );
}

type SkillListProps = {
  state: TutorSkillCatalogState;
  query: string;
  onRetry: () => void;
  selectedIds: Set<string>;
  onToggle: (skill: TutorSkill) => void;
};

function SkillList({ state, query, onRetry, selectedIds, onToggle }: SkillListProps) {
  const storeSkills = useTutorApplicationStore((s) => s.skills);

  const mergedSkills = useMemo(() => {
    const list = state.status === "success" ? [...state.skills] : [];
    // Include custom skills added by user
    for (const sk of storeSkills) {
      if (!list.some((existing) => existing.id === sk.id)) {
        list.push(sk);
      }
    }
    const q = query.trim().toLowerCase();
    if (!q) return list;
    return list.filter(
      (sk) =>
        sk.label.toLowerCase().includes(q) ||
        (sk.category && sk.category.toLowerCase().includes(q)) ||
        (sk.description && sk.description.toLowerCase().includes(q)) ||
        (sk.scope && sk.scope.toLowerCase().includes(q)),
    );
  }, [state, storeSkills, query]);

  if (state.status === "loading" && storeSkills.length === 0) {
    return (
      <View className="gap-[10px]">
        {[0, 1, 2, 3].map((i) => (
          <View key={i} className="h-[74px] rounded-lg bg-line-soft" />
        ))}
      </View>
    );
  }

  if (state.status === "error" && storeSkills.length === 0) {
    return (
      <View className="flex-row items-center gap-3">
        <Text className="flex-1 text-[13.5px] text-error">{state.message}</Text>
        <PressableScale onPress={onRetry} accessibilityLabel="Réessayer de charger les compétences">
          <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
        </PressableScale>
      </View>
    );
  }

  if (mergedSkills.length === 0) {
    return (
      <View className="items-center py-6">
        <Text className="text-[13.5px] text-ink-faint">
          Aucune compétence ne correspond à « {query.trim()} ».
        </Text>
      </View>
    );
  }

  return (
    <View className="gap-[10px]">
      {mergedSkills.map((skill, index) => {
        const isSelected = selectedIds.has(skill.id);
        return (
          <FadeIn key={skill.id} delay={60 + index * 25}>
            <PressableScale onPress={() => onToggle(skill)} accessibilityLabel={skill.label}>
              <View
                className={[
                  "rounded-lg border p-3.5 transition-colors",
                  isSelected ? "border-primary bg-primary-tint/20" : "border-line bg-surface",
                ].join(" ")}
              >
                <View className="flex-row items-start justify-between gap-2">
                  <View className="flex-1">
                    <View className="flex-row items-center gap-2">
                      <Text className="text-[15px] font-bold text-ink">{skill.label}</Text>
                      {skill.category ? (
                        <View className="rounded bg-paper px-2 py-0.5">
                          <Text className="text-[11px] font-semibold text-ink-soft">{skill.category}</Text>
                        </View>
                      ) : null}
                    </View>

                    {skill.description ? (
                      <Text className="mt-1 text-[12.5px] leading-[17px] text-ink-soft">
                        {skill.description}
                      </Text>
                    ) : null}

                    {skill.scope ? (
                      <Text className="mt-1 text-[11.5px] italic text-primary">
                        Périmètre : {skill.scope}
                      </Text>
                    ) : null}
                  </View>

                  <View
                    className={[
                      "mt-0.5 h-5 w-5 items-center justify-center rounded border",
                      isSelected ? "border-primary bg-primary" : "border-line bg-paper",
                    ].join(" ")}
                  >
                    {isSelected ? <CheckIcon size={13} color="#fff" /> : null}
                  </View>
                </View>
              </View>
            </PressableScale>
          </FadeIn>
        );
      })}
    </View>
  );
}
