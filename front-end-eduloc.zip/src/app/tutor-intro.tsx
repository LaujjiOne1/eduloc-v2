import { TutorIntroScreen } from "@/screens/tutor-onboarding/tutor-intro-screen";

export default function TutorIntro() {
  return <TutorIntroScreen />;
}
