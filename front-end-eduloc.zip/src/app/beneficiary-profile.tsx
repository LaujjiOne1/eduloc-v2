import { BeneficiaryProfileScreen } from "@/screens/booking/beneficiary-profile-screen";

export default function BeneficiaryProfile() {
  return <BeneficiaryProfileScreen />;
}
