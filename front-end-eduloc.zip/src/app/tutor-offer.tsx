import { TutorOfferScreen } from "@/screens/tutor-onboarding/tutor-offer-screen";

export default function TutorOffer() {
  return <TutorOfferScreen />;
}
