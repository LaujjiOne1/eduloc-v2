import { DashboardScreen } from "@/screens/apprenti-dashboard/dashboard-screen";

export default function ApprentiDashboard() {
  return <DashboardScreen />;
}
