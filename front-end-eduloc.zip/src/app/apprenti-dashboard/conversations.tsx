import { ConversationsListScreen } from "@/screens/apprenti-dashboard/conversations-list-screen";

export default function Conversations() {
  return <ConversationsListScreen />;
}
