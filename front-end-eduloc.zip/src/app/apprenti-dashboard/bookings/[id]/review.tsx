import { ReviewTutorScreen } from "@/screens/apprenti-dashboard/review-tutor-screen";

export default function ApprentiReviewTutor() {
  return <ReviewTutorScreen />;
}
