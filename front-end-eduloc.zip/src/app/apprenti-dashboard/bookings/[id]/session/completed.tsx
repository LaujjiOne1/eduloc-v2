import { SessionCompletedScreen } from "@/screens/apprenti-dashboard/session-completed-screen";

export default function ApprentiSessionCompleted() {
  return <SessionCompletedScreen />;
}
