import { SessionInProgressScreen } from "@/screens/apprenti-dashboard/session-in-progress-screen";

export default function ApprentiSessionInProgress() {
  return <SessionInProgressScreen />;
}
