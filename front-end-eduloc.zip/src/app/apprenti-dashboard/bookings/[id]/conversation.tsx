import { ConversationScreen } from "@/screens/apprenti-dashboard/conversation-screen";

export default function ApprentiConversation() {
  return <ConversationScreen />;
}
