import { SessionOtpScreen } from "@/screens/apprenti-dashboard/session-otp-screen";

export default function ApprentiSessionOtp() {
  return <SessionOtpScreen />;
}
