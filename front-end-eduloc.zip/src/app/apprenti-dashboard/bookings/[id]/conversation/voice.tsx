import { VoiceRecordingScreen } from "@/screens/apprenti-dashboard/voice-recording-screen";

export default function ApprentiVoiceRecording() {
  return <VoiceRecordingScreen />;
}
