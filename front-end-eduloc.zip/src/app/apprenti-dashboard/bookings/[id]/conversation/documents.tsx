import { DocumentExchangeScreen } from "@/screens/apprenti-dashboard/document-exchange-screen";

export default function ApprentiDocumentExchange() {
  return <DocumentExchangeScreen />;
}
