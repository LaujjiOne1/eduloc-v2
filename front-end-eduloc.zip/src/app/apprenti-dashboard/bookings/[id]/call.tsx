import { CallScreen } from "@/screens/apprenti-dashboard/call-screen";

export default function ApprentiCall() {
  return <CallScreen />;
}
