import { MyBookingsScreen } from "@/screens/apprenti-dashboard/my-bookings-screen";

export default function ApprentiBookings() {
  return <MyBookingsScreen />;
}
