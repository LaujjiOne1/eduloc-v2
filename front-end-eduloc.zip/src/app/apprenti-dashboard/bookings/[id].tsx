import { BookingDetailScreen } from "@/screens/apprenti-dashboard/booking-detail-screen";

export default function ApprentiBookingDetail() {
  return <BookingDetailScreen />;
}
