import { TutorSkillsScreen } from "@/screens/tutor-onboarding/tutor-skills-screen";

export default function TutorSkills() {
  return <TutorSkillsScreen />;
}
