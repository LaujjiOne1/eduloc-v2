import { ModeChoiceScreen } from "@/screens/mode-choice-screen";

export default function ModeChoice() {
  return <ModeChoiceScreen />;
}
