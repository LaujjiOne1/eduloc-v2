import { BookingSummaryScreen } from "@/screens/booking/booking-summary-screen";

export default function BookingSummary() {
  return <BookingSummaryScreen />;
}
