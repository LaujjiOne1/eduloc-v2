import { TutorFormatScreen } from "@/screens/tutor-onboarding/tutor-format-screen";

export default function TutorFormat() {
  return <TutorFormatScreen />;
}
