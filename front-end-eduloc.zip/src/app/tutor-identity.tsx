import { TutorIdentityScreen } from "@/screens/tutor-onboarding/tutor-identity-screen";

export default function TutorIdentity() {
  return <TutorIdentityScreen />;
}
