import { BeneficiaryScreen } from "@/screens/booking/beneficiary-screen";

export default function Beneficiary() {
  return <BeneficiaryScreen />;
}
