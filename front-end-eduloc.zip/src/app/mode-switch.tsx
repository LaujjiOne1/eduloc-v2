import { ModeSwitchScreen } from "@/screens/mode-switch-screen";

export default function ModeSwitch() {
  return <ModeSwitchScreen />;
}
