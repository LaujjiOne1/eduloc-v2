import { TutorAvailabilityScreen } from "@/screens/tutor-onboarding/tutor-availability-screen";

export default function TutorAvailability() {
  return <TutorAvailabilityScreen />;
}
