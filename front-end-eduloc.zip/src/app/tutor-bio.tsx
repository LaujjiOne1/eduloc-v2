import { TutorBioScreen } from "@/screens/tutor-onboarding/tutor-bio-screen";

export default function TutorBio() {
  return <TutorBioScreen />;
}
