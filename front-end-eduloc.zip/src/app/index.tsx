import { SplashScreen } from "@/screens/splash-screen";

export default function Index() {
  return <SplashScreen />;
}
