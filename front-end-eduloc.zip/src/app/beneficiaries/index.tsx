import { BeneficiariesScreen } from "@/screens/beneficiaries/beneficiaries-screen";

export default function Beneficiaries() {
  return <BeneficiariesScreen />;
}
