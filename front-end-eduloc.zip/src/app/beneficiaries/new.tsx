import { AddBeneficiaryScreen } from "@/screens/beneficiaries/add-beneficiary-screen";

export default function NewBeneficiary() {
  return <AddBeneficiaryScreen />;
}
