import { TutorLocationsScreen } from "@/screens/tutor-onboarding/tutor-locations-screen";

export default function TutorLocations() {
  return <TutorLocationsScreen />;
}
