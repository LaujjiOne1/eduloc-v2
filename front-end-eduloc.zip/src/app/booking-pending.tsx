import { BookingPendingScreen } from "@/screens/booking/booking-pending-screen";

export default function BookingPending() {
  return <BookingPendingScreen />;
}
