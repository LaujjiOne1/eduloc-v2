import { VerifyScreen } from "@/screens/booking/verify-screen";

export default function Verify() {
  return <VerifyScreen />;
}
