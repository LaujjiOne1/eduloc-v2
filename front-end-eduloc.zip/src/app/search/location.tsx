import { LocationScreen } from "@/screens/search/location-screen";

export default function SearchLocation() {
  return <LocationScreen />;
}
