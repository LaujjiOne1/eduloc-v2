import { ForWhomScreen } from "@/screens/search/for-whom-screen";

export default function SearchForWhom() {
  return <ForWhomScreen />;
}
