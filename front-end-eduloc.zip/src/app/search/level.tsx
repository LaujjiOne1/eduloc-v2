import { LevelScreen } from "@/screens/search/level-screen";

export default function SearchLevel() {
  return <LevelScreen />;
}
