import { SearchSummaryScreen } from "@/screens/search/summary-screen";

export default function SearchSummaryRoute() {
  return <SearchSummaryScreen />;
}
