import { ObjectiveScreen } from "@/screens/search/objective-screen";

export default function SearchObjective() {
  return <ObjectiveScreen />;
}
