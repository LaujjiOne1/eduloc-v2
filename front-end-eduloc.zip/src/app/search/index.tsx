import { NeedScreen } from "@/screens/search/need-screen";

export default function Search() {
  return <NeedScreen />;
}
