import { DetailScreen } from "@/screens/search/detail-screen";

export default function SearchDetail() {
  return <DetailScreen />;
}
