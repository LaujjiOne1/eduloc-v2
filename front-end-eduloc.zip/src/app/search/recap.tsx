import { SearchSummaryScreen } from "@/screens/search/summary-screen";

export default function SearchRecapRoute() {
  return <SearchSummaryScreen />;
}
