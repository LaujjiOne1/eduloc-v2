import { AccountScreen } from "@/screens/account-screen";

export default function Account() {
  return <AccountScreen />;
}
