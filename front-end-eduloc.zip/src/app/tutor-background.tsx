import { TutorBackgroundScreen } from "@/screens/tutor-onboarding/tutor-background-screen";

export default function TutorBackground() {
  return <TutorBackgroundScreen />;
}
