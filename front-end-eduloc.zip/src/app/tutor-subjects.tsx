import { TutorSubjectsScreen } from "@/screens/tutor-onboarding/tutor-subjects-screen";

export default function TutorSubjects() {
  return <TutorSubjectsScreen />;
}
