import { TutorDocumentsScreen } from "@/screens/tutor-onboarding/tutor-documents-screen";

export default function TutorDocuments() {
  return <TutorDocumentsScreen />;
}
