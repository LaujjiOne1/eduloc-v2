import { MyProfileScreen } from "@/screens/tutor-dashboard/my-profile-screen";

export default function TutorProfile() {
  return <MyProfileScreen />;
}
