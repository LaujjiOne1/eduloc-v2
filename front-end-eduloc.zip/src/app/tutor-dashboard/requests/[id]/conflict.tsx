import { RequestConflictScreen } from "@/screens/tutor-dashboard/request-conflict-screen";

export default function TutorRequestConflict() {
  return <RequestConflictScreen />;
}
