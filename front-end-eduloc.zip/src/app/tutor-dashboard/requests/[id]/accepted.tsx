import { RequestAcceptedScreen } from "@/screens/tutor-dashboard/request-accepted-screen";

export default function TutorRequestAccepted() {
  return <RequestAcceptedScreen />;
}
