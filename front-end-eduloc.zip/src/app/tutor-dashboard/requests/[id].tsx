import { RequestDetailScreen } from "@/screens/tutor-dashboard/request-detail-screen";

export default function TutorRequestDetail() {
  return <RequestDetailScreen />;
}
