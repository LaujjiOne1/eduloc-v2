import { RequestsScreen } from "@/screens/tutor-dashboard/requests-screen";

export default function TutorRequests() {
  return <RequestsScreen />;
}
