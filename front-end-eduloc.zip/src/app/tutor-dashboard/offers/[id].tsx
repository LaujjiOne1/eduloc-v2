import { ManageOfferScreen } from "@/screens/tutor-dashboard/manage-offer-screen";

export default function EditTutorOffer() {
  return <ManageOfferScreen />;
}
