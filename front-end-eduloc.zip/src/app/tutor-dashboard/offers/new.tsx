import { ManageOfferScreen } from "@/screens/tutor-dashboard/manage-offer-screen";

export default function NewTutorOffer() {
  return <ManageOfferScreen />;
}
