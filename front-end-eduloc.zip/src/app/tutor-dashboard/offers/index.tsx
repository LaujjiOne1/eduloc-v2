import { OffersScreen } from "@/screens/tutor-dashboard/offers-screen";

export default function TutorOffers() {
  return <OffersScreen />;
}
