import { TutorAppointmentsScreen } from "@/screens/tutor-dashboard/appointments-screen";

export default function TutorAppointments() {
  return <TutorAppointmentsScreen />;
}
