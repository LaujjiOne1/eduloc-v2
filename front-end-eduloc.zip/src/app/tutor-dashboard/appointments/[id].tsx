import { TutorAppointmentDetailScreen } from "@/screens/tutor-dashboard/appointment-detail-screen";

export default function TutorAppointmentDetail() {
  return <TutorAppointmentDetailScreen />;
}
