import { TutorAppointmentConversationScreen } from "@/screens/tutor-dashboard/appointment-conversation-screen";

export default function TutorAppointmentConversation() {
  return <TutorAppointmentConversationScreen />;
}
