import { StartSessionScreen } from "@/screens/tutor-dashboard/start-session-screen";

export default function TutorAppointmentStartSession() {
  return <StartSessionScreen />;
}
