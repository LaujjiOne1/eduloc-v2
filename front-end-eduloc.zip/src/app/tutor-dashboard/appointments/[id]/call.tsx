import { TutorAppointmentCallScreen } from "@/screens/tutor-dashboard/appointment-call-screen";

export default function TutorAppointmentCall() {
  return <TutorAppointmentCallScreen />;
}
