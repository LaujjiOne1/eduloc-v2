import { TutorVoiceRecordingScreen } from "@/screens/tutor-dashboard/appointment-voice-recording-screen";

export default function TutorAppointmentVoiceRecording() {
  return <TutorVoiceRecordingScreen />;
}
