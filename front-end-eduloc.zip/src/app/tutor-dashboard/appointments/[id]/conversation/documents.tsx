import { TutorDocumentExchangeScreen } from "@/screens/tutor-dashboard/appointment-document-exchange-screen";

export default function TutorAppointmentDocumentExchange() {
  return <TutorDocumentExchangeScreen />;
}
