import { SessionInProgressPresentialScreen } from "@/screens/tutor-dashboard/session-in-progress-presential-screen";

export default function TutorAppointmentSessionPresential() {
  return <SessionInProgressPresentialScreen />;
}
