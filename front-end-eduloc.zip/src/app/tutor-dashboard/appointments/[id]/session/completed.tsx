import { TutorSessionCompletedScreen } from "@/screens/tutor-dashboard/complete-session-screen";

export default function TutorAppointmentSessionCompleted() {
  return <TutorSessionCompletedScreen />;
}
