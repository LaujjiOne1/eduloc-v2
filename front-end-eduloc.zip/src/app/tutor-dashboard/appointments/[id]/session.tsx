import { TutorSessionInProgressScreen } from "@/screens/tutor-dashboard/session-in-progress-screen";

export default function TutorAppointmentSession() {
  return <TutorSessionInProgressScreen />;
}
