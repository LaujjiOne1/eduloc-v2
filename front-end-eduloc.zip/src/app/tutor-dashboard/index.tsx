import { DashboardScreen } from "@/screens/tutor-dashboard/dashboard-screen";

export default function TutorDashboard() {
  return <DashboardScreen />;
}
