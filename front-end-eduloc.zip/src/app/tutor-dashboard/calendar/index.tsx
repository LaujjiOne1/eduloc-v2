import { CalendarScreen } from "@/screens/tutor-dashboard/calendar-screen";

export default function TutorCalendar() {
  return <CalendarScreen />;
}
