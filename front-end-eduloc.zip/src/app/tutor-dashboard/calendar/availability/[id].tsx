import { AvailabilityEditScreen } from "@/screens/tutor-dashboard/availability-edit-screen";

export default function EditTutorAvailability() {
  return <AvailabilityEditScreen />;
}
