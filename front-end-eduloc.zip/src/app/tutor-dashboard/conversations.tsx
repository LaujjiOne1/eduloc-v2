import { TutorConversationsListScreen } from "@/screens/tutor-dashboard/conversations-list-screen";

export default function TutorConversationsPage() {
  return <TutorConversationsListScreen />;
}
