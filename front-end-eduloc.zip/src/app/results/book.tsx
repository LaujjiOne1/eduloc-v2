import { BookDateScreen } from "@/screens/booking/book-date-screen";

export default function Book() {
  return <BookDateScreen />;
}
