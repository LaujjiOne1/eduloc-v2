import { TutorProfileScreen } from "@/screens/results/tutor-profile-screen";

export default function TutorProfile() {
  return <TutorProfileScreen />;
}
