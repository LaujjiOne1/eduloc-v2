import { ResultsMapScreen } from "@/screens/results/results-map-screen";

export default function ResultsMap() {
  return <ResultsMapScreen />;
}
