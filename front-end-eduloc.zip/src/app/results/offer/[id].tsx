import { OfferDetailScreen } from "@/screens/results/offer-detail-screen";

export default function OfferDetail() {
  return <OfferDetailScreen />;
}
