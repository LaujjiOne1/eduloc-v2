import { ResultsScreen } from "@/screens/results/results-screen";

export default function Results() {
  return <ResultsScreen />;
}
