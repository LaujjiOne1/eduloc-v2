import { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Platform, Text, View } from "react-native";
import type { Map as MapLibreMap, Marker } from "maplibre-gl";

import type { Tutor } from "@/types/tutor";

interface MapLibreResultsMapProps {
  tutors: Tutor[];
  selectedTutorId: string | null;
  onSelectTutor: (tutor: Tutor) => void;
  searchLocationQuery?: string;
}

// Fallback coordinates (Antananarivo center)
const DEFAULT_CENTER: [number, number] = [47.525, -18.895]; // [lng, lat]
const DEFAULT_ZOOM = 13;

// Free open-source vector tile style via OpenFreeMap (light positron theme, matching EduLoc tokens)
const MAP_STYLE_URL = "https://tiles.openfreemap.org/styles/positron";
const FALLBACK_STYLE_URL = "https://demotiles.maplibre.org/style.json";

function getCoordinatesForTutor(tutor: Tutor, index: number): [number, number] {
  if (tutor.location.longitude != null && tutor.location.latitude != null) {
    return [tutor.location.longitude, tutor.location.latitude];
  }

  // Fallback offset around default center if no coordinates provided
  const angle = (index * 2 * Math.PI) / 3;
  const radius = 0.012; // ~1.3km
  return [DEFAULT_CENTER[0] + radius * Math.cos(angle), DEFAULT_CENTER[1] + radius * Math.sin(angle)];
}

function createMarkerElement(isSelected: boolean): HTMLElement {
  const container = document.createElement("div");
  container.className = "eduloc-marker-wrapper";

  const pin = document.createElement("div");
  pin.className = `eduloc-marker-pin ${isSelected ? "is-selected" : ""}`;

  const iconWrapper = document.createElement("div");
  iconWrapper.className = "eduloc-marker-icon";

  // SVG graduation cap icon
  iconWrapper.innerHTML = `
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="${
      isSelected ? "#ffffff" : "#332e86"
    }" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z"/>
      <path d="M22 10v6"/>
      <path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5"/>
    </svg>
  `;

  pin.appendChild(iconWrapper);
  container.appendChild(pin);
  return container;
}

export function MapLibreResultsMap({
  tutors,
  selectedTutorId,
  onSelectTutor,
}: MapLibreResultsMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<MapLibreMap | null>(null);
  const markersRef = useRef<Map<string, Marker>>(new Map());
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);

  // Initialize MapLibre GL map
  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined" || !containerRef.current) {
      return;
    }

    let isMounted = true;

    async function init() {
      try {
        const maplibregl = await import("maplibre-gl");

        if (!isMounted || !containerRef.current) return;

        // Ensure MapLibre Web Worker loads correctly from local static files
        const localWorkerUrl =
          typeof window !== "undefined" && window.location?.origin
            ? `${window.location.origin}/maplibre-gl/maplibre-gl-worker.mjs`
            : "/maplibre-gl/maplibre-gl-worker.mjs";

        try {
          if (typeof maplibregl.setWorkerUrl === "function") {
            maplibregl.setWorkerUrl(localWorkerUrl);
          } else if (maplibregl.config) {
            maplibregl.config.WORKER_URL = localWorkerUrl;
          }
        } catch (_) {}

        // Determine starting center
        let initialCenter = DEFAULT_CENTER;
        if (tutors.length > 0) {
          const firstTutor = tutors[0];
          initialCenter = getCoordinatesForTutor(firstTutor, 0);
        }

        const mapInstance = new maplibregl.Map({
          container: containerRef.current,
          style: MAP_STYLE_URL,
          center: initialCenter,
          zoom: DEFAULT_ZOOM,
          attributionControl: false,
        });

        mapRef.current = mapInstance;

        // Custom navigation controls
        mapInstance.addControl(
          new maplibregl.NavigationControl({
            showCompass: false,
            visualizePitch: false,
          }),
          "top-right",
        );

        // Fallback style if primary fails
        mapInstance.on("error", (e) => {
          // If style failed to load, retry with demotiles
          if (e.error && "message" in e.error && e.error.message.includes("style")) {
            try {
              mapInstance.setStyle(FALLBACK_STYLE_URL);
            } catch {
              // Ignore style fallback error
            }
          }
        });

        mapInstance.on("load", () => {
          if (!isMounted) return;
          setMapLoaded(true);

          // Fit bounds to tutors if multiple
          if (tutors.length > 1) {
            const bounds = new maplibregl.LngLatBounds();
            tutors.forEach((tutor, idx) => {
              bounds.extend(getCoordinatesForTutor(tutor, idx));
            });
            mapInstance.fitBounds(bounds, {
              padding: { top: 60, bottom: 130, left: 40, right: 40 },
              maxZoom: 14,
              duration: 800,
            });
          }
        });
      } catch (err) {
        console.error("Failed to initialize MapLibre map:", err);
        if (isMounted) {
          setMapError("Impossible de charger la carte.");
        }
      }
    }

    init();

    return () => {
      isMounted = false;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Update markers when tutors or selection changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded || typeof window === "undefined") return;

    let isMounted = true;

    async function syncMarkers() {
      const maplibregl = await import("maplibre-gl");
      if (!isMounted || !mapRef.current) return;

      // Remove existing markers
      markersRef.current.forEach((marker) => marker.remove());
      markersRef.current.clear();

      // Add marker for each tutor
      tutors.forEach((tutor, index) => {
        const isSelected = tutor.id === selectedTutorId;
        const coords = getCoordinatesForTutor(tutor, index);
        const el = createMarkerElement(isSelected);

        el.addEventListener("click", (e) => {
          e.stopPropagation();
          onSelectTutor(tutor);

          if (mapRef.current) {
            mapRef.current.flyTo({
              center: coords,
              zoom: Math.max(mapRef.current.getZoom(), 13.5),
              speed: 1.1,
              curve: 1.4,
              essential: true,
            });
          }
        });

        const marker = new maplibregl.Marker({
          element: el,
          anchor: "bottom",
        })
          .setLngLat(coords)
          .addTo(map);

        markersRef.current.set(tutor.id, marker);
      });
    }

    syncMarkers();

    return () => {
      isMounted = false;
    };
  }, [tutors, selectedTutorId, mapLoaded, onSelectTutor]);

  // Center on selected tutor if selection changed from outside
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded || !selectedTutorId) return;

    const selectedTutor = tutors.find((t) => t.id === selectedTutorId);
    if (!selectedTutor) return;

    const index = tutors.indexOf(selectedTutor);
    const coords = getCoordinatesForTutor(selectedTutor, index);

    map.flyTo({
      center: coords,
      zoom: Math.max(map.getZoom(), 13.5),
      speed: 1.1,
      curve: 1.4,
      essential: true,
    });
  }, [selectedTutorId, mapLoaded, tutors]);

  if (mapError) {
    return (
      <View className="flex-1 items-center justify-center p-6 bg-paper-alt">
        <Text className="text-center text-[13.5px] text-ink-soft">{mapError}</Text>
      </View>
    );
  }

  return (
    <View className="relative flex-1 bg-paper-alt overflow-hidden">
      {/* Real MapLibre GL DOM Container */}
      <div
        ref={containerRef}
        style={{
          width: "100%",
          height: "100%",
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
        }}
      />

      {/* Loading overlay while map initializes */}
      {!mapLoaded && (
        <View className="absolute inset-0 items-center justify-center bg-paper-alt/80">
          <ActivityIndicator size="small" color="#332E86" />
          <Text className="mt-2 text-[13px] text-ink-soft">Chargement de la carte MapLibre...</Text>
        </View>
      )}
    </View>
  );
}
