import * as React from "react";
import {
  animate,
  type MotionValue,
  motion,
  type PanInfo,
  useMotionValue,
  useTransform,
} from "framer-motion";

import { cn } from "@/lib/utils";

export interface DateWheelPickerProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  value?: Date;
  onChange: (date: Date) => void;
  minYear?: number;
  maxYear?: number;
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  locale?: string;
  onDecadeSelect?: (year: number) => void;
}

const ITEM_HEIGHT = 40;
const VISIBLE_ITEMS = 5;
const PERSPECTIVE_ORIGIN = ITEM_HEIGHT * 2;

function getMonthNames(locale = "fr-FR"): string[] {
  const formatter = new Intl.DateTimeFormat(locale, { month: "long" });
  return Array.from({ length: 12 }, (_, i) => {
    const raw = formatter.format(new Date(2000, i, 1));
    return raw.charAt(0).toUpperCase() + raw.slice(1);
  });
}

const sizeConfig = {
  sm: {
    height: ITEM_HEIGHT * VISIBLE_ITEMS * 0.8,
    itemHeight: ITEM_HEIGHT * 0.8,
    fontSize: "text-sm",
    gap: "gap-2",
  },
  md: {
    height: ITEM_HEIGHT * VISIBLE_ITEMS,
    itemHeight: ITEM_HEIGHT,
    fontSize: "text-base",
    gap: "gap-3",
  },
  lg: {
    height: ITEM_HEIGHT * VISIBLE_ITEMS * 1.2,
    itemHeight: ITEM_HEIGHT * 1.2,
    fontSize: "text-lg",
    gap: "gap-5",
  },
};

interface WheelItemProps {
  item: string | number;
  index: number;
  y: MotionValue<number>;
  itemHeight: number;
  visibleItems: number;
  centerOffset: number;
  isSelected: boolean;
  disabled?: boolean;
  onClick: () => void;
}

function WheelItem({
  item,
  index,
  y,
  itemHeight,
  visibleItems,
  centerOffset,
  isSelected,
  disabled,
  onClick,
}: WheelItemProps) {
  const itemY = useTransform(y, (latest) => {
    const offset = index * itemHeight + latest + centerOffset;
    return offset;
  });

  const rotateX = useTransform(
    itemY,
    [0, centerOffset, itemHeight * visibleItems],
    [45, 0, -45]
  );

  const scale = useTransform(
    itemY,
    [0, centerOffset, itemHeight * visibleItems],
    [0.85, 1.05, 0.85]
  );

  const opacity = useTransform(
    itemY,
    [0, centerOffset * 0.5, centerOffset, centerOffset * 1.5, itemHeight * visibleItems],
    [0.25, 0.55, 1, 0.55, 0.25]
  );

  return (
    <motion.div
      className="flex select-none items-center justify-center cursor-pointer"
      style={{
        height: itemHeight,
        rotateX,
        scale,
        opacity,
        transformStyle: "preserve-3d",
        transformOrigin: `center center -${PERSPECTIVE_ORIGIN}px`,
      }}
      onClick={() => !disabled && onClick()}
    >
      <span
        className={cn(
          "transition-colors truncate px-1",
          isSelected
            ? "font-bold text-primary scale-105"
            : "font-medium text-[#606482]"
        )}
      >
        {item}
      </span>
    </motion.div>
  );
}

interface WheelColumnProps {
  items: (string | number)[];
  value: number;
  onChange: (index: number) => void;
  itemHeight: number;
  visibleItems: number;
  disabled?: boolean;
  className?: string;
  ariaLabel: string;
}

function WheelColumn({
  items,
  value,
  onChange,
  itemHeight,
  visibleItems,
  disabled,
  className,
  ariaLabel,
}: WheelColumnProps) {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const y = useMotionValue(-value * itemHeight);
  const centerOffset = Math.floor(visibleItems / 2) * itemHeight;

  const valueRef = React.useRef(value);
  const onChangeRef = React.useRef(onChange);
  const itemsLengthRef = React.useRef(items.length);

  React.useEffect(() => {
    valueRef.current = value;
    onChangeRef.current = onChange;
    itemsLengthRef.current = items.length;
  });

  React.useEffect(() => {
    animate(y, -value * itemHeight, {
      type: "spring",
      stiffness: 320,
      damping: 32,
    });
  }, [value, itemHeight, y]);

  const handleDragEnd = (_: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (disabled) return;

    const currentY = y.get();
    const velocity = info.velocity.y;
    const projectedY = currentY + velocity * 0.2;

    let newIndex = Math.round(-projectedY / itemHeight);
    newIndex = Math.max(0, Math.min(items.length - 1, newIndex));

    onChange(newIndex);
  };

  React.useEffect(() => {
    const container = containerRef.current;
    if (!container || disabled) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const direction = e.deltaY > 0 ? 1 : -1;
      const currentValue = valueRef.current;
      const maxIndex = itemsLengthRef.current - 1;
      const newIndex = Math.max(0, Math.min(maxIndex, currentValue + direction));

      if (newIndex !== currentValue) {
        onChangeRef.current(newIndex);
      }
    };

    container.addEventListener("wheel", handleWheel, { passive: false });

    return () => {
      container.removeEventListener("wheel", handleWheel);
    };
  }, [disabled]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (disabled) return;

    const maxIndex = items.length - 1;
    let newIndex = value;

    switch (e.key) {
      case "ArrowUp":
        e.preventDefault();
        newIndex = Math.max(0, value - 1);
        break;
      case "ArrowDown":
        e.preventDefault();
        newIndex = Math.min(maxIndex, value + 1);
        break;
      case "Home":
        e.preventDefault();
        newIndex = 0;
        break;
      case "End":
        e.preventDefault();
        newIndex = maxIndex;
        break;
      case "PageUp":
        e.preventDefault();
        newIndex = Math.max(0, value - 5);
        break;
      case "PageDown":
        e.preventDefault();
        newIndex = Math.min(maxIndex, value + 5);
        break;
      default:
        return;
    }

    if (newIndex !== value) {
      onChange(newIndex);
    }
  };

  const dragConstraints = React.useMemo(
    () => ({
      top: -(items.length - 1) * itemHeight,
      bottom: 0,
    }),
    [items.length, itemHeight]
  );

  return (
    <div
      ref={containerRef}
      className={cn(
        "relative overflow-hidden outline-none select-none",
        disabled && "opacity-50 pointer-events-none",
        className
      )}
      style={{ height: itemHeight * visibleItems }}
      tabIndex={disabled ? -1 : 0}
      onKeyDown={handleKeyDown}
      role="spinbutton"
      aria-label={ariaLabel}
      aria-valuenow={value}
      aria-valuemin={0}
      aria-valuemax={items.length - 1}
      aria-valuetext={String(items[value])}
      aria-disabled={disabled}
    >
      {/* Top Gradient Fade */}
      <div
        className="absolute inset-x-0 top-0 z-10 pointer-events-none"
        style={{
          height: centerOffset,
          background: "linear-gradient(to bottom, #FFFFFF 15%, rgba(255,255,255,0) 100%)",
        }}
        aria-hidden="true"
      />

      {/* Bottom Gradient Fade */}
      <div
        className="absolute inset-x-0 bottom-0 z-10 pointer-events-none"
        style={{
          height: centerOffset,
          background: "linear-gradient(to top, #FFFFFF 15%, rgba(255,255,255,0) 100%)",
        }}
        aria-hidden="true"
      />

      {/* Center Highlight Bar (EduLoc border & tint) */}
      <div
        className="absolute inset-x-0 z-5 pointer-events-none border-y border-[#332E86]/25 bg-[#332E86]/5 rounded-sm"
        style={{
          top: centerOffset,
          height: itemHeight,
        }}
        aria-hidden="true"
      />

      {/* Draggable Column */}
      <motion.div
        className="cursor-grab active:cursor-grabbing"
        style={{
          y,
          paddingTop: centerOffset,
          paddingBottom: centerOffset,
        }}
        drag="y"
        dragConstraints={dragConstraints}
        dragElastic={0.15}
        onDragEnd={handleDragEnd}
      >
        {items.map((item, index) => (
          <WheelItem
            key={`${item}-${index}`}
            item={item}
            index={index}
            y={y}
            itemHeight={itemHeight}
            visibleItems={visibleItems}
            centerOffset={centerOffset}
            isSelected={index === value}
            disabled={disabled}
            onClick={() => onChange(index)}
          />
        ))}
      </motion.div>
    </div>
  );
}

function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate();
}

export const DateWheelPicker = React.forwardRef<HTMLDivElement, DateWheelPickerProps>(
  (
    {
      value,
      onChange,
      minYear = 1920,
      maxYear = new Date().getFullYear() - 15,
      size = "md",
      disabled = false,
      locale = "fr-FR",
      className,
      ...props
    },
    ref
  ) => {
    const config = sizeConfig[size];

    const months = React.useMemo(() => getMonthNames(locale), [locale]);

    // Years descending: e.g. 2011, 2010, ... 1997 ... 1920
    const years = React.useMemo(() => {
      const arr: number[] = [];
      for (let y = maxYear; y >= minYear; y--) {
        arr.push(y);
      }
      return arr;
    }, [minYear, maxYear]);

    const [dateState, setDateState] = React.useState(() => {
      const currentDate = value || new Date(1997, 4, 12);
      return {
        day: currentDate.getDate(),
        month: currentDate.getMonth(),
        year: currentDate.getFullYear(),
      };
    });

    const isInternalChange = React.useRef(false);

    const days = React.useMemo(() => {
      const daysCount = getDaysInMonth(dateState.year, dateState.month);
      return Array.from({ length: daysCount }, (_, i) => i + 1);
    }, [dateState.month, dateState.year]);

    const handleDayChange = React.useCallback((dayIndex: number) => {
      isInternalChange.current = true;
      setDateState((prev) => ({ ...prev, day: dayIndex + 1 }));
    }, []);

    const handleMonthChange = React.useCallback((monthIndex: number) => {
      isInternalChange.current = true;
      setDateState((prev) => {
        const daysInNewMonth = getDaysInMonth(prev.year, monthIndex);
        const adjustedDay = Math.min(prev.day, daysInNewMonth);
        return { ...prev, month: monthIndex, day: adjustedDay };
      });
    }, []);

    const handleYearChange = React.useCallback(
      (yearIndex: number) => {
        isInternalChange.current = true;
        setDateState((prev) => {
          const newYear = years[yearIndex];
          const daysInNewMonth = getDaysInMonth(newYear, prev.month);
          const adjustedDay = Math.min(prev.day, daysInNewMonth);
          return { ...prev, year: newYear, day: adjustedDay };
        });
      },
      [years]
    );

    React.useEffect(() => {
      if (isInternalChange.current) {
        const newDate = new Date(dateState.year, dateState.month, dateState.day);
        onChange(newDate);
        isInternalChange.current = false;
      }
    }, [dateState, onChange]);

    React.useEffect(() => {
      if (value && !isInternalChange.current) {
        const valueDay = value.getDate();
        const valueMonth = value.getMonth();
        const valueYear = value.getFullYear();

        if (
          valueDay !== dateState.day ||
          valueMonth !== dateState.month ||
          valueYear !== dateState.year
        ) {
          setDateState({
            day: valueDay,
            month: valueMonth,
            year: valueYear,
          });
        }
      }
    }, [value, dateState.day, dateState.month, dateState.year]);

    const yearIndex = years.indexOf(dateState.year);

    // Jump to a specific decade or year
    const jumpToYear = React.useCallback(
      (targetYear: number) => {
        const idx = years.indexOf(targetYear);
        if (idx >= 0) {
          handleYearChange(idx);
        }
      },
      [years, handleYearChange]
    );

    return (
      <div
        ref={ref}
        className={cn(
          "flex flex-col items-center justify-center w-full",
          disabled && "opacity-50 pointer-events-none",
          className
        )}
        role="group"
        aria-label="Date wheel picker"
        {...props}
      >
        {/* Quick decade jump bar */}
        <div className="flex items-center justify-center gap-1.5 mb-2 w-full flex-wrap">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#9799AF] mr-1">
            Décennie :
          </span>
          {[2000, 1990, 1980, 1970, 1960].map((dec) => {
            const isCurrentDecade =
              Math.floor(dateState.year / 10) * 10 === dec;
            return (
              <button
                key={dec}
                type="button"
                onClick={() => jumpToYear(dec + 5)}
                className={cn(
                  "px-2 py-0.5 text-[11.5px] font-bold rounded-full transition-all border",
                  isCurrentDecade
                    ? "bg-primary text-white border-primary shadow-xs"
                    : "bg-[#F7F6F2] text-[#606482] border-[#E7E3D7] hover:bg-[#EFECE3]"
                )}
              >
                {dec}s
              </button>
            );
          })}
        </div>

        {/* 3D Wheel Pickers in Row: Jour (Day), Mois (Month), Année (Year) */}
        <div
          className={cn(
            "flex items-center justify-center w-full rounded-xl border border-[#E7E3D7] bg-white px-2 py-1 shadow-inner",
            config.gap,
            config.fontSize
          )}
          style={{ perspective: "1000px" }}
        >
          {/* Day Column */}
          <div className="flex flex-col items-center">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-[#9799AF] mb-0.5">
              Jour
            </span>
            <WheelColumn
              items={days}
              value={dateState.day - 1}
              onChange={handleDayChange}
              itemHeight={config.itemHeight}
              visibleItems={VISIBLE_ITEMS}
              disabled={disabled}
              className="w-14"
              ariaLabel="Sélectionner le jour"
            />
          </div>

          <div className="h-28 w-[1px] bg-[#E7E3D7]" />

          {/* Month Column */}
          <div className="flex flex-col items-center">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-[#9799AF] mb-0.5">
              Mois
            </span>
            <WheelColumn
              items={months}
              value={dateState.month}
              onChange={handleMonthChange}
              itemHeight={config.itemHeight}
              visibleItems={VISIBLE_ITEMS}
              disabled={disabled}
              className="w-32"
              ariaLabel="Sélectionner le mois"
            />
          </div>

          <div className="h-28 w-[1px] bg-[#E7E3D7]" />

          {/* Year Column */}
          <div className="flex flex-col items-center">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-[#9799AF] mb-0.5">
              Année
            </span>
            <WheelColumn
              items={years}
              value={yearIndex >= 0 ? yearIndex : 0}
              onChange={handleYearChange}
              itemHeight={config.itemHeight}
              visibleItems={VISIBLE_ITEMS}
              disabled={disabled}
              className="w-20"
              ariaLabel="Sélectionner l'année"
            />
          </div>
        </div>
      </div>
    );
  }
);

DateWheelPicker.displayName = "DateWheelPicker";
