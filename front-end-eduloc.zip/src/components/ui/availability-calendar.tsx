import { useMemo, useState } from "react";
import { Text, TextInput, View } from "react-native";

import {
  ChevronLeftIcon,
  ChevronRightIcon,
  PencilIcon,
  PlusIcon,
  SettingsIcon,
} from "@/components/icons";
import { PressableScale } from "@/components/motion/pressable-scale";
import {
  addMonths,
  buildCalendarMonth,
  formatDayLabel,
  formatMonthLabel,
  yearMonthFromIsoDate,
} from "@/utils/calendar";

export type AvailabilityCalendarProps = {
  selectedDate: string; // ISO format "2026-09-19"
  onSelectDate: (isoDate: string, label: string) => void;
  availableDates?: Set<string>;
  minDate?: string;
  onNewEventPress?: () => void;
};

const WEEKDAY_INITIALS = ["L", "M", "M", "J", "V", "S", "D"]; // Lun, Mar, Mer, Jeu, Ven, Sam, Dim

function getStartOfWeek(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  // Monday is 1, Sunday is 0
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

function formatDateIso(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function AvailabilityCalendar({
  selectedDate,
  onSelectDate,
  availableDates = new Set(),
  minDate,
  onNewEventPress,
}: AvailabilityCalendarProps) {
  // Toggle between "weekly" and "monthly" views (defaults to "weekly" matching the image)
  const [viewMode, setViewMode] = useState<"weekly" | "monthly">("weekly");

  // Determine current viewed month/year from selectedDate or today
  const initialYM = selectedDate
    ? yearMonthFromIsoDate(selectedDate)
    : { year: new Date().getFullYear(), month: new Date().getMonth() };

  const [viewedYM, setViewedYM] = useState(initialYM);

  // Current week start state
  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(() => {
    const baseDate = selectedDate ? new Date(selectedDate) : new Date();
    return getStartOfWeek(isNaN(baseDate.getTime()) ? new Date() : baseDate);
  });

  // Note feature: inline note editing toggle
  const [isEditingNote, setIsEditingNote] = useState<boolean>(false);
  const [noteText, setNoteText] = useState<string>("");

  // Build the 7 days of the current week (for Weekly view)
  const weekDays = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(currentWeekStart);
      d.setDate(d.getDate() + i);
      const iso = formatDateIso(d);
      return {
        date: d,
        iso,
        dayNumber: d.getDate(),
        dayInitial: WEEKDAY_INITIALS[i],
      };
    });
  }, [currentWeekStart]);

  // Full Month data (for Monthly view)
  const monthData = useMemo(() => {
    return buildCalendarMonth(viewedYM.year, viewedYM.month, availableDates);
  }, [viewedYM.year, viewedYM.month, availableDates]);

  // Dynamic month title:
  // In weekly mode, based on middle day of the week; in monthly mode, based on viewedYM
  const middleWeekDay = weekDays[3]?.date ?? new Date();
  const monthTitle =
    viewMode === "weekly"
      ? formatMonthLabel(middleWeekDay.getFullYear(), middleWeekDay.getMonth()).split(" ")[0]
      : formatMonthLabel(viewedYM.year, viewedYM.month).split(" ")[0];

  // Navigation handlers
  const handlePrev = () => {
    if (viewMode === "weekly") {
      const prev = new Date(currentWeekStart);
      prev.setDate(prev.getDate() - 7);
      setCurrentWeekStart(prev);
    } else {
      setViewedYM((prev) => addMonths(prev.year, prev.month, -1));
    }
  };

  const handleNext = () => {
    if (viewMode === "weekly") {
      const next = new Date(currentWeekStart);
      next.setDate(next.getDate() + 7);
      setCurrentWeekStart(next);
    } else {
      setViewedYM((prev) => addMonths(prev.year, prev.month, 1));
    }
  };

  const todayIso = new Date().toISOString().split("T")[0];

  return (
    <View
      className="overflow-hidden rounded-[32px] p-6 shadow-2xl"
      style={{
        backgroundColor: "#636E7B",
        backgroundImage: "linear-gradient(135deg, #5B6676 0%, #687182 50%, #7A677B 100%)",
        borderWidth: 1,
        borderColor: "rgba(255, 255, 255, 0.18)",
        boxShadow: "0 18px 40px -10px rgba(25, 28, 48, 0.45)",
      }}
    >
      {/* Top Row: Segmented Switcher (Weekly / Monthly) + Settings Gear */}
      <View className="flex-row items-center justify-between mb-4">
        {/* Weekly / Monthly Pill */}
        <View
          className="flex-row items-center p-1 rounded-full"
          style={{ backgroundColor: "rgba(0, 0, 0, 0.22)" }}
        >
          <PressableScale
            onPress={() => setViewMode("weekly")}
            accessibilityLabel="Vue par semaine"
            className={[
              "px-4 py-1.5 rounded-full transition-all",
              viewMode === "weekly" ? "bg-white shadow-xs" : "",
            ].join(" ")}
          >
            <Text
              className={[
                "text-[13px] font-bold tracking-tight",
                viewMode === "weekly" ? "text-slate-900" : "text-white/70 hover:text-white",
              ].join(" ")}
            >
              Weekly
            </Text>
          </PressableScale>

          <PressableScale
            onPress={() => setViewMode("monthly")}
            accessibilityLabel="Vue par mois"
            className={[
              "px-4 py-1.5 rounded-full transition-all",
              viewMode === "monthly" ? "bg-white shadow-xs" : "",
            ].join(" ")}
          >
            <Text
              className={[
                "text-[13px] font-bold tracking-tight",
                viewMode === "monthly" ? "text-slate-900" : "text-white/70 hover:text-white",
              ].join(" ")}
            >
              Monthly
            </Text>
          </PressableScale>
        </View>

        {/* Settings Gear Icon */}
        <PressableScale
          onPress={() => {}}
          accessibilityLabel="Paramètres du calendrier"
          className="h-8 w-8 items-center justify-center rounded-full hover:bg-white/10 active:scale-95"
        >
          <SettingsIcon size={19} color="rgba(255, 255, 255, 0.75)" />
        </PressableScale>
      </View>

      {/* Month Header Row: Month Name + Chevrons Row */}
      <View className="flex-row items-center justify-between mb-5 px-1">
        <Text className="text-[32px] font-bold text-white tracking-tight capitalize">
          {monthTitle}
        </Text>

        <View className="flex-row items-center gap-1.5">
          <PressableScale
            onPress={handlePrev}
            accessibilityLabel={viewMode === "weekly" ? "Semaine précédente" : "Mois précédent"}
            className="h-8 w-8 items-center justify-center rounded-full hover:bg-white/10 active:scale-95"
          >
            <ChevronLeftIcon size={18} color="rgba(255, 255, 255, 0.85)" />
          </PressableScale>

          <PressableScale
            onPress={handleNext}
            accessibilityLabel={viewMode === "weekly" ? "Semaine suivante" : "Mois suivant"}
            className="h-8 w-8 items-center justify-center rounded-full hover:bg-white/10 active:scale-95"
          >
            <ChevronRightIcon size={18} color="rgba(255, 255, 255, 0.85)" />
          </PressableScale>
        </View>
      </View>

      {/* Days View: Weekly or Monthly */}
      {viewMode === "weekly" ? (
        /* WEEKLY VIEW (Matching the design image) */
        <View className="flex-row items-center justify-between px-1 mb-3">
          {weekDays.map((item) => {
            const isSelected = item.iso === selectedDate;
            const hasEvent = availableDates.has(item.iso);
            const isToday = item.iso === todayIso;
            const isPast = minDate ? item.iso < minDate : false;

            return (
              <PressableScale
                key={item.iso}
                onPress={() => {
                  if (!isPast) {
                    onSelectDate(item.iso, formatDayLabel(item.iso));
                  }
                }}
                disabled={isPast}
                accessibilityLabel={`Sélectionner le ${item.dayNumber}`}
                className="items-center flex-1 py-1"
              >
                {/* Day Initial (e.g. T, W, T, F, S, S, M) */}
                <Text className="text-[13px] font-bold text-white/55 mb-2.5 uppercase">
                  {item.dayInitial}
                </Text>

                {/* Day Number */}
                <View
                  className={[
                    "h-9 w-9 items-center justify-center rounded-full transition-all",
                    isSelected
                      ? "bg-white shadow-md"
                      : isToday
                      ? "border border-white/50 bg-white/15"
                      : isPast
                      ? "opacity-35"
                      : "hover:bg-white/10",
                  ].join(" ")}
                >
                  <Text
                    className={[
                      "text-[16px] font-bold tabular-nums",
                      isSelected ? "text-slate-900" : "text-white",
                    ].join(" ")}
                  >
                    {item.dayNumber}
                  </Text>

                  {/* Has event / availability dot */}
                  {hasEvent ? (
                    <View
                      className={[
                        "absolute bottom-1 h-1.5 w-1.5 rounded-full",
                        isSelected ? "bg-[#7A677B]" : "bg-emerald-300",
                      ].join(" ")}
                    />
                  ) : null}
                </View>
              </PressableScale>
            );
          })}
        </View>
      ) : (
        /* MONTHLY VIEW */
        <View className="mb-2">
          {/* Weekday headers */}
          <View className="mb-2 flex-row">
            {WEEKDAY_INITIALS.map((initial, i) => (
              <View key={`header-${i}`} className="flex-1 items-center justify-center py-1">
                <Text className="text-[12px] font-bold text-white/55 uppercase">{initial}</Text>
              </View>
            ))}
          </View>

          {/* Month grid */}
          <View className="flex-row flex-wrap">
            {monthData.cells.map((cell, index) => {
              if (!cell) {
                return <View key={`empty-${index}`} className="h-10 w-[14.28%]" />;
              }

              const isSelected = cell.date === selectedDate;
              const isToday = cell.date === todayIso;
              const isPast = minDate ? cell.date < minDate : false;

              return (
                <View key={cell.date} className="h-10 w-[14.28%] items-center justify-center p-0.5">
                  <PressableScale
                    onPress={() => {
                      if (!isPast) {
                        onSelectDate(cell.date, formatDayLabel(cell.date));
                      }
                    }}
                    disabled={isPast}
                    accessibilityLabel={`${cell.day} ${monthData.label}`}
                    accessibilityRole="button"
                    className={[
                      "h-9 w-9 items-center justify-center rounded-full transition-all",
                      isSelected
                        ? "bg-white shadow-md"
                        : isToday
                        ? "border border-white/50 bg-white/15"
                        : isPast
                        ? "opacity-35"
                        : "hover:bg-white/10",
                    ].join(" ")}
                  >
                    <Text
                      className={[
                        "text-[14px] font-bold tabular-nums",
                        isSelected
                          ? "text-slate-900"
                          : isPast
                          ? "text-white/40 line-through"
                          : "text-white",
                      ].join(" ")}
                    >
                      {cell.day}
                    </Text>

                    {/* Dot */}
                    {cell.hasAvailability ? (
                      <View
                        className={[
                          "absolute bottom-1 h-1.5 w-1.5 rounded-full",
                          isSelected ? "bg-[#7A677B]" : "bg-emerald-300",
                        ].join(" ")}
                      />
                    ) : null}
                  </PressableScale>
                </View>
              );
            })}
          </View>
        </View>
      )}

      {/* Horizontal Divider Line */}
      <View className="h-[1px] bg-white/15 my-4" />

      {/* Bottom Row: Add a note... on left + New Event button on right */}
      <View className="flex-row items-center justify-between gap-3 px-1">
        {/* Left: Add a note... */}
        <View className="flex-1">
          {isEditingNote ? (
            <View className="flex-row items-center gap-2">
              <TextInput
                value={noteText}
                onChangeText={setNoteText}
                placeholder="Votre note..."
                placeholderTextColor="rgba(255, 255, 255, 0.5)"
                autoFocus
                onBlur={() => setIsEditingNote(false)}
                className="flex-1 bg-white/10 text-white rounded-lg px-2.5 py-1 text-[13px] border border-white/20"
              />
              <PressableScale
                onPress={() => setIsEditingNote(false)}
                className="px-2 py-1 rounded bg-white/20"
              >
                <Text className="text-[11px] font-bold text-white">OK</Text>
              </PressableScale>
            </View>
          ) : (
            <PressableScale
              onPress={() => setIsEditingNote(true)}
              accessibilityLabel="Ajouter une note"
              className="flex-row items-center gap-2 py-1 hover:opacity-90"
            >
              <PencilIcon size={15} color="rgba(255, 255, 255, 0.75)" />
              <Text className="text-[13.5px] font-medium text-white/70">
                {noteText ? noteText : "Add a note..."}
              </Text>
            </PressableScale>
          )}
        </View>

        {/* Right: + New Event */}
        <PressableScale
          onPress={() => {
            if (onNewEventPress) {
              onNewEventPress();
            }
          }}
          accessibilityLabel="Ajouter un créneau"
          accessibilityRole="button"
          className="flex-row items-center gap-1.5 px-4 py-2 rounded-xl active:scale-95 transition-all shadow-sm"
          style={{
            backgroundColor: "#826e84",
            borderWidth: 1,
            borderColor: "rgba(255, 255, 255, 0.22)",
            boxShadow: "0 2px 8px rgba(0, 0, 0, 0.2)",
          }}
        >
          <PlusIcon size={14} color="#ffffff" />
          <Text className="text-[13px] font-bold text-white tracking-wide">
            + New Event
          </Text>
        </PressableScale>
      </View>
    </View>
  );
}
