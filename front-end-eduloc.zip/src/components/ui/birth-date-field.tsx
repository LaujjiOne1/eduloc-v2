import { useEffect, useMemo, useState } from "react";
import { Text, View } from "react-native";

import { CalendarIcon, CheckIcon, ChevronRightIcon } from "@/components/icons";
import { PressableScale } from "@/components/motion/pressable-scale";
import { DateWheelPicker } from "@/components/ui/date-wheel-picker";

export type BirthDateFieldProps = {
  label?: string;
  value: string;
  onChangeText: (formattedDate: string) => void;
  placeholder?: string;
  error?: string;
  disabled?: boolean;
  minYear?: number;
  maxYear?: number;
};

/** Parse DD/MM/YYYY into a real Date object. */
function parseDateStringToDate(raw: string): Date | undefined {
  if (!raw) return undefined;
  const parts = raw.replace(/[^\d]/g, " ").trim().split(/\s+/);
  if (parts.length >= 3) {
    const d = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10) - 1;
    const y = parseInt(parts[2], 10);
    if (
      !isNaN(d) &&
      !isNaN(m) &&
      !isNaN(y) &&
      y >= 1900 &&
      m >= 0 &&
      m <= 11 &&
      d >= 1 &&
      d <= 31
    ) {
      return new Date(y, m, d);
    }
  }
  return undefined;
}

/** Format Date object into DD/MM/YYYY. */
function formatDateToDDMMYYYY(date: Date): string {
  const d = String(date.getDate()).padStart(2, "0");
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const y = String(date.getFullYear());
  return `${d}/${m}/${y}`;
}

/** Calculate age given date. */
function calculateAgeFromDate(date: Date): number | null {
  const today = new Date();
  let age = today.getFullYear() - date.getFullYear();
  const m = today.getMonth() - date.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < date.getDate())) {
    age--;
  }
  return age >= 0 && age <= 120 ? age : null;
}

/** Format date in French words: e.g. "12 Mai 1997". */
function formatFrenchDisplay(date: Date): string {
  const day = date.getDate();
  const year = date.getFullYear();
  const monthName = new Intl.DateTimeFormat("fr-FR", { month: "long" }).format(date);
  const capitalizedMonth = monthName.charAt(0).toUpperCase() + monthName.slice(1);
  return `${day} ${capitalizedMonth} ${year}`;
}

/**
 * BirthDateField
 *
 * Provides a 3D cylindrical DateWheelPicker powered by framer-motion,
 * allowing users to roll through days, months, and distant birth years with
 * spring physics, 3D perspective rotation, drag controls, and mouse wheel support.
 */
export function BirthDateField({
  label = "Date de naissance",
  value,
  onChangeText,
  error,
  disabled = false,
  minYear = 1920,
  maxYear = new Date().getFullYear() - 15,
}: BirthDateFieldProps) {
  const parsedDate = useMemo(() => parseDateStringToDate(value), [value]);

  // Internal date state (defaults to ~27 years ago: 1997-05-12 if none provided)
  const [internalDate, setInternalDate] = useState<Date>(
    () => parsedDate || new Date(1997, 4, 12)
  );

  const [isOpen, setIsOpen] = useState(true);

  // Sync internalDate if external value prop updates
  useEffect(() => {
    if (parsedDate) {
      setInternalDate(parsedDate);
    }
  }, [parsedDate]);

  const age = useMemo(
    () => calculateAgeFromDate(parsedDate || internalDate),
    [parsedDate, internalDate]
  );

  const handleDateChange = (newDate: Date) => {
    setInternalDate(newDate);
    const formatted = formatDateToDDMMYYYY(newDate);
    onChangeText(formatted);
  };

  return (
    <View className="mb-[14px]">
      {/* Header Label and Age Badge */}
      <View className="mb-[6px] ml-0.5 flex-row items-center justify-between">
        <Text className="text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
          {label}
        </Text>
        {age !== null && (
          <View className="rounded-full bg-primary-soft px-2.5 py-0.5 border border-primary/20">
            <Text className="text-[11.5px] font-bold text-primary">
              {age} ans
            </Text>
          </View>
        )}
      </View>

      {/* Date Display Card / Trigger */}
      <PressableScale
        onPress={() => setIsOpen((prev) => !prev)}
        disabled={disabled}
        accessibilityLabel={`${label}: ${formatFrenchDisplay(internalDate)}`}
      >
        <View
          className={[
            "flex-row items-center justify-between rounded-lg border bg-surface px-4 py-3 shadow-xs",
            error ? "border-error" : isOpen ? "border-primary ring-1 ring-primary/20" : "border-line",
            disabled ? "opacity-50" : "",
          ].join(" ")}
        >
          <View className="flex-row items-center gap-2.5">
            <View className="h-8 w-8 items-center justify-center rounded-md bg-primary-soft">
              <CalendarIcon size={16} color="#332E86" />
            </View>
            <View>
              <Text className="text-[15px] font-bold text-ink">
                {formatFrenchDisplay(internalDate)}
              </Text>
              <Text className="text-[11.5px] font-medium text-ink-soft">
                {value ? `Format : ${value}` : "Faites défiler le rouleau pour ajuster"}
              </Text>
            </View>
          </View>

          <View
            style={{
              transform: [{ rotate: isOpen ? "90deg" : "0deg" }],
            }}
          >
            <ChevronRightIcon size={16} color="#332E86" />
          </View>
        </View>
      </PressableScale>

      {/* Collapsible 3D Date Wheel Picker Container */}
      {isOpen && (
        <View className="mt-2.5 overflow-hidden rounded-xl border border-line bg-surface p-3.5 shadow-xs">
          <DateWheelPicker
            value={internalDate}
            onChange={handleDateChange}
            minYear={minYear}
            maxYear={maxYear}
            disabled={disabled}
            locale="fr-FR"
          />

          <View className="mt-3 flex-row items-center justify-between border-t border-line-soft pt-2.5">
            <Text className="text-[11.5px] text-ink-faint">
              💡 Glissez ou utilisez la molette
            </Text>
            <PressableScale
              onPress={() => {
                const formatted = formatDateToDDMMYYYY(internalDate);
                onChangeText(formatted);
                setIsOpen(false);
              }}
              accessibilityRole="button"
              accessibilityLabel="OK, valider la date"
            >
              <View className="flex-row items-center justify-center gap-1.5 rounded-lg bg-primary px-5 py-2 shadow-xs active:opacity-90">
                <CheckIcon size={14} color="#FFFFFF" />
                <Text className="text-[13px] font-bold text-white tracking-wider">
                  OK
                </Text>
              </View>
            </PressableScale>
          </View>
        </View>
      )}

      {/* Error message */}
      {error ? (
        <Text className="mb-0 mt-[6px] ml-0.5 text-[12.5px] text-error">{error}</Text>
      ) : null}
    </View>
  );
}
