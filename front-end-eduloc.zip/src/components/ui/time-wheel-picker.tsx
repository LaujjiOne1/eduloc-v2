import * as React from "react";
import {
  animate,
  type MotionValue,
  motion,
  type PanInfo,
  useMotionValue,
  useTransform,
} from "framer-motion";

import { cn } from "@/lib/utils";

export type TimeWheelPickerProps = {
  startTime: string; // e.g. "09:00"
  endTime: string; // e.g. "10:00"
  onChangeStart: (time: string) => void;
  onChangeEnd: (time: string) => void;
  disabled?: boolean;
};

const ITEM_HEIGHT = 38;
const VISIBLE_ITEMS = 3;
const PERSPECTIVE_ORIGIN = ITEM_HEIGHT * 1.5;

const HOURS: string[] = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0"));
const MINUTES: string[] = ["00", "15", "30", "45"];

interface WheelItemProps {
  item: string;
  index: number;
  y: MotionValue<number>;
  itemHeight: number;
  visibleItems: number;
  centerOffset: number;
  isSelected: boolean;
  disabled?: boolean;
  onClick: () => void;
}

function WheelItem({
  item,
  index,
  y,
  itemHeight,
  visibleItems,
  centerOffset,
  isSelected,
  disabled,
  onClick,
}: WheelItemProps) {
  const itemY = useTransform(y, (latest) => {
    return index * itemHeight + latest + centerOffset;
  });

  const rotateX = useTransform(
    itemY,
    [0, centerOffset, itemHeight * visibleItems],
    [35, 0, -35]
  );

  const scale = useTransform(
    itemY,
    [0, centerOffset, itemHeight * visibleItems],
    [0.85, 1.08, 0.85]
  );

  const opacity = useTransform(
    itemY,
    [0, centerOffset * 0.5, centerOffset, centerOffset * 1.5, itemHeight * visibleItems],
    [0.3, 0.6, 1, 0.6, 0.3]
  );

  return (
    <motion.div
      className="flex select-none items-center justify-center cursor-pointer"
      style={{
        height: itemHeight,
        rotateX,
        scale,
        opacity,
        transformStyle: "preserve-3d",
        transformOrigin: `center center -${PERSPECTIVE_ORIGIN}px`,
      }}
      onClick={() => !disabled && onClick()}
    >
      <span
        className={cn(
          "transition-colors text-center font-bold px-1 tabular-nums",
          isSelected
            ? "text-[21px] text-primary"
            : "text-[16px] text-ink-soft hover:text-ink"
        )}
      >
        {item}
      </span>
    </motion.div>
  );
}

interface SingleWheelProps {
  items: string[];
  value: number;
  onChange: (index: number) => void;
  disabled?: boolean;
  ariaLabel: string;
  width?: string;
}

function SingleWheel({
  items,
  value,
  onChange,
  disabled,
  ariaLabel,
  width = "w-14",
}: SingleWheelProps) {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const y = useMotionValue(-value * ITEM_HEIGHT);
  const centerOffset = Math.floor(VISIBLE_ITEMS / 2) * ITEM_HEIGHT;

  const valueRef = React.useRef(value);
  const onChangeRef = React.useRef(onChange);
  const itemsLengthRef = React.useRef(items.length);

  React.useEffect(() => {
    valueRef.current = value;
    onChangeRef.current = onChange;
    itemsLengthRef.current = items.length;
  });

  React.useEffect(() => {
    animate(y, -value * ITEM_HEIGHT, {
      type: "spring",
      stiffness: 350,
      damping: 30,
    });
  }, [value, y]);

  const handleDragEnd = (_: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (disabled) return;
    const currentY = y.get();
    const velocity = info.velocity.y;
    const projectedY = currentY + velocity * 0.15;
    let newIndex = Math.round(-projectedY / ITEM_HEIGHT);
    newIndex = Math.max(0, Math.min(items.length - 1, newIndex));
    onChange(newIndex);
  };

  React.useEffect(() => {
    const container = containerRef.current;
    if (!container || disabled) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const direction = e.deltaY > 0 ? 1 : -1;
      const currentValue = valueRef.current;
      const maxIndex = itemsLengthRef.current - 1;
      const newIndex = Math.max(0, Math.min(maxIndex, currentValue + direction));
      if (newIndex !== currentValue) {
        onChangeRef.current(newIndex);
      }
    };

    container.addEventListener("wheel", handleWheel, { passive: false });
    return () => {
      container.removeEventListener("wheel", handleWheel);
    };
  }, [disabled]);

  const dragConstraints = React.useMemo(
    () => ({
      top: -(items.length - 1) * ITEM_HEIGHT,
      bottom: 0,
    }),
    [items.length]
  );

  return (
    <div
      ref={containerRef}
      className={cn(
        "relative overflow-hidden outline-none select-none bg-surface/50 rounded-lg",
        width,
        disabled && "opacity-50 pointer-events-none"
      )}
      style={{ height: ITEM_HEIGHT * VISIBLE_ITEMS }}
      tabIndex={disabled ? -1 : 0}
      role="spinbutton"
      aria-label={ariaLabel}
      aria-valuenow={value}
      aria-valuetext={items[value]}
    >
      {/* Center highlight band */}
      <div
        className="pointer-events-none absolute left-0 right-0 rounded-md border-y border-primary/20 bg-primary/8 shadow-2xs"
        style={{
          top: centerOffset,
          height: ITEM_HEIGHT,
        }}
      />

      {/* Top Gradient Fade */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-6 bg-gradient-to-b from-surface via-surface/80 to-transparent z-10" />

      {/* Draggable items stack */}
      <motion.div
        drag="y"
        dragConstraints={dragConstraints}
        dragElastic={0.15}
        onDragEnd={handleDragEnd}
        style={{ y }}
        className="cursor-grab active:cursor-grabbing"
      >
        {items.map((item, index) => (
          <WheelItem
            key={`${item}-${index}`}
            item={item}
            index={index}
            y={y}
            itemHeight={ITEM_HEIGHT}
            visibleItems={VISIBLE_ITEMS}
            centerOffset={centerOffset}
            isSelected={index === value}
            disabled={disabled}
            onClick={() => onChange(index)}
          />
        ))}
      </motion.div>

      {/* Bottom Gradient Fade */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-6 bg-gradient-to-t from-surface via-surface/80 to-transparent z-10" />
    </div>
  );
}

export function TimeWheelPicker({
  startTime,
  endTime,
  onChangeStart,
  onChangeEnd,
  disabled = false,
}: TimeWheelPickerProps) {
  // Parse start hours and minutes
  const [startH, startM] = (startTime || "09:00").split(":");
  const startHourIndex = Math.max(0, HOURS.indexOf(startH));
  const startMinIndex = Math.max(
    0,
    MINUTES.findIndex((m) => Number(m) >= Number(startM))
  );

  // Parse end hours and minutes
  const [endH, endM] = (endTime || "10:00").split(":");
  const endHourIndex = Math.max(0, HOURS.indexOf(endH));
  const endMinIndex = Math.max(
    0,
    MINUTES.findIndex((m) => Number(m) >= Number(endM))
  );

  const handleStartHourChange = (idx: number) => {
    const newH = HOURS[idx];
    const currM = MINUTES[startMinIndex >= 0 ? startMinIndex : 0];
    onChangeStart(`${newH}:${currM}`);
  };

  const handleStartMinChange = (idx: number) => {
    const currH = HOURS[startHourIndex >= 0 ? startHourIndex : 9];
    const newM = MINUTES[idx];
    onChangeStart(`${currH}:${newM}`);
  };

  const handleEndHourChange = (idx: number) => {
    const newH = HOURS[idx];
    const currM = MINUTES[endMinIndex >= 0 ? endMinIndex : 0];
    onChangeEnd(`${newH}:${currM}`);
  };

  const handleEndMinChange = (idx: number) => {
    const currH = HOURS[endHourIndex >= 0 ? endHourIndex : 10];
    const newM = MINUTES[idx];
    onChangeEnd(`${currH}:${newM}`);
  };

  return (
    <div className="flex flex-row items-center justify-between gap-3 sm:gap-6 rounded-2xl border border-line bg-surface/70 p-4 shadow-2xs">
      {/* Start Time Section */}
      <div className="flex-1 flex flex-col items-center">
        <span className="text-[12px] font-bold text-ink-soft uppercase tracking-wider mb-2">
          Début
        </span>
        <div className="flex flex-row items-center gap-1.5 bg-paper rounded-xl p-1.5 border border-line">
          <SingleWheel
            items={HOURS}
            value={startHourIndex >= 0 ? startHourIndex : 9}
            onChange={handleStartHourChange}
            disabled={disabled}
            ariaLabel="Heure de début"
          />
          <span className="text-[18px] font-bold text-primary">:</span>
          <SingleWheel
            items={MINUTES}
            value={startMinIndex >= 0 ? startMinIndex : 0}
            onChange={handleStartMinChange}
            disabled={disabled}
            ariaLabel="Minute de début"
          />
        </div>
      </div>

      {/* Middle Arrow Divider */}
      <div className="flex flex-col items-center justify-center pt-5">
        <div className="h-7 w-7 rounded-full bg-primary-tint items-center justify-center flex">
          <span className="text-[14px] font-bold text-primary leading-none">→</span>
        </div>
      </div>

      {/* End Time Section */}
      <div className="flex-1 flex flex-col items-center">
        <span className="text-[12px] font-bold text-ink-soft uppercase tracking-wider mb-2">
          Fin
        </span>
        <div className="flex flex-row items-center gap-1.5 bg-paper rounded-xl p-1.5 border border-line">
          <SingleWheel
            items={HOURS}
            value={endHourIndex >= 0 ? endHourIndex : 10}
            onChange={handleEndHourChange}
            disabled={disabled}
            ariaLabel="Heure de fin"
          />
          <span className="text-[18px] font-bold text-primary">:</span>
          <SingleWheel
            items={MINUTES}
            value={endMinIndex >= 0 ? endMinIndex : 0}
            onChange={handleEndMinChange}
            disabled={disabled}
            ariaLabel="Minute de fin"
          />
        </div>
      </div>
    </div>
  );
}
