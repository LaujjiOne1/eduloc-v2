import { type Href, useRouter } from "expo-router";
import { useMemo, useRef, useState } from "react";
import { Modal, Text, TextInput, View } from "react-native";

import {
  ChevronLeftIcon,
  ChevronRightIcon,
  PencilIcon,
  PlusIcon,
  SettingsIcon,
  XIcon,
} from "@/components/icons";
import { PressableScale } from "@/components/motion/pressable-scale";
import type { Booking } from "@/types/booking";
import type { TutorAvailabilitySlot } from "@/types/availability";
import { formatMonthLabel } from "@/utils/calendar";

export type TutorScheduleStripProps = {
  availability?: TutorAvailabilitySlot[];
  bookings?: Booking[];
  onNewEventPress?: () => void;
  onCalendarPress?: () => void;
  selectedDate?: string;
  onSelectDate?: (dateIso: string) => void;
  showOpenBadge?: boolean;
};

const DAY_INITIALS = ["T", "W", "T", "F", "S", "S", "M"]; // Matches image layout (or Lun-Dim)

function getStartOfWeek(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  // Monday is 1, Sunday is 0
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

function formatDateIso(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function TutorScheduleStrip({
  availability = [],
  bookings = [],
  onNewEventPress,
  onCalendarPress,
  selectedDate,
  onSelectDate,
}: TutorScheduleStripProps) {
  const router = useRouter();

  const [viewMode, setViewMode] = useState<"weekly" | "monthly">("weekly");
  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(() => getStartOfWeek(new Date()));
  const [internalSelectedDate, setInternalSelectedDate] = useState<string>(() => formatDateIso(new Date()));

  // Inline Note Modal / State
  const [isNoteModalVisible, setIsNoteModalVisible] = useState(false);
  const [notesByDate, setNotesByDate] = useState<Record<string, string>>({});
  const [noteText, setNoteText] = useState("");

  const selectedDateIso = selectedDate ?? internalSelectedDate;

  const handleDayPress = (iso: string) => {
    setInternalSelectedDate(iso);
    onSelectDate?.(iso);
  };

  // Navigation refs for horizontal wheel & drag
  const lastWheelTimeRef = useRef<number>(0);
  const dragStartXRef = useRef<number | null>(null);

  // Build the 7 days of the current week
  const weekDays = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(currentWeekStart);
      d.setDate(d.getDate() + i);
      const iso = formatDateIso(d);
      return {
        date: d,
        iso,
        dayNumber: d.getDate(),
        dayInitial: DAY_INITIALS[i],
      };
    });
  }, [currentWeekStart]);

  // Set of dates that have availability or bookings
  const activeDates = useMemo(() => {
    const dates = new Set<string>();
    for (const a of availability) {
      if (a.date) dates.add(a.date);
    }
    for (const b of bookings) {
      if (b.slot?.date) dates.add(b.slot.date);
    }
    return dates;
  }, [availability, bookings]);

  // Navigate previous/next
  const handlePrev = (e?: { stopPropagation?: () => void }) => {
    e?.stopPropagation?.();
    if (viewMode === "weekly") {
      const prev = new Date(currentWeekStart);
      prev.setDate(prev.getDate() - 7);
      setCurrentWeekStart(prev);
    } else {
      const prev = new Date(currentWeekStart);
      prev.setMonth(prev.getMonth() - 1);
      setCurrentWeekStart(getStartOfWeek(prev));
    }
  };

  const handleNext = (e?: { stopPropagation?: () => void }) => {
    e?.stopPropagation?.();
    if (viewMode === "weekly") {
      const next = new Date(currentWeekStart);
      next.setDate(next.getDate() + 7);
      setCurrentWeekStart(next);
    } else {
      const next = new Date(currentWeekStart);
      next.setMonth(next.getMonth() + 1);
      setCurrentWeekStart(getStartOfWeek(next));
    }
  };

  // Horizontal mouse wheel handler for navigating weeks
  const handleWheel = (e: any) => {
    const dx = e.deltaX ?? 0;
    const dy = e.deltaY ?? 0;
    const absX = Math.abs(dx);
    const absY = Math.abs(dy);
    const dominantDelta = absX >= absY ? dx : dy;
    if (Math.abs(dominantDelta) < 16) return;

    const now = Date.now();
    if (now - lastWheelTimeRef.current < 240) return;
    lastWheelTimeRef.current = now;

    if (dominantDelta > 0) {
      handleNext();
    } else {
      handlePrev();
    }
  };

  // Touch and pointer swipe handlers
  const handlePointerDown = (e: any) => {
    dragStartXRef.current = e.nativeEvent?.clientX ?? e.clientX ?? e.nativeEvent?.touches?.[0]?.clientX ?? 0;
  };

  const handlePointerUp = (e: any) => {
    if (dragStartXRef.current === null) return;
    const currentX = e.nativeEvent?.clientX ?? e.clientX ?? e.nativeEvent?.changedTouches?.[0]?.clientX ?? 0;
    const diff = dragStartXRef.current - currentX;
    if (diff > 35) {
      handleNext();
    } else if (diff < -35) {
      handlePrev();
    }
    dragStartXRef.current = null;
  };

  // Month label to display: e.g. "September" / "Septembre"
  const middleDay = weekDays[3]?.date ?? new Date();
  const monthName = formatMonthLabel(middleDay.getFullYear(), middleDay.getMonth()).split(" ")[0];

  const handleCreateAvailability = () => {
    if (onNewEventPress) {
      onNewEventPress();
    } else {
      router.push("/tutor-dashboard/calendar/availability/new" as Href);
    }
  };

  const handleOpenNoteModal = () => {
    setNoteText(notesByDate[selectedDateIso] ?? "");
    setIsNoteModalVisible(true);
  };

  const handleSaveNote = () => {
    setNotesByDate((prev) => ({
      ...prev,
      [selectedDateIso]: noteText.trim(),
    }));
    setIsNoteModalVisible(false);
  };

  // Days for monthly view
  const monthGridDays = useMemo(() => {
    if (viewMode !== "monthly") return [];
    const year = middleDay.getFullYear();
    const month = middleDay.getMonth();
    const firstDayOfMonth = new Date(year, month, 1);
    const startOfFirstWeek = getStartOfWeek(firstDayOfMonth);
    const days: { date: Date; iso: string; dayNumber: number; isCurrentMonth: boolean }[] = [];

    for (let i = 0; i < 35; i++) {
      const d = new Date(startOfFirstWeek);
      d.setDate(d.getDate() + i);
      days.push({
        date: d,
        iso: formatDateIso(d),
        dayNumber: d.getDate(),
        isCurrentMonth: d.getMonth() === month,
      });
    }
    return days;
  }, [viewMode, middleDay]);

  const currentNote = notesByDate[selectedDateIso];

  return (
    <View
      className="mb-6 overflow-hidden rounded-[32px] p-6 shadow-xl"
      style={{
        backgroundColor: "#637283",
        backgroundImage: "linear-gradient(135deg, #647486 0%, #6E7487 40%, #856E86 80%, #92758E 100%)",
        borderWidth: 1,
        borderColor: "rgba(255, 255, 255, 0.18)",
      }}
    >
      {/* Top Row: Weekly / Monthly Pill Segmented Switch + Settings Cog */}
      <View className="flex-row items-center justify-between mb-5">
        {/* Weekly / Monthly toggle */}
        <View
          style={{
            backgroundColor: "rgba(0, 0, 0, 0.22)",
            borderRadius: 16,
            padding: 4,
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <PressableScale
            onPress={() => setViewMode("weekly")}
            accessibilityLabel="Vue hebdomadaire"
            style={{
              backgroundColor: viewMode === "weekly" ? "#ffffff" : "transparent",
              borderRadius: 12,
              paddingVertical: 6,
              paddingHorizontal: 16,
              shadowColor: "#000",
              shadowOpacity: viewMode === "weekly" ? 0.15 : 0,
              shadowRadius: 3,
            }}
          >
            <Text
              style={{
                fontSize: 13,
                fontWeight: "700",
                color: viewMode === "weekly" ? "#1e293b" : "rgba(255, 255, 255, 0.65)",
              }}
            >
              Weekly
            </Text>
          </PressableScale>

          <PressableScale
            onPress={() => setViewMode("monthly")}
            accessibilityLabel="Vue mensuelle"
            style={{
              backgroundColor: viewMode === "monthly" ? "#ffffff" : "transparent",
              borderRadius: 12,
              paddingVertical: 6,
              paddingHorizontal: 16,
              shadowColor: "#000",
              shadowOpacity: viewMode === "monthly" ? 0.15 : 0,
              shadowRadius: 3,
            }}
          >
            <Text
              style={{
                fontSize: 13,
                fontWeight: "700",
                color: viewMode === "monthly" ? "#1e293b" : "rgba(255, 255, 255, 0.65)",
              }}
            >
              Monthly
            </Text>
          </PressableScale>
        </View>

        {/* Settings gear icon */}
        <PressableScale
          onPress={() => onCalendarPress?.()}
          accessibilityLabel="Paramètres du calendrier"
          className="h-9 w-9 items-center justify-center rounded-full hover:bg-white/10 active:scale-95"
        >
          <SettingsIcon size={20} color="rgba(255, 255, 255, 0.7)" />
        </PressableScale>
      </View>

      {/* Month Title + Pagination Chevrons */}
      <View className="flex-row items-center justify-between mb-5 px-1">
        <Text
          style={{
            fontSize: 34,
            fontWeight: "800",
            color: "#ffffff",
            letterSpacing: -0.8,
            textTransform: "capitalize",
          }}
        >
          {monthName}
        </Text>

        <View className="flex-row items-center gap-3">
          <PressableScale
            onPress={handlePrev}
            accessibilityLabel="Précédent"
            className="h-8 w-8 items-center justify-center rounded-full hover:bg-white/10 active:scale-95"
          >
            <ChevronLeftIcon size={20} color="rgba(255, 255, 255, 0.75)" />
          </PressableScale>

          <PressableScale
            onPress={handleNext}
            accessibilityLabel="Suivant"
            className="h-8 w-8 items-center justify-center rounded-full hover:bg-white/10 active:scale-95"
          >
            <ChevronRightIcon size={20} color="rgba(255, 255, 255, 0.75)" />
          </PressableScale>
        </View>
      </View>

      {/* Main Days Area: Weekly or Monthly */}
      {viewMode === "weekly" ? (
        <View
          // @ts-expect-error Web onWheel support
          onWheel={handleWheel}
          onTouchStart={handlePointerDown}
          onTouchEnd={handlePointerUp}
          onMouseDown={handlePointerDown}
          onMouseUp={handlePointerUp}
          style={{ userSelect: "none" }}
          className="px-1 mb-2"
        >
          {/* Day initials & numbers columns */}
          <View className="flex-row items-center justify-between">
            {weekDays.map((item) => {
              const isSelected = item.iso === selectedDateIso;
              const hasEvent = activeDates.has(item.iso);

              return (
                <PressableScale
                  key={item.iso}
                  onPress={() => handleDayPress(item.iso)}
                  accessibilityLabel={`Jour ${item.dayNumber}`}
                  className="items-center flex-1 py-1"
                >
                  {/* Day Initial */}
                  <Text
                    style={{
                      fontSize: 13,
                      fontWeight: "700",
                      color: isSelected ? "#ffffff" : "rgba(255, 255, 255, 0.55)",
                      marginBottom: 10,
                      textTransform: "uppercase",
                    }}
                  >
                    {item.dayInitial}
                  </Text>

                  {/* Day Number */}
                  <View
                    style={{
                      height: 36,
                      width: 36,
                      borderRadius: 18,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: isSelected ? "rgba(255, 255, 255, 0.22)" : "transparent",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 17,
                        fontWeight: "700",
                        color: "#ffffff",
                        fontVariant: ["tabular-nums"],
                      }}
                    >
                      {item.dayNumber}
                    </Text>

                    {/* Has event dot */}
                    {hasEvent ? (
                      <View
                        style={{
                          position: "absolute",
                          bottom: 2,
                          width: 4,
                          height: 4,
                          borderRadius: 2,
                          backgroundColor: "#34D399",
                        }}
                      />
                    ) : null}
                  </View>
                </PressableScale>
              );
            })}
          </View>
        </View>
      ) : (
        /* Monthly Grid View */
        <View className="px-1 mb-2">
          {/* Weekday headers */}
          <View className="flex-row items-center justify-between mb-2">
            {DAY_INITIALS.map((init, idx) => (
              <View key={idx} className="items-center flex-1">
                <Text style={{ fontSize: 12, fontWeight: "700", color: "rgba(255, 255, 255, 0.5)" }}>
                  {init}
                </Text>
              </View>
            ))}
          </View>

          {/* Month grid */}
          <View className="flex-row flex-wrap">
            {monthGridDays.map((item) => {
              const isSelected = item.iso === selectedDateIso;
              const hasEvent = activeDates.has(item.iso);

              return (
                <PressableScale
                  key={item.iso}
                  onPress={() => handleDayPress(item.iso)}
                  style={{
                    width: "14.28%",
                    alignItems: "center",
                    paddingVertical: 5,
                  }}
                >
                  <View
                    style={{
                      height: 30,
                      width: 30,
                      borderRadius: 15,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: isSelected ? "rgba(255, 255, 255, 0.25)" : "transparent",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: isSelected ? "700" : "500",
                        color: item.isCurrentMonth
                          ? "#ffffff"
                          : "rgba(255, 255, 255, 0.3)",
                      }}
                    >
                      {item.dayNumber}
                    </Text>
                    {hasEvent ? (
                      <View
                        style={{
                          position: "absolute",
                          bottom: 2,
                          width: 3,
                          height: 3,
                          borderRadius: 1.5,
                          backgroundColor: "#34D399",
                        }}
                      />
                    ) : null}
                  </View>
                </PressableScale>
              );
            })}
          </View>
        </View>
      )}

      {/* Horizontal Divider Line */}
      <View
        style={{
          height: 1,
          backgroundColor: "rgba(255, 255, 255, 0.15)",
          marginVertical: 18,
          width: "100%",
        }}
      />

      {/* Bottom Row: Add a note... on left, + New Event button on right */}
      <View className="flex-row items-center justify-between gap-3 px-1">
        {/* Left: Add a note... */}
        <PressableScale
          onPress={handleOpenNoteModal}
          accessibilityLabel="Ajouter une note"
          className="flex-row items-center gap-2 py-1.5 flex-1"
        >
          <PencilIcon size={16} color="rgba(255, 255, 255, 0.65)" />
          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              color: currentNote ? "#ffffff" : "rgba(255, 255, 255, 0.65)",
            }}
            numberOfLines={1}
          >
            {currentNote ? currentNote : "Add a note..."}
          </Text>
        </PressableScale>

        {/* Right: + New Event button */}
        <PressableScale
          onPress={handleCreateAvailability}
          accessibilityLabel="Créer un nouvel événement"
          accessibilityRole="button"
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 7,
            backgroundColor: "rgba(142, 116, 140, 0.8)",
            borderWidth: 1,
            borderColor: "rgba(255, 255, 255, 0.2)",
            borderRadius: 14,
            paddingVertical: 9,
            paddingHorizontal: 16,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.15,
            shadowRadius: 4,
          }}
        >
          <PlusIcon size={14} color="#ffffff" />
          <Text
            style={{
              fontSize: 13,
              fontWeight: "700",
              color: "#ffffff",
              letterSpacing: 0.2,
            }}
          >
            New Event
          </Text>
        </PressableScale>
      </View>

      {/* Note Modal */}
      <Modal
        visible={isNoteModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setIsNoteModalVisible(false)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            alignItems: "center",
            justifyContent: "center",
            padding: 20,
          }}
        >
          <View
            style={{
              width: "100%",
              maxWidth: 380,
              backgroundColor: "#2B3240",
              borderRadius: 24,
              padding: 20,
              borderWidth: 1,
              borderColor: "rgba(255, 255, 255, 0.15)",
              shadowColor: "#000",
              shadowOpacity: 0.35,
              shadowRadius: 10,
            }}
          >
            <View className="flex-row items-center justify-between mb-3">
              <Text className="text-[17px] font-bold text-white">Note pour le {selectedDateIso}</Text>
              <PressableScale onPress={() => setIsNoteModalVisible(false)}>
                <XIcon size={18} color="rgba(255, 255, 255, 0.7)" />
              </PressableScale>
            </View>

            <TextInput
              value={noteText}
              onChangeText={setNoteText}
              placeholder="Ex : Réviser le chapitre de trigonométrie..."
              placeholderTextColor="rgba(255, 255, 255, 0.4)"
              multiline
              numberOfLines={4}
              style={{
                backgroundColor: "rgba(255, 255, 255, 0.08)",
                borderRadius: 14,
                padding: 12,
                color: "#ffffff",
                fontSize: 14,
                textAlignVertical: "top",
                minHeight: 100,
                marginBottom: 16,
              }}
            />

            <View className="flex-row items-center justify-end gap-2">
              <PressableScale
                onPress={() => setIsNoteModalVisible(false)}
                className="px-4 py-2 rounded-xl bg-white/10"
              >
                <Text className="text-[13px] font-semibold text-white/80">Annuler</Text>
              </PressableScale>
              <PressableScale
                onPress={handleSaveNote}
                className="px-4 py-2 rounded-xl"
                style={{ backgroundColor: "#8E758D" }}
              >
                <Text className="text-[13px] font-bold text-white">Enregistrer</Text>
              </PressableScale>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}
