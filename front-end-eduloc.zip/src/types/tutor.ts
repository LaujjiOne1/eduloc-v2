import type { LocationFormatId } from "@/types/search";

export type TutorAvatarTone = "primary" | "violet" | "accent";

export interface TutorLocation {
  label: string;
  /** null when the tutor only teaches online (no physical distance to show). */
  distanceKm: number | null;
  /** Geographic coordinates for map display */
  latitude?: number;
  longitude?: number;
}

/** Lightweight offer reference shown on the tutor's profile — full detail lives in Offer. */
export interface TutorOfferSummary {
  id: string;
  title: string;
  durationLabel: string;
  formats: LocationFormatId[];
}

export interface Tutor {
  id: string;
  firstName: string;
  lastName: string;
  avatarTone: TutorAvatarTone;
  rating: number;
  reviewCount: number;
  isVerified: boolean;
  subjects: string[];
  levels: string[];
  formats: LocationFormatId[];
  location: TutorLocation;
  nextSlotLabel: string;
  bio: string;
  offers: TutorOfferSummary[];
}
