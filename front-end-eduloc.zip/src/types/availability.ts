import type { LocationFormatId } from "@/types/search";

/**
 * A tutor-declared open time window (56_TutorCalendar / 57_TutorAvailabilityEdit).
 * Distinct from `OfferSlot`: this is the tutor's general availability, not tied
 * to a specific offer — an offer's bookable slots are derived from it server-side.
 */
export interface TutorAvailabilitySlot {
  id: string;
  /** ISO date ("2026-09-19"), used to group entries by day on the calendar. */
  date: string;
  /** Display label matching the ISO date, e.g. "Samedi 19 septembre". */
  dateLabel: string;
  startTime: string;
  endTime: string;
  timeRangeLabel: string;
  format: LocationFormatId;
  /** Location label for in-person/both availability; null for online-only. */
  locationLabel: string | null;
}

export interface TutorAvailabilityDraft {
  date: string;
  dateLabel: string;
  startTime: string;
  endTime: string;
  format: LocationFormatId;
  locationLabel: string | null;
}
