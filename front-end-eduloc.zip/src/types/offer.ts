import type { LocationFormatId } from "@/types/search";

export interface OfferSlot {
  id: string;
  /** ISO date ("2026-09-19") — powers the BookDate calendar grid. */
  date: string;
  /** Display label matching the ISO date, e.g. "Samedi 19 septembre". */
  dateLabel: string;
  startTime: string;
  endTime: string;
  timeRangeLabel: string;
  /** "booked" slots render disabled ("Pris") in the BookDate time list. */
  status: "available" | "booked";
}

export interface Offer {
  id: string;
  tutorId: string;
  tutorName: string;
  tutorInitial: string;
  title: string;
  description: string;
  /** Subject/level this offer was created for — fixed at creation, shown read-only on ManageOffer (59). */
  subjectLabel: string;
  levelLabel: string;
  durationLabel: string;
  formats: LocationFormatId[];
  location: string;
  slots: OfferSlot[];
  /** Whether the offer is currently bookable/visible to beneficiaries (58_TutorOffers Active/Désactivée). */
  isActive: boolean;
}

/**
 * Payload for 59_TutorOfferDetail in "create" mode — a brand new offer needs
 * its subject/level. `formats`/`location` aren't collected by this form (no
 * such fields in the mock); the screen defaults them from the tutor's own
 * profile locations, matching where the tutor already teaches.
 */
export interface CreateOfferInput {
  subjectLabel: string;
  levelLabel: string;
  title: string;
  description: string;
  durationLabel: string;
  formats: LocationFormatId[];
  location: string;
}

/**
 * Payload for 59_TutorOfferDetail in "edit" mode — subject/level are fixed at
 * creation (shown read-only) and aren't part of the update payload.
 */
export interface UpdateOfferInput {
  title: string;
  description: string;
  durationLabel: string;
}
