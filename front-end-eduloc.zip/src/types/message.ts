/**
 * A conversation between a beneficiary and a tutor is scoped to a single
 * Booking (25_Conversation) and, per the spec, carries no free text — only
 * voice notes and documents ("Pas de message texte — vocal et documents
 * uniquement").
 */
export type ConversationMessageType = "voice" | "document";

export interface ConversationMessage {
  id: string;
  bookingId: string;
  /** Display name of the sender, e.g. "Jean" or "Vous". */
  authorLabel: string;
  /** True when the signed-in beneficiary sent this message. */
  isMine: boolean;
  type: ConversationMessageType;
  createdAt: string;
  /** Set when type is "voice" — e.g. "00:37". */
  durationLabel?: string;
  /** Set when type is "document". */
  fileName?: string;
  fileSizeLabel?: string;
}
