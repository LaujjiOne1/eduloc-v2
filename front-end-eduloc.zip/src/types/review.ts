/** Payload for 32_ReviewTutor's "Envoyer" — rates the tutor once a session is COMPLETED. */
export interface TutorReviewInput {
  rating: 1 | 2 | 3 | 4 | 5;
  comment: string;
}
