import type { EducationLevel, LocationFormatId } from "@/types/search";

/** A teachable skill/topic a tutor can pick from (e.g. "Python") with service scope. */
export interface TutorSkill {
  id: string;
  label: string;
  category?: string;
  description?: string;
  scope?: string;
}

export interface TutorIdentityFields {
  firstName: string;
  lastName: string;
  /** Free-text "JJ/MM/AAAA" — no date-picker component exists in this project yet. */
  birthDate: string;
  phone: string;
  email: string;
}

/** The tutor's own level of education — distinct from `EducationLevel`, which is the level(s) they *teach*. */
export type EducationDegreeId = "bac" | "licence" | "master" | "doctorat" | "other";

export interface EducationDegree {
  id: EducationDegreeId;
  label: string;
}

export type TutorExperienceType = "professionnelle" | "academique";

export interface TutorExperienceEntry {
  id: string;
  type: TutorExperienceType;
  title: string;
  organization: string;
  period: string;
  description?: string;
}

export interface TutorBackgroundFields {
  degree: EducationDegree | null;
  field: string;
  institution: string;
  experience: string;
  experiences?: TutorExperienceEntry[];
}

/** Levels a given skill is taught at (TutorSubjects step) — reuses the search wizard's EducationLevel catalog. */
export interface TutorSubjectLevels {
  skill: TutorSkill;
  levels: EducationLevel[];
}

export type OfferDurationId = "45m" | "1h" | "1h30" | "2h" | "3h";

export interface OfferDuration {
  id: OfferDurationId;
  label: string;
  hours: number;
}

export interface TutorOfferDraft {
  id: string;
  skill: TutorSkill | null;
  level: EducationLevel | null;
  title: string;
  description: string;
  duration: OfferDuration | null;
  /** Hourly rate in € */
  hourlyRate: number;
  /** Calculated total price per session based on hourlyRate * duration.hours */
  priceCalculated?: number;
}

export interface TutorLocationEntry {
  id: string;
  label: string;
  radiusKm: number;
  isPrimary?: boolean;
  address?: string;
}

export interface WeeklyDaySlot {
  id: string;
  startTime: string;
  endTime: string;
  format: LocationFormatId;
}

export interface WeeklyDayAvailability {
  dayId: "mon" | "tue" | "wed" | "thu" | "fri" | "sat" | "sun";
  dayLabel: string;
  active: boolean;
  slots: WeeklyDaySlot[];
}

export interface TutorAvailabilityEntry {
  id: string;
  dateLabel: string;
  timeRangeLabel: string;
  format: LocationFormatId;
  /** Location label shown for in-person availability; null for online-only slots. */
  locationLabel: string | null;
}

export type TutorDocumentKind = "proof_of_identity" | "diploma" | "other";

export interface TutorDocumentEntry {
  kind: TutorDocumentKind;
  label: string;
  provided: boolean;
  fileName?: string;
  fileSize?: string;
}

/** Full payload sent to the backend once the applicant submits (49_TutorApplicationSummary → "Soumettre"). */
export interface TutorApplicationSubmission {
  identity: TutorIdentityFields;
  background: TutorBackgroundFields;
  skills: TutorSkill[];
  subjectLevels: TutorSubjectLevels[];
  bio: string;
  offer: TutorOfferDraft;
  offers?: TutorOfferDraft[];
  formats: LocationFormatId[];
  locations: TutorLocationEntry[];
  availability: TutorAvailabilityEntry[];
  weeklyAvailability?: WeeklyDayAvailability[];
  documents: TutorDocumentEntry[];
}

/**
 * PENDING → APPROVED (EduLoc reviews the file) | REJECTED
 * A tutor only appears in search results once APPROVED — mirrors the
 * "vous n'apparaissez pas dans les résultats de recherche" note on 50_TutorApplicationPending.
 */
export type TutorApplicationStatus = "pending" | "approved" | "rejected";

export interface TutorApplication {
  id: string;
  status: TutorApplicationStatus;
  submittedAt: string;
}
