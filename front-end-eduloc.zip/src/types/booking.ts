import type { Offer, OfferSlot } from "@/types/offer";
import type { EducationLevel } from "@/types/search";

/**
 * PENDING → CONFIRMED (tutor accepts) → IN_PROGRESS → COMPLETED
 * PENDING → REFUSED | CANCELLED
 * CONFIRMED → CANCELLED
 */
export type BookingStatus =
  | "pending"
  | "confirmed"
  | "refused"
  | "cancelled"
  | "in_progress"
  | "completed";

export interface BeneficiaryProfile {
  firstName: string;
  lastName: string;
  /** null when the beneficiary is the requester themself — "relation to yourself" is meaningless. */
  relationLabel: string | null;
  level: EducationLevel;
  /** Optional free-text description of the beneficiary's main difficulty. */
  difficulty: string;
}

export interface BookingRequest {
  offerId: string;
  slotId: string;
  beneficiary: BeneficiaryProfile;
  /** Carried over from the search wizard's "Précisez votre besoin" step. */
  note: string;
}

export interface Booking {
  id: string;
  status: BookingStatus;
  offer: Offer;
  slot: OfferSlot;
  beneficiary: BeneficiaryProfile;
  note: string;
  createdAt: string;
  /** ISO timestamp set once IN_PROGRESS starts — powers 30_SessionInProgress's live timer. */
  sessionStartedAt?: string;
  /** Set once COMPLETED — display label for 31_SessionCompleted's "Durée : ...". */
  sessionDurationLabel?: string;
  /**
   * Set once IN_PROGRESS starts on the tutor side (64_TutorStartSession) —
   * "online" after a validated session code, "in_person" via the presential
   * shortcut. Decides which in-progress screen 62_TutorAppointmentDetail's
   * "Rejoindre la séance" reopens (65 vs 67).
   */
  sessionMode?: "online" | "in_person";
}
