export interface LoginCredentials {
  email: string;
  password: string;
}

export interface SignupPayload {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
}

export interface AuthenticatedUser {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

export type OAuthProvider = "google" | "apple";

export type AuthErrorCode =
  | "invalid_credentials"
  | "email_already_used"
  | "validation_error"
  | "provider_not_configured"
  | "network_error"
  | "unknown_error";
