import type { Category } from "@/types/category";

/** A level of education the tutoring need is scoped to (e.g. "Université"). */
export type EducationLevelId = "primary" | "middle_school" | "high_school" | "university" | "professional";

export interface EducationLevel {
  id: EducationLevelId;
  label: string;
}

/** Who the booked course is for, relative to the person searching. */
export type BeneficiaryTypeId = "myself" | "child" | "relative" | "other";

export interface BeneficiaryType {
  id: BeneficiaryTypeId;
  label: string;
  description: string;
}

/** How the course should be delivered. */
export type LocationFormatId = "in_person" | "online" | "both";

export interface LocationFormatOption {
  id: LocationFormatId;
  label: string;
}

/** The learning goal driving the search (exam prep, refresher, etc.). */
export type LearningObjectiveId =
  | "basics"
  | "refresher"
  | "exam_prep"
  | "deepen"
  | "regular_support"
  | "other";

export interface LearningObjective {
  id: LearningObjectiveId;
  label: string;
}

export interface SearchLocation {
  /** Free-text address/neighborhood, or the reverse-geocoded label set by "Utiliser ma position". */
  query: string;
  useCurrentPosition: boolean;
  format: LocationFormatId;
}

export interface SearchDetail {
  /** Optional free-text description of the need, shown to the matched tutor. */
  note: string;
}

/**
 * Selections accumulated across the search wizard (Need → Level → ForWhom →
 * Location → Objective → Detail). Matches the eventual payload for a future
 * tutor-matching/search endpoint.
 */
export interface SearchCriteria {
  subject: Category | null;
  level: EducationLevel | null;
  beneficiary: BeneficiaryType | null;
  location: SearchLocation;
  objective: LearningObjective | null;
  detail: SearchDetail;
}
