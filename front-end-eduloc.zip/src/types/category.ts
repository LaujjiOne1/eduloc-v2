/**
 * A subject/category a user can search a tutor for (e.g. "Mathématiques").
 * Powers the "Recherches populaires" shortcuts on the Home screen.
 */
export interface Category {
  id: string;
  label: string;
}
