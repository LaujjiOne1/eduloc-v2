/**
 * booking_accepted / booking_refused mirror the BookingStatus transitions
 * (PENDING → CONFIRMED / PENDING → REFUSED, see types/booking.ts) surfaced as
 * a notification. new_message and reminder are informational and aren't tied
 * to a status change.
 */
export type NotificationType = "booking_accepted" | "booking_refused" | "new_message" | "reminder";

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  /** Pre-formatted relative time label ("2h", "Hier", ...) — matches 33_Notifications; no live recomputation in this batch. */
  timeLabel: string;
  /** Groups the list into the screen's date sections ("Aujourd'hui", "Hier", ...). */
  dateGroup: string;
}
