import type { TutorAvatarTone } from "@/types/tutor";
import type { TutorLocationEntry, TutorSkill, TutorSubjectLevels } from "@/types/tutor-application";

/**
 * The signed-in tutor's own profile, as shown on 60_TutorProfilePage — reuses
 * the onboarding's skill/subject/location shapes since it's the same data,
 * now approved and read back instead of being drafted.
 */
export interface TutorProfileSummary {
  id: string;
  firstName: string;
  lastName: string;
  avatarInitials: string;
  avatarTone: TutorAvatarTone;
  rating: number;
  reviewCount: number;
  bio: string;
  skills: TutorSkill[];
  subjects: TutorSubjectLevels[];
  locations: TutorLocationEntry[];
}
