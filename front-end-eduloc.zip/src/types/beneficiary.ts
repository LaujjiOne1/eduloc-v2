import type { EducationLevel } from "@/types/search";

/**
 * A beneficiary saved to the requester's address book (34_Beneficiaries) so
 * it can be reused across future bookings. Distinct from BeneficiaryProfile
 * (types/booking.ts), which is the one-off snapshot collected per booking on
 * the 17_Beneficiary wizard step.
 */
export interface SavedBeneficiary {
  id: string;
  firstName: string;
  lastName: string;
  /** True only for the signed-in user's own "(vous)" entry — seeded, never created via the add form. */
  isSelf: boolean;
  /** null for the self entry — "relation to yourself" is meaningless (mirrors BeneficiaryProfile). */
  relationLabel: string | null;
  /** null when no level has been set yet (the reference screen's self entry shows "—"). */
  level: EducationLevel | null;
}

export interface CreateBeneficiaryInput {
  firstName: string;
  lastName: string;
  relationLabel: string;
  level: EducationLevel;
}
