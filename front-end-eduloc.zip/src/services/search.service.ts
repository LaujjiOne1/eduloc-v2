import type {
  BeneficiaryType,
  EducationLevel,
  LearningObjective,
  LocationFormatOption,
} from "@/types/search";

/**
 * Backend contract (not yet implemented server-side):
 *
 *   GET /reference-data/levels
 *   GET /reference-data/beneficiary-types
 *   GET /reference-data/location-formats
 *   GET /reference-data/objectives
 *
 *   Auth:      none (public — used while composing a search, before login)
 *   Response:  EducationLevel[] / BeneficiaryType[] / LocationFormatOption[] / LearningObjective[]
 *   Errors:    500
 *
 * Until these endpoints exist, this returns mocked reference data so the
 * search wizard screens can be built against the final shape. Swap the mock
 * bodies for real HTTP calls here only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 300;

const MOCK_LEVELS: EducationLevel[] = [
  { id: "primary", label: "Primaire" },
  { id: "middle_school", label: "Collège" },
  { id: "high_school", label: "Lycée" },
  { id: "university", label: "Université" },
  { id: "professional", label: "Professionnel" },
];

const MOCK_BENEFICIARY_TYPES: BeneficiaryType[] = [
  { id: "myself", label: "Pour moi", description: "Vous êtes le bénéficiaire du cours" },
  { id: "child", label: "Mon enfant", description: "Réservez pour votre enfant" },
  { id: "relative", label: "Un proche", description: "Un membre de votre famille" },
  { id: "other", label: "Autre personne", description: "Précisez qui suivra le cours" },
];

const MOCK_LOCATION_FORMATS: LocationFormatOption[] = [
  { id: "in_person", label: "En présentiel" },
  { id: "online", label: "En ligne" },
  { id: "both", label: "Les deux" },
];

const MOCK_OBJECTIVES: LearningObjective[] = [
  { id: "basics", label: "Comprendre les bases" },
  { id: "refresher", label: "Remise à niveau" },
  { id: "exam_prep", label: "Préparer un examen" },
  { id: "deepen", label: "Approfondir" },
  { id: "regular_support", label: "Accompagnement régulier" },
  { id: "other", label: "Autre" },
];

function mockFetch<T>(data: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(data), MOCK_LATENCY_MS));
}

export const SearchService = {
  async getLevels(): Promise<EducationLevel[]> {
    return mockFetch(MOCK_LEVELS);
  },
  async getBeneficiaryTypes(): Promise<BeneficiaryType[]> {
    return mockFetch(MOCK_BENEFICIARY_TYPES);
  },
  async getLocationFormats(): Promise<LocationFormatOption[]> {
    return mockFetch(MOCK_LOCATION_FORMATS);
  },
  async getObjectives(): Promise<LearningObjective[]> {
    return mockFetch(MOCK_OBJECTIVES);
  },
};
