export class LocationServiceError extends Error {
  code: "permission_denied" | "position_unavailable";

  constructor(code: "permission_denied" | "position_unavailable", message: string) {
    super(message);
    this.code = code;
  }
}

/**
 * Device capability contract (not a backend HTTP endpoint):
 *
 *   LocationService.getCurrentPosition()
 *   Real implementation will use `expo-location` (not yet installed in this
 *   project — out of scope for this task) to request foreground permission,
 *   read the device's GPS coordinates, then reverse-geocode them into a
 *   human-readable label.
 *   Errors: permission_denied, position_unavailable
 *
 * Mocked until `expo-location` is added, so the "Utiliser ma position" action
 * on the Location step can be built against the final shape.
 */
const MOCK_LATENCY_MS = 700;

export const LocationService = {
  async getCurrentPosition(): Promise<{ label: string }> {
    return new Promise((resolve) => {
      setTimeout(() => resolve({ label: "Position actuelle" }), MOCK_LATENCY_MS);
    });
  },
};
