import type { SearchCriteria } from "@/types/search";
import type { Tutor } from "@/types/tutor";
import type { TutorProfileSummary } from "@/types/tutor-profile";

export class TutorServiceError extends Error {
  code: "not_found";

  constructor(code: "not_found", message: string) {
    super(message);
    this.code = code;
  }
}

/**
 * Backend contract (not yet implemented server-side):
 *
 *   GET /tutors/search?subjectId=&levelId=&beneficiaryType=&locationQuery=&format=&objectiveId=
 *   Auth:      none (public)
 *   Response:  Tutor[]
 *   Errors:    500
 *
 *   GET /tutors/:id
 *   Auth:      none (public)
 *   Response:  Tutor
 *   Errors:    404 not_found, 500
 *
 * Until these endpoints exist, this returns mocked data so the Results,
 * ResultsMap and TutorProfile screens can be built against the final shape.
 * The mock ignores `criteria` and always returns the same fixed dataset —
 * real filtering/matching happens server-side. Swap the mock bodies for real
 * HTTP calls here only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 450;

const MOCK_TUTORS: Tutor[] = [
  {
    id: "jean-rakoto",
    firstName: "Jean",
    lastName: "Rakoto",
    avatarTone: "primary",
    rating: 4.8,
    reviewCount: 24,
    isVerified: true,
    subjects: ["Python", "Algorithmique", "Bases de données"],
    levels: ["Université", "Professionnel"],
    formats: ["in_person", "online"],
    location: { label: "Ankorondrano", distanceKm: 1.2, latitude: -18.8856, longitude: 47.5255 },
    nextSlotLabel: "Prochain créneau : samedi 14h",
    bio: "Développeur spécialisé en Python et en algorithmique, j'accompagne étudiants et professionnels vers l'autonomie sur leurs projets techniques — pédagogie progressive et exercices concrets.",
    offers: [
      { id: "python-debutant", title: "Python pour débutants", durationLabel: "2h", formats: ["in_person", "online"] },
      { id: "prep-algo", title: "Préparation examen Algo", durationLabel: "1h30", formats: ["online"] },
    ],
  },
  {
    id: "hery-andria",
    firstName: "Hery",
    lastName: "Andria",
    avatarTone: "violet",
    rating: 4.6,
    reviewCount: 16,
    isVerified: true,
    subjects: ["Algorithmique"],
    levels: ["Université"],
    formats: ["in_person"],
    location: { label: "Analakely", distanceKm: 2.4, latitude: -18.9082, longitude: 47.5242 },
    nextSlotLabel: "Prochain créneau : dimanche 10h",
    bio: "Spécialiste en algorithmique, j'aide les étudiants à structurer leur logique de programmation à travers des exercices progressifs.",
    offers: [{ id: "algo-bases", title: "Algorithmique — Bases", durationLabel: "1h30", formats: ["in_person"] }],
  },
  {
    id: "nina-rasoa",
    firstName: "Nina",
    lastName: "Rasoa",
    avatarTone: "accent",
    rating: 5.0,
    reviewCount: 31,
    isVerified: true,
    subjects: ["Python", "SQL"],
    levels: ["Professionnel"],
    formats: ["online"],
    location: { label: "En ligne", distanceKm: null, latitude: -18.9195, longitude: 47.5285 },
    nextSlotLabel: "Prochain créneau : lundi 18h",
    bio: "Experte Python et bases de données, j'accompagne les professionnels dans la maîtrise de leurs outils au quotidien.",
    offers: [{ id: "python-sql-avance", title: "Python & SQL avancé", durationLabel: "2h", formats: ["online"] }],
  },
];

function mockFetch<T>(data: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(data), MOCK_LATENCY_MS));
}

/**
 * Stand-in for "the signed-in tutor's id" until the backend/session model is
 * role-aware (see MOCK_MY_PROFILE below) — shared by the hooks that need to
 * scope requests/offers/availability to the current tutor.
 */
export const CURRENT_TUTOR_ID = "jean-rakoto";

const UNIVERSITY_LEVEL = { id: "university" as const, label: "Université" };
const PROFESSIONAL_LEVEL = { id: "professional" as const, label: "Professionnel" };

/**
 * Mocked "current tutor" profile for the dashboard (51/60_TutorProfilePage) —
 * matches the jean-rakoto entry in MOCK_TUTORS above, plus the skill/subject
 * detail that only the tutor's own profile shows. There is no real
 * tutor-session concept yet (auth.store's user isn't role-aware) — signalled
 * rather than invented per AGENTS.md §8; swap this mock for a real
 * `GET /tutors/me` call once the backend/session model exists.
 */
const MOCK_MY_PROFILE: TutorProfileSummary = {
  id: CURRENT_TUTOR_ID,
  firstName: "Jean",
  lastName: "Rakoto",
  avatarInitials: "JR",
  avatarTone: "primary",
  rating: 4.8,
  reviewCount: 24,
  bio: "Développeur spécialisé en Python et en algorithmique, j'accompagne étudiants et professionnels vers l'autonomie sur leurs projets techniques — pédagogie progressive et exercices concrets.",
  skills: [
    { id: "python", label: "Python" },
    { id: "algorithmique", label: "Algorithmique" },
  ],
  subjects: [
    { skill: { id: "python", label: "Python" }, levels: [UNIVERSITY_LEVEL, PROFESSIONAL_LEVEL] },
    { skill: { id: "algorithmique", label: "Algorithmique" }, levels: [UNIVERSITY_LEVEL, PROFESSIONAL_LEVEL] },
  ],
  locations: [
    { id: "ankorondrano", label: "Ankorondrano", radiusKm: 5 },
    { id: "analakely", label: "Analakely", radiusKm: 5 },
  ],
};

export const TutorService = {
  async searchTutors(_criteria: SearchCriteria): Promise<Tutor[]> {
    return mockFetch(MOCK_TUTORS);
  },

  async getTutorById(id: string): Promise<Tutor> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const tutor = MOCK_TUTORS.find((t) => t.id === id);
        if (tutor) resolve(tutor);
        else reject(new TutorServiceError("not_found", "Ce tuteur est introuvable."));
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /tutors/me
   *   Auth:      required (Bearer token)
   *   Response:  TutorProfileSummary
   *
   * Powers 51_TutorDashboard's header/greeting and 60_TutorProfilePage.
   */
  async getMyProfile(): Promise<TutorProfileSummary> {
    return mockFetch(MOCK_MY_PROFILE);
  },
};
