import type { CreateOfferInput, Offer, UpdateOfferInput } from "@/types/offer";

export class OfferServiceError extends Error {
  code: "not_found";

  constructor(code: "not_found", message: string) {
    super(message);
    this.code = code;
  }
}

/**
 * Backend contract (not yet implemented server-side):
 *
 *   GET /offers/:id
 *   Auth:      none (public)
 *   Response:  Offer
 *   Errors:    404 not_found, 500
 *
 * Until this endpoint exists, this returns mocked data so the OfferDetail
 * screen can be built against the final shape. Offer ids must stay in sync
 * with the `offers` summaries returned by TutorService's mock — a real
 * backend would guarantee that relationship itself. Swap the mock body for a
 * real HTTP call here only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 400;

export const MOCK_OFFERS: Offer[] = [
  {
    id: "python-debutant",
    tutorId: "jean-rakoto",
    tutorName: "Jean Rakoto",
    tutorInitial: "J",
    title: "Python — Niveau débutant",
    description:
      "Une introduction concrète à Python : syntaxe, structures de données et premiers scripts, avec des exercices adaptés à votre rythme.",
    subjectLabel: "Python",
    levelLabel: "Université",
    durationLabel: "2 heures",
    formats: ["in_person", "online"],
    location: "Ankorondrano",
    isActive: true,
    slots: [
      {
        id: "slot-1",
        date: "2026-09-19",
        dateLabel: "Samedi 19 septembre",
        startTime: "14:00",
        endTime: "16:00",
        timeRangeLabel: "14:00 → 16:00",
        status: "available",
      },
      {
        id: "slot-2",
        date: "2026-09-26",
        dateLabel: "Samedi 26 septembre",
        startTime: "14:00",
        endTime: "16:00",
        timeRangeLabel: "14:00 → 16:00",
        status: "available",
      },
      {
        id: "slot-3",
        date: "2026-09-27",
        dateLabel: "Dimanche 27 septembre",
        startTime: "10:00",
        endTime: "12:00",
        timeRangeLabel: "10:00 → 12:00",
        status: "available",
      },
    ],
  },
  {
    id: "prep-algo",
    tutorId: "jean-rakoto",
    tutorName: "Jean Rakoto",
    tutorInitial: "J",
    title: "Préparation examen Algo",
    description:
      "Révision ciblée des structures de données et algorithmes classiques, avec des sujets d'examen type pour s'entraîner en conditions réelles.",
    subjectLabel: "Algorithmique",
    levelLabel: "Université",
    durationLabel: "1 heure 30",
    formats: ["online"],
    location: "En ligne",
    // Seeded inactive so both 58_TutorOffers badge states (Active/Désactivée)
    // are exercised as soon as the offers list loads, without requiring the
    // tutor to toggle one first.
    isActive: false,
    slots: [
      {
        id: "slot-4",
        date: "2026-09-22",
        dateLabel: "Mardi 22 septembre",
        startTime: "18:00",
        endTime: "19:30",
        timeRangeLabel: "18:00 → 19:30",
        status: "available",
      },
      {
        id: "slot-5",
        date: "2026-09-24",
        dateLabel: "Jeudi 24 septembre",
        startTime: "18:00",
        endTime: "19:30",
        timeRangeLabel: "18:00 → 19:30",
        status: "available",
      },
    ],
  },
  {
    id: "algo-bases",
    tutorId: "hery-andria",
    tutorName: "Hery Andria",
    tutorInitial: "H",
    title: "Algorithmique — Bases",
    description:
      "Les fondamentaux de l'algorithmique expliqués pas à pas : logique conditionnelle, boucles et premiers algorithmes de tri.",
    subjectLabel: "Algorithmique",
    levelLabel: "Université",
    durationLabel: "1 heure 30",
    formats: ["in_person"],
    location: "Analakely",
    isActive: true,
    slots: [
      {
        id: "slot-6",
        date: "2026-09-20",
        dateLabel: "Dimanche 20 septembre",
        startTime: "10:00",
        endTime: "11:30",
        timeRangeLabel: "10:00 → 11:30",
        status: "available",
      },
    ],
  },
  {
    id: "python-sql-avance",
    tutorId: "nina-rasoa",
    tutorName: "Nina Rasoa",
    tutorInitial: "N",
    title: "Python & SQL avancé",
    description:
      "Manipulation de données avec Python et SQL pour des cas d'usage professionnels : requêtes complexes, jointures et scripts d'automatisation.",
    subjectLabel: "Python",
    levelLabel: "Professionnel",
    durationLabel: "2 heures",
    formats: ["online"],
    location: "En ligne",
    isActive: true,
    slots: [
      {
        id: "slot-7",
        date: "2026-09-21",
        dateLabel: "Lundi 21 septembre",
        startTime: "18:00",
        endTime: "20:00",
        timeRangeLabel: "18:00 → 20:00",
        status: "available",
      },
    ],
  },
  {
    id: "maths-lycee",
    tutorId: "sarah-ilo",
    tutorName: "Sarah Ilo",
    tutorInitial: "S",
    title: "Mathématiques",
    description:
      "Un accompagnement en mathématiques axé sur la compréhension des notions clés et la pratique d'exercices types, au rythme de l'élève.",
    subjectLabel: "Mathématiques",
    levelLabel: "Lycée",
    durationLabel: "1 heure 30",
    formats: ["in_person", "online"],
    location: "Ankorondrano",
    isActive: true,
    slots: [
      {
        id: "slot-8",
        date: "2026-09-22",
        dateLabel: "Mardi 22 septembre",
        startTime: "16:00",
        endTime: "17:30",
        timeRangeLabel: "16:00 → 17:30",
        status: "available",
      },
    ],
  },
];

export const OfferService = {
  async getOfferById(id: string): Promise<Offer> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const offer = MOCK_OFFERS.find((o) => o.id === id);
        if (offer) resolve(offer);
        else reject(new OfferServiceError("not_found", "Cette offre est introuvable."));
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /tutors/me/offers
   *   Auth:      required (Bearer token)
   *   Response:  Offer[]
   *
   * Powers 58_TutorOffers — mocked by filtering MOCK_OFFERS by tutorId until
   * a real "current tutor" session exists (see TutorService.getMyProfile).
   */
  async getTutorOffers(tutorId: string): Promise<Offer[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve(MOCK_OFFERS.filter((o) => o.tutorId === tutorId)), MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   PATCH /offers/:id
   *   Auth:      required (Bearer token, must own the offer)
   *   Body:      UpdateOfferInput
   *   Response:  Offer
   *   Errors:    404 not_found, 422 validation_error, 500
   *
   * Powers 59_TutorOfferDetail's "Enregistrer" in edit mode.
   */
  async updateOffer(id: string, data: UpdateOfferInput): Promise<Offer> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = MOCK_OFFERS.findIndex((o) => o.id === id);
        if (index === -1) {
          reject(new OfferServiceError("not_found", "Cette offre est introuvable."));
          return;
        }
        MOCK_OFFERS[index] = { ...MOCK_OFFERS[index], ...data };
        resolve(MOCK_OFFERS[index]);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   PATCH /offers/:id/status
   *   Auth:      required (Bearer token, must own the offer)
   *   Body:      { isActive: boolean }
   *   Response:  Offer
   *   Errors:    404 not_found, 500
   *
   * Powers 59_TutorOfferDetail's "Désactiver l'offre" / "Réactiver l'offre".
   */
  async updateOfferStatus(id: string, isActive: boolean): Promise<Offer> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = MOCK_OFFERS.findIndex((o) => o.id === id);
        if (index === -1) {
          reject(new OfferServiceError("not_found", "Cette offre est introuvable."));
          return;
        }
        MOCK_OFFERS[index] = { ...MOCK_OFFERS[index], isActive };
        resolve(MOCK_OFFERS[index]);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /offers
   *   Auth:      required (Bearer token)
   *   Body:      CreateOfferInput
   *   Response:  Offer (isActive: true)
   *   Errors:    422 validation_error, 500
   *
   * Powers 59_TutorOfferDetail's "Enregistrer" in create mode ("Nouvelle offre").
   */
  async createOffer(
    tutorId: string,
    tutorName: string,
    tutorInitial: string,
    data: CreateOfferInput,
  ): Promise<Offer> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const offer: Offer = {
          id: `offer-${Date.now()}`,
          tutorId,
          tutorName,
          tutorInitial,
          ...data,
          isActive: true,
          slots: [],
        };
        MOCK_OFFERS.push(offer);
        resolve(offer);
      }, MOCK_LATENCY_MS);
    });
  },
};
