import type {
  AuthenticatedUser,
  AuthErrorCode,
  LoginCredentials,
  OAuthProvider,
  SignupPayload,
} from "@/types/auth";

export class AuthServiceError extends Error {
  code: AuthErrorCode;

  constructor(code: AuthErrorCode, message: string) {
    super(message);
    this.code = code;
  }
}

/**
 * Backend contract (not yet implemented server-side):
 *
 *   POST /auth/login
 *     Body:      LoginCredentials
 *     Response:  { user: AuthenticatedUser, accessToken: string }
 *     Errors:    401 invalid_credentials, 422 validation_error, 500
 *
 *   POST /auth/signup
 *     Body:      SignupPayload
 *     Response:  { user: AuthenticatedUser, accessToken: string }
 *     Errors:    409 email_already_used, 422 validation_error, 500
 *
 *   POST /auth/oauth/:provider   (provider = "google" | "apple")
 *     Body:      { idToken: string }
 *     Response:  { user: AuthenticatedUser, accessToken: string }
 *     Errors:    401 invalid_credentials, 500
 *     Note: obtaining `idToken` requires a native SDK (expo-auth-session for
 *     Google, expo-apple-authentication for Apple) that isn't wired up yet —
 *     out of scope for this task, see loginWithProvider below.
 *
 *   POST /auth/verify-email
 *     Body:      { email: string, code: string }
 *     Response:  { verified: true }
 *     Errors:    400 invalid_code, 410 code_expired, 500
 *     Note: there's no real backend to validate a code against yet, so the
 *     mock accepts any syntactically valid 6-digit code — same "signal
 *     rather than fake it" approach already used for OAuth above.
 *
 *   POST /auth/resend-verification
 *     Body:      { email: string }
 *     Response:  { sent: true }
 *     Errors:    429 too_many_requests, 500
 *
 * Until the endpoints exist, these are mocked so the screens can be built
 * against the final shape. Swap the mock bodies for real HTTP calls here
 * only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 500;

const mockUserFromEmail = (email: string): AuthenticatedUser => ({
  id: `mock-${email}`,
  firstName: "",
  lastName: "",
  email,
});

export const AuthService = {
  async login({ email, password }: LoginCredentials): Promise<AuthenticatedUser> {
    if (!password) {
      throw new AuthServiceError("invalid_credentials", "Email ou mot de passe incorrect.");
    }
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockUserFromEmail(email)), MOCK_LATENCY_MS);
    });
  },

  async signup(payload: SignupPayload): Promise<AuthenticatedUser> {
    return new Promise((resolve) => {
      setTimeout(
        () =>
          resolve({
            id: `mock-${payload.email}`,
            firstName: payload.firstName,
            lastName: payload.lastName,
            email: payload.email,
          }),
        MOCK_LATENCY_MS,
      );
    });
  },

  async loginWithProvider(provider: OAuthProvider): Promise<AuthenticatedUser> {
    throw new AuthServiceError(
      "provider_not_configured",
      provider === "google"
        ? "La connexion avec Google n'est pas encore disponible."
        : "La connexion avec Apple n'est pas encore disponible.",
    );
  },

  async verifyEmail({ code }: { email: string; code: string }): Promise<void> {
    if (!/^\d{6}$/.test(code)) {
      throw new AuthServiceError("validation_error", "Le code doit contenir 6 chiffres.");
    }
    return new Promise((resolve) => {
      setTimeout(resolve, MOCK_LATENCY_MS);
    });
  },

  async resendVerificationCode({ email: _email }: { email: string }): Promise<void> {
    return new Promise((resolve) => {
      setTimeout(resolve, MOCK_LATENCY_MS);
    });
  },
};
