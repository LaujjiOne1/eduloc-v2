import type { Category } from "@/types/category";

/**
 * Backend contract (not yet implemented server-side):
 *
 *   GET /categories/popular
 *   GET /categories
 *   Auth:      none (public)
 *   Response:  Category[]
 *   Errors:    500 (server error) — surfaced to the caller as a rejected promise
 *
 * Until the endpoints exist, this returns mocked data so the Home screen and
 * the search wizard's "Que recherchez-vous ?" step can be built against the
 * final shape. Swap the mock bodies for real HTTP calls here only —
 * screens/hooks must not change.
 */
const MOCK_POPULAR_CATEGORIES: Category[] = [
  { id: "programming", label: "Programmation" },
  { id: "math", label: "Mathématiques" },
  { id: "languages", label: "Langues" },
  { id: "finance", label: "Finance" },
];

const MOCK_ALL_CATEGORIES: Category[] = [
  ...MOCK_POPULAR_CATEGORIES,
  { id: "sciences", label: "Sciences" },
  { id: "methodology", label: "Méthodologie" },
];

const MOCK_LATENCY_MS = 350;

export const CategoryService = {
  async getPopularCategories(): Promise<Category[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve(MOCK_POPULAR_CATEGORIES), MOCK_LATENCY_MS);
    });
  },

  async getCategories(): Promise<Category[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve(MOCK_ALL_CATEGORIES), MOCK_LATENCY_MS);
    });
  },
};
