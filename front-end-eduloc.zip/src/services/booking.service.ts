import { MOCK_OFFERS, OfferService } from "@/services/offer.service";
import type { Booking, BookingRequest } from "@/types/booking";

export class BookingServiceError extends Error {
  code: "slot_unavailable" | "validation_error" | "unauthorized" | "not_found" | "invalid_state";

  constructor(
    code: "slot_unavailable" | "validation_error" | "unauthorized" | "not_found" | "invalid_state",
    message: string,
  ) {
    super(message);
    this.code = code;
  }
}

/**
 * Backend contract (not yet implemented server-side):
 *
 *   POST /bookings
 *   Auth:      required (Bearer token)
 *   Body:      BookingRequest
 *   Response:  Booking (status: "pending" — the tutor must accept it to
 *              reach "confirmed", per the PENDING → CONFIRMED transition
 *              defined in the spec)
 *   Errors:    401 unauthorized, 409 slot_unavailable, 422 validation_error, 500
 *
 * Until the endpoint exists, this resolves a mocked Booking built from the
 * offer/slot already fetched by OfferService, so BookingSummary/Pending can
 * be built against the final shape. Swap the mock body for a real HTTP call
 * here only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 700;

/**
 * Deterministic per booking id so it stays stable across re-fetches within a
 * mock session — a real backend would generate and persist this. Shared by
 * getSessionCode (beneficiary reads it) and startTutorSession (tutor types it
 * back) so the two sides of the same mock booking agree on one value.
 */
function computeSessionCode(bookingId: string): string {
  const numeric = Array.from(bookingId).reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
  const code = String(100000 + (numeric * 7919) % 900000);
  return `${code.slice(0, 3)} ${code.slice(3)}`;
}

const UNIVERSITY_LEVEL = { id: "university" as const, label: "Université" };

/**
 * Mock incoming requests for the signed-in tutor's dashboard (51/52/53). Kept
 * mutable in-memory so accept/refuse feel real within a session — a real
 * backend owns this list. "booking-nadia" is seeded to always conflict on
 * accept (see acceptBooking below), matching 20 sept/10h showing as still
 * "Disponible" on 56_TutorCalendar: nothing has actually claimed it yet from
 * the tutor's own availability, but another request beats this one to
 * confirmation — the realistic scenario 55_TutorRequestConflict describes.
 */
let mockTutorBookings: Booking[] = [
  {
    id: "booking-thomas",
    status: "pending",
    offer: MOCK_OFFERS.find((o) => o.id === "python-debutant")!,
    slot: MOCK_OFFERS.find((o) => o.id === "python-debutant")!.slots[0],
    beneficiary: { firstName: "Thomas", lastName: "", relationLabel: null, level: UNIVERSITY_LEVEL, difficulty: "" },
    note: "Préparation examen",
    createdAt: "2026-09-15T09:00:00.000Z",
  },
  {
    id: "booking-nadia",
    status: "pending",
    offer: MOCK_OFFERS.find((o) => o.id === "prep-algo")!,
    slot: {
      id: "slot-nadia",
      date: "2026-09-20",
      dateLabel: "Dimanche 20 septembre",
      startTime: "10:00",
      endTime: "11:30",
      timeRangeLabel: "10:00 → 11:30",
      status: "available",
    },
    beneficiary: { firstName: "Nadia", lastName: "", relationLabel: null, level: UNIVERSITY_LEVEL, difficulty: "" },
    note: "Révisions avant l'examen d'algorithmique",
    createdAt: "2026-09-16T14:00:00.000Z",
  },
  // Already CONFIRMED so 61_TutorAppointments/62_TutorAppointmentDetail have
  // something to show without first requiring a trip through the Requests
  // accept flow — same Thomas/Python story as 61-67's mock, on the offer's
  // other Saturday slot so it doesn't contradict "booking-thomas" above
  // (still pending) by claiming to be both pending and confirmed at once.
  {
    id: "booking-thomas-confirmed",
    status: "confirmed",
    offer: MOCK_OFFERS.find((o) => o.id === "python-debutant")!,
    slot: MOCK_OFFERS.find((o) => o.id === "python-debutant")!.slots[1],
    beneficiary: { firstName: "Thomas", lastName: "", relationLabel: null, level: UNIVERSITY_LEVEL, difficulty: "" },
    note: "Préparation examen",
    createdAt: "2026-09-10T09:00:00.000Z",
  },
];

/**
 * Stand-in for "the signed-in beneficiary's id" until the backend/session
 * model is role-aware — mirrors TutorService.CURRENT_TUTOR_ID. Scopes
 * getMyBookings for the 21_ApprentiDashboard / 22_MyBookings screens.
 */
export const CURRENT_BENEFICIARY_ID = "tida";

const LYCEE_LEVEL = { id: "high_school" as const, label: "Lycée" };

/**
 * Mock bookings for the signed-in beneficiary's dashboard (21/22/23/24).
 * Kept mutable in-memory, like mockTutorBookings, so cancel/session actions
 * feel real within a session. Seeded with one PENDING booking (drives
 * 23_BookingDetailPending — no in-app action promotes it to CONFIRMED here,
 * since that transition belongs to the tutor's own accept flow, out of this
 * screen group's scope) and one CONFIRMED booking (drives 24 → 29 → 30 → 31 → 32).
 */
let mockApprentiBookings: Booking[] = [
  {
    id: "booking-python-pending",
    status: "pending",
    offer: MOCK_OFFERS.find((o) => o.id === "python-debutant")!,
    slot: MOCK_OFFERS.find((o) => o.id === "python-debutant")!.slots[0],
    beneficiary: { firstName: "Tida", lastName: "", relationLabel: null, level: UNIVERSITY_LEVEL, difficulty: "" },
    note: "Préparation aux exercices de boucles et fonctions",
    createdAt: "2026-09-15T09:00:00.000Z",
  },
  {
    id: "booking-maths-confirmed",
    status: "confirmed",
    offer: MOCK_OFFERS.find((o) => o.id === "maths-lycee")!,
    slot: MOCK_OFFERS.find((o) => o.id === "maths-lycee")!.slots[0],
    beneficiary: { firstName: "Tida", lastName: "", relationLabel: null, level: LYCEE_LEVEL, difficulty: "" },
    note: "Révisions avant le contrôle",
    createdAt: "2026-09-14T11:00:00.000Z",
  },
];

export const BookingService = {
  async createBooking(request: BookingRequest): Promise<Booking> {
    const offer = await OfferService.getOfferById(request.offerId).catch(() => {
      throw new BookingServiceError("slot_unavailable", "Cette offre n'est plus disponible.");
    });

    const slot = offer.slots.find((s) => s.id === request.slotId);
    if (!slot) {
      throw new BookingServiceError("slot_unavailable", "Ce créneau n'est plus disponible.");
    }

    return new Promise((resolve) => {
      setTimeout(() => {
        const booking: Booking = {
          id: `booking-${Date.now()}`,
          status: "pending",
          offer,
          slot,
          beneficiary: request.beneficiary,
          note: request.note,
          createdAt: new Date().toISOString(),
        };
        // The requester who just submitted this booking owns it — it must
        // show up in their own 22_MyBookings list right away.
        mockApprentiBookings = [booking, ...mockApprentiBookings];
        resolve(booking);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /users/me/bookings
   *   Auth:      required (Bearer token)
   *   Response:  Booking[]
   *
   * Powers 21_ApprentiDashboard's "Prochain rendez-vous" preview and
   * 22_MyBookings' three tabs (À venir / En attente / Historique).
   */
  async getMyBookings(_beneficiaryId: string): Promise<Booking[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve([...mockApprentiBookings]), MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /bookings/:id
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Response:  Booking
   *   Errors:    404 not_found
   *
   * Powers 23_BookingDetailPending, 24_BookingConfirmed and every screen in
   * the conversation/session sub-flow (25-32), all reached by booking id.
   */
  async getMyBookingById(id: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const booking = mockApprentiBookings.find((b) => b.id === id);
        if (booking) resolve(booking);
        else reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
      }, MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/cancel
   *   Auth:      required (Bearer token, must be the beneficiary)
   *   Response:  Booking (status: "cancelled")
   *   Errors:    404 not_found, 409 invalid_state (already cancelled/completed), 500
   *
   * Powers 23_BookingDetailPending's "Annuler la demande" and
   * 24_BookingConfirmed's "Annuler" — PENDING|CONFIRMED → CANCELLED.
   */
  async cancelBooking(bookingId: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockApprentiBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
          return;
        }
        const current = mockApprentiBookings[index];
        if (current.status !== "pending" && current.status !== "confirmed") {
          reject(new BookingServiceError("invalid_state", "Ce rendez-vous ne peut plus être annulé."));
          return;
        }
        mockApprentiBookings[index] = { ...current, status: "cancelled" };
        resolve(mockApprentiBookings[index]);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /bookings/:id/session-code
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Response:  { code: string }
   *   Errors:    404 not_found, 409 invalid_state (booking isn't confirmed)
   *
   * Powers 24_BookingConfirmed's preview and 29_SessionOTP — the code the
   * beneficiary reads out to the tutor to start the session.
   */
  async getSessionCode(bookingId: string): Promise<string> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const booking = mockApprentiBookings.find((b) => b.id === bookingId);
        if (!booking) {
          reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
          return;
        }
        resolve(computeSessionCode(bookingId));
      }, MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/start-session
   *   Auth:      required (Bearer token, must be the tutor — triggered by the
   *              tutor entering the beneficiary's session code)
   *   Response:  Booking (status: "in_progress", sessionStartedAt set)
   *   Errors:    404 not_found, 409 invalid_state (booking isn't confirmed)
   *
   * Powers 29_SessionOTP's "Simuler : la séance démarre" shortcut, standing
   * in for the tutor-side code entry until that screen exists —
   * CONFIRMED → IN_PROGRESS.
   */
  async startSession(bookingId: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockApprentiBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
          return;
        }
        if (mockApprentiBookings[index].status !== "confirmed") {
          reject(new BookingServiceError("invalid_state", "Cette séance ne peut pas démarrer maintenant."));
          return;
        }
        mockApprentiBookings[index] = {
          ...mockApprentiBookings[index],
          status: "in_progress",
          sessionStartedAt: new Date().toISOString(),
        };
        resolve(mockApprentiBookings[index]);
      }, MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/complete-session
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Response:  Booking (status: "completed", sessionDurationLabel set)
   *   Errors:    404 not_found, 409 invalid_state (booking isn't in_progress)
   *
   * Powers 30_SessionInProgress's "Terminer la séance" —
   * IN_PROGRESS → COMPLETED.
   */
  async completeSession(bookingId: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockApprentiBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
          return;
        }
        const current = mockApprentiBookings[index];
        if (current.status !== "in_progress") {
          reject(new BookingServiceError("invalid_state", "Cette séance n'est pas en cours."));
          return;
        }
        const startedMs = current.sessionStartedAt ? new Date(current.sessionStartedAt).getTime() : Date.now();
        const elapsedMinutes = Math.max(1, Math.round((Date.now() - startedMs) / 60000));
        const hours = Math.floor(elapsedMinutes / 60);
        const minutes = elapsedMinutes % 60;
        const durationLabel = hours > 0 ? `${hours}h${minutes > 0 ? ` ${minutes}min` : ""}` : `${minutes} min`;

        mockApprentiBookings[index] = { ...current, status: "completed", sessionDurationLabel: durationLabel };
        resolve(mockApprentiBookings[index]);
      }, MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /tutors/me/bookings?status=
   *   Auth:      required (Bearer token)
   *   Response:  Booking[]
   *
   * Powers 51_TutorDashboard's stats/preview and 52_TutorRequests' two tabs.
   */
  async getTutorBookings(tutorId: string): Promise<Booking[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockTutorBookings.filter((b) => b.offer.tutorId === tutorId)), MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /bookings/:id
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Response:  Booking
   *   Errors:    404 not_found
   *
   * Powers 53_TutorRequestDetail and 54_TutorRequestAccepted.
   */
  async getTutorBookingById(id: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const booking = mockTutorBookings.find((b) => b.id === id);
        if (booking) resolve(booking);
        else reject(new BookingServiceError("not_found", "Cette demande est introuvable."));
      }, MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/accept
   *   Auth:      required (Bearer token, must be the offer's tutor)
   *   Response:  Booking (status: "confirmed")
   *   Errors:    404 not_found, 409 slot_unavailable (another request for an
   *              overlapping slot was confirmed first — real concurrency
   *              check happens server-side), 500
   *
   * Powers 53_TutorRequestDetail's "Accepter" → 54 (success) / 55 (conflict).
   */
  async acceptBooking(bookingId: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockTutorBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Cette demande est introuvable."));
          return;
        }
        // Mock-only: this specific booking always conflicts on accept, so
        // 55_TutorRequestConflict's 409 state is reliably exercisable. A real
        // backend would decide this from actual concurrent confirmations.
        if (bookingId === "booking-nadia") {
          reject(new BookingServiceError("slot_unavailable", "Ce créneau n'est plus disponible."));
          return;
        }
        mockTutorBookings[index] = { ...mockTutorBookings[index], status: "confirmed" };
        resolve(mockTutorBookings[index]);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/refuse
   *   Auth:      required (Bearer token, must be the offer's tutor)
   *   Response:  Booking (status: "refused")
   *   Errors:    404 not_found, 500
   *
   * Powers 52_TutorRequests / 53_TutorRequestDetail's "Refuser".
   */
  async refuseBooking(bookingId: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockTutorBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Cette demande est introuvable."));
          return;
        }
        mockTutorBookings[index] = { ...mockTutorBookings[index], status: "refused" };
        resolve(mockTutorBookings[index]);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/start-session
   *   Auth:      required (Bearer token, must be the tutor)
   *   Body:      { code: string }
   *   Response:  Booking (status: "in_progress", sessionStartedAt set, sessionMode: "online")
   *   Errors:    404 not_found, 409 invalid_state (booking isn't confirmed), 422 validation_error (wrong code), 500
   *
   * Powers 64_TutorStartSession's code entry — the tutor types the code the
   * beneficiary read out loud, checked against the same computeSessionCode
   * the beneficiary's getSessionCode shows them. CONFIRMED → IN_PROGRESS.
   */
  async startTutorSession(bookingId: string, code: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockTutorBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
          return;
        }
        if (mockTutorBookings[index].status !== "confirmed") {
          reject(new BookingServiceError("invalid_state", "Cette séance ne peut pas démarrer maintenant."));
          return;
        }
        if (code.replace(/\s/g, "") !== computeSessionCode(bookingId).replace(/\s/g, "")) {
          reject(new BookingServiceError("validation_error", "Code incorrect. Vérifiez le code communiqué par le bénéficiaire."));
          return;
        }
        mockTutorBookings[index] = {
          ...mockTutorBookings[index],
          status: "in_progress",
          sessionStartedAt: new Date().toISOString(),
          sessionMode: "online",
        };
        resolve(mockTutorBookings[index]);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/start-session
   *   Auth:      required (Bearer token, must be the tutor)
   *   Body:      { mode: "in_person" } (no code — tutor and beneficiary are physically together)
   *   Response:  Booking (status: "in_progress", sessionStartedAt set, sessionMode: "in_person")
   *   Errors:    404 not_found, 409 invalid_state (booking isn't confirmed), 500
   *
   * Powers 64_TutorStartSession's "Ce cours est en présentiel" shortcut into
   * 67_SessionInProgressPresential. CONFIRMED → IN_PROGRESS, no code check.
   */
  async startTutorPresentialSession(bookingId: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockTutorBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
          return;
        }
        if (mockTutorBookings[index].status !== "confirmed") {
          reject(new BookingServiceError("invalid_state", "Cette séance ne peut pas démarrer maintenant."));
          return;
        }
        mockTutorBookings[index] = {
          ...mockTutorBookings[index],
          status: "in_progress",
          sessionStartedAt: new Date().toISOString(),
          sessionMode: "in_person",
        };
        resolve(mockTutorBookings[index]);
      }, MOCK_LATENCY_MS / 2);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/complete-session
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Response:  Booking (status: "completed", sessionDurationLabel set)
   *   Errors:    404 not_found, 409 invalid_state (booking isn't in_progress)
   *
   * Powers 65_TutorSessionInProgress and 67_SessionInProgressPresential's
   * "Terminer (la séance)" — IN_PROGRESS → COMPLETED.
   */
  async completeTutorSession(bookingId: string): Promise<Booking> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockTutorBookings.findIndex((b) => b.id === bookingId);
        if (index === -1) {
          reject(new BookingServiceError("not_found", "Ce rendez-vous est introuvable."));
          return;
        }
        const current = mockTutorBookings[index];
        if (current.status !== "in_progress") {
          reject(new BookingServiceError("invalid_state", "Cette séance n'est pas en cours."));
          return;
        }
        const startedMs = current.sessionStartedAt ? new Date(current.sessionStartedAt).getTime() : Date.now();
        const elapsedMinutes = Math.max(1, Math.round((Date.now() - startedMs) / 60000));
        const hours = Math.floor(elapsedMinutes / 60);
        const minutes = elapsedMinutes % 60;
        const durationLabel = hours > 0 ? `${hours}h${minutes > 0 ? ` ${minutes}min` : ""}` : `${minutes} min`;

        mockTutorBookings[index] = { ...current, status: "completed", sessionDurationLabel: durationLabel };
        resolve(mockTutorBookings[index]);
      }, MOCK_LATENCY_MS / 2);
    });
  },
};

/** Dev-only helper for 64_TutorStartSession's "Simuler" shortcut — not a real endpoint, just lets the OTP be exercised without a second device/session showing the beneficiary's code. */
export function previewSessionCodeDigits(bookingId: string): string {
  return computeSessionCode(bookingId).replace(/\s/g, "");
}
