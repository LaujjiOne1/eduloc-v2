import type { TutorAvailabilityDraft, TutorAvailabilitySlot } from "@/types/availability";

export class AvailabilityServiceError extends Error {
  code: "not_found";

  constructor(code: "not_found", message: string) {
    super(message);
    this.code = code;
  }
}

const MOCK_LATENCY_MS = 400;

/**
 * Mock open availability for the signed-in tutor — powers 56_TutorCalendar
 * (merged with confirmed bookings, grouped by day) and 57_TutorAvailabilityEdit.
 * Kept mutable in-memory so create/edit/delete feel real within a session —
 * a real backend owns this list.
 */
let mockAvailability: TutorAvailabilitySlot[] = [
  {
    id: "availability-1",
    date: "2026-09-19",
    dateLabel: "Samedi 19 septembre",
    startTime: "16:00",
    endTime: "17:00",
    timeRangeLabel: "16:00 → 17:00",
    format: "in_person",
    locationLabel: "Ankorondrano",
  },
  {
    id: "availability-2",
    date: "2026-09-20",
    dateLabel: "Dimanche 20 septembre",
    startTime: "10:00",
    endTime: "12:00",
    timeRangeLabel: "10:00 → 12:00",
    format: "in_person",
    locationLabel: "Ankorondrano",
  },
];

export const AvailabilityService = {
  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /tutors/me/availability
   *   Auth:      required (Bearer token)
   *   Response:  TutorAvailabilitySlot[]
   *
   * Powers 56_TutorCalendar.
   */
  async getAvailability(): Promise<TutorAvailabilitySlot[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve([...mockAvailability]), MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /availability/:id
   *   Auth:      required (Bearer token, must own the entry)
   *   Response:  TutorAvailabilitySlot
   *   Errors:    404 not_found
   *
   * Powers 57_TutorAvailabilityEdit in edit mode.
   */
  async getAvailabilityById(id: string): Promise<TutorAvailabilitySlot> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const entry = mockAvailability.find((a) => a.id === id);
        if (entry) resolve(entry);
        else reject(new AvailabilityServiceError("not_found", "Cette disponibilité est introuvable."));
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /availability
   *   Auth:      required (Bearer token)
   *   Body:      TutorAvailabilityDraft
   *   Response:  TutorAvailabilitySlot
   *   Errors:    422 validation_error, 500
   *
   * Powers 57_TutorAvailabilityEdit's "Enregistrer" in create mode.
   */
  async createAvailability(data: TutorAvailabilityDraft): Promise<TutorAvailabilitySlot> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const entry: TutorAvailabilitySlot = {
          id: `availability-${Date.now()}`,
          ...data,
          timeRangeLabel: `${data.startTime} → ${data.endTime}`,
        };
        mockAvailability = [...mockAvailability, entry];
        resolve(entry);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   PUT /availability/:id
   *   Auth:      required (Bearer token, must own the entry)
   *   Body:      TutorAvailabilityDraft
   *   Response:  TutorAvailabilitySlot
   *   Errors:    404 not_found, 422 validation_error, 500
   *
   * Powers 57_TutorAvailabilityEdit's "Enregistrer" in edit mode.
   */
  async updateAvailability(id: string, data: TutorAvailabilityDraft): Promise<TutorAvailabilitySlot> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = mockAvailability.findIndex((a) => a.id === id);
        if (index === -1) {
          reject(new AvailabilityServiceError("not_found", "Cette disponibilité est introuvable."));
          return;
        }
        const entry: TutorAvailabilitySlot = {
          id,
          ...data,
          timeRangeLabel: `${data.startTime} → ${data.endTime}`,
        };
        mockAvailability = mockAvailability.map((a) => (a.id === id ? entry : a));
        resolve(entry);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   DELETE /availability/:id
   *   Auth:      required (Bearer token, must own the entry)
   *   Response:  204
   *   Errors:    404 not_found, 500
   *
   * Powers 57_TutorAvailabilityEdit's "Supprimer".
   */
  async deleteAvailability(id: string): Promise<void> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!mockAvailability.some((a) => a.id === id)) {
          reject(new AvailabilityServiceError("not_found", "Cette disponibilité est introuvable."));
          return;
        }
        mockAvailability = mockAvailability.filter((a) => a.id !== id);
        resolve();
      }, MOCK_LATENCY_MS);
    });
  },
};
