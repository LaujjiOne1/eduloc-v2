import type { AppNotification } from "@/types/notification";

/**
 * Backend contract (not yet implemented server-side):
 *
 *   GET /users/me/notifications
 *   Auth:      required (Bearer token)
 *   Response:  AppNotification[]
 *   Errors:    401 unauthorized, 500
 *
 * Powers 33_Notifications. Until the endpoint exists, this returns a fixed
 * mocked feed matching the reference screen's two date groups. Swap the mock
 * body for a real HTTP call here only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 500;

const MOCK_NOTIFICATIONS: AppNotification[] = [
  {
    id: "notif-accepted",
    type: "booking_accepted",
    title: "Demande acceptée",
    message: "Jean a accepté votre demande de Python.",
    timeLabel: "2h",
    dateGroup: "Aujourd'hui",
  },
  {
    id: "notif-message",
    type: "new_message",
    title: "Nouveau vocal",
    message: "Jean vous a envoyé un message.",
    timeLabel: "3h",
    dateGroup: "Aujourd'hui",
  },
  {
    id: "notif-reminder",
    type: "reminder",
    title: "Rappel",
    message: "Votre séance commence demain à 14:00.",
    timeLabel: "5h",
    dateGroup: "Aujourd'hui",
  },
  {
    id: "notif-refused",
    type: "booking_refused",
    title: "Demande refusée",
    message: "Sarah n'est plus disponible sur ce créneau.",
    timeLabel: "Hier",
    dateGroup: "Hier",
  },
];

function mockFetch<T>(data: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(data), MOCK_LATENCY_MS));
}

export const NotificationService = {
  async getMyNotifications(): Promise<AppNotification[]> {
    return mockFetch(MOCK_NOTIFICATIONS);
  },
};
