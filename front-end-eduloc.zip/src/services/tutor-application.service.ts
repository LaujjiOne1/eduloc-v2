import type {
  TutorApplication,
  TutorApplicationSubmission,
  TutorSkill,
} from "@/types/tutor-application";

export class TutorApplicationServiceError extends Error {
  code: "validation_error" | "unauthorized";

  constructor(code: "validation_error" | "unauthorized", message: string) {
    super(message);
    this.code = code;
  }
}

/**
 * Backend contract (not yet implemented server-side):
 *
 *   GET /tutor-applications/skills
 *   Auth:      none (public reference data)
 *   Response:  TutorSkill[]
 *   Errors:    500
 *
 *   POST /tutor-applications
 *   Auth:      required (Bearer token) — applying to become a tutor upgrades
 *              an existing EduLoc account, it doesn't create a new one.
 *   Body:      TutorApplicationSubmission
 *   Response:  TutorApplication (status: "pending" — an EduLoc reviewer must
 *              approve it before the tutor is publicly searchable, per
 *              50_TutorApplicationPending's "vous n'apparaissez pas dans les
 *              résultats de recherche" note)
 *   Errors:    401 unauthorized, 422 validation_error, 500
 *
 * Until these endpoints exist, this returns mocked data so the tutor
 * onboarding screens can be built against the final shape. Swap the mock
 * bodies for real HTTP calls here only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 350;
const MOCK_SUBMIT_LATENCY_MS = 700;

const MOCK_SKILLS: TutorSkill[] = [
  {
    id: "python",
    label: "Python",
    category: "Programmation",
    description: "Apprentissage des bases du langage, structures de données, POO et projets pratiques.",
    scope: "Initiation, perfectionnement, aide aux devoirs et préparation aux projets académiques.",
  },
  {
    id: "algorithmique",
    label: "Algorithmique",
    category: "Informatique fondamentale",
    description: "Complexité temporelle, algorithmes de tri, recherche, graphes et récursivité.",
    scope: "Soutien prépa, licence informatique et concours d'ingénieurs.",
  },
  {
    id: "javascript",
    label: "JavaScript / TypeScript",
    category: "Développement Web",
    description: "Développement web front-end moderne (React/Next), Node.js et écosystème web.",
    scope: "Débutant à avancé, projets concrets et reconversion professionnelle.",
  },
  {
    id: "sql",
    label: "Bases de données & SQL",
    category: "Données",
    description: "Conception relationnelle, requêtes complexes, jointures et modélisation.",
    scope: "BTS, DUT, Université et formation continue.",
  },
  {
    id: "math",
    label: "Mathématiques",
    category: "Sciences exactes",
    description: "Algèbre, analyse, probabilités et géométrie.",
    scope: "Du collège aux classes préparatoires scientifiques et commerciales.",
  },
  {
    id: "finance",
    label: "Finance & Économie",
    category: "Gestion",
    description: "Analyse financière, comptabilité, mathématiques financières et macroéconomie.",
    scope: "Écoles de commerce, IAE, licences éco-gestion et révisions d'examens.",
  },
];

export const TutorApplicationService = {
  async getSkillCatalog(): Promise<TutorSkill[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve(MOCK_SKILLS), MOCK_LATENCY_MS);
    });
  },

  async submitApplication(_submission: TutorApplicationSubmission): Promise<TutorApplication> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: `tutor-application-${Date.now()}`,
          status: "pending",
          submittedAt: new Date().toISOString(),
        });
      }, MOCK_SUBMIT_LATENCY_MS);
    });
  },
};
