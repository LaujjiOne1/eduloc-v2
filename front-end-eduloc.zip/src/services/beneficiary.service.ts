import { CURRENT_BENEFICIARY_ID } from "@/services/booking.service";
import type { CreateBeneficiaryInput, SavedBeneficiary } from "@/types/beneficiary";

export class BeneficiaryServiceError extends Error {
  code: "validation_error";

  constructor(code: "validation_error", message: string) {
    super(message);
    this.code = code;
  }
}

const MOCK_LATENCY_MS = 500;

const UNIVERSITY_LEVEL = { id: "university" as const, label: "Université" };
const HIGH_SCHOOL_LEVEL = { id: "high_school" as const, label: "Lycée" };

/**
 * Mock address book for the signed-in beneficiary (CURRENT_BENEFICIARY_ID,
 * shared with BookingService), kept mutable in-memory so "Ajouter un
 * bénéficiaire" feels real within a session — a real backend owns this list.
 * Seeded with the self entry (no relation/level — "vous") plus the two saved
 * beneficiaries shown on the reference screen.
 */
const mockBeneficiaries: Record<string, SavedBeneficiary[]> = {
  [CURRENT_BENEFICIARY_ID]: [
    { id: "self", firstName: "Tida", lastName: "", isSelf: true, relationLabel: null, level: null },
    {
      id: "beneficiary-thomas",
      firstName: "Thomas",
      lastName: "",
      isSelf: false,
      relationLabel: "Mon fils",
      level: UNIVERSITY_LEVEL,
    },
    {
      id: "beneficiary-nadia",
      firstName: "Nadia",
      lastName: "",
      isSelf: false,
      relationLabel: "Une proche",
      level: HIGH_SCHOOL_LEVEL,
    },
  ],
};

export const BeneficiaryService = {
  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /users/me/beneficiaries
   *   Auth:      required (Bearer token)
   *   Response:  SavedBeneficiary[]
   *
   * Powers 34_Beneficiaries.
   */
  async getMyBeneficiaries(beneficiaryId: string): Promise<SavedBeneficiary[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve([...(mockBeneficiaries[beneficiaryId] ?? [])]), MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /users/me/beneficiaries
   *   Auth:      required (Bearer token)
   *   Body:      CreateBeneficiaryInput
   *   Response:  SavedBeneficiary
   *   Errors:    422 validation_error, 500
   *
   * Powers 34_Beneficiaries' "Ajouter un bénéficiaire" form.
   */
  async createBeneficiary(beneficiaryId: string, input: CreateBeneficiaryInput): Promise<SavedBeneficiary> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const created: SavedBeneficiary = {
          id: `beneficiary-${Date.now()}`,
          firstName: input.firstName,
          lastName: input.lastName,
          isSelf: false,
          relationLabel: input.relationLabel,
          level: input.level,
        };
        mockBeneficiaries[beneficiaryId] = [...(mockBeneficiaries[beneficiaryId] ?? []), created];
        resolve(created);
      }, MOCK_LATENCY_MS);
    });
  },
};
