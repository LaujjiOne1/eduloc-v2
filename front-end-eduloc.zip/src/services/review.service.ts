import type { TutorReviewInput } from "@/types/review";

export class ReviewServiceError extends Error {
  code: "validation_error" | "not_found";

  constructor(code: "validation_error" | "not_found", message: string) {
    super(message);
    this.code = code;
  }
}

const MOCK_LATENCY_MS = 600;

export const ReviewService = {
  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/review
   *   Auth:      required (Bearer token, must be the beneficiary, booking
   *              must be COMPLETED)
   *   Body:      TutorReviewInput
   *   Response:  204 No Content
   *   Errors:    404 not_found, 422 validation_error (rating out of range), 500
   *
   * Powers 32_ReviewTutor's "Envoyer".
   */
  async submitReview(_bookingId: string, input: TutorReviewInput): Promise<void> {
    if (input.rating < 1 || input.rating > 5) {
      throw new ReviewServiceError("validation_error", "Merci de choisir une note.");
    }
    return new Promise((resolve) => {
      setTimeout(resolve, MOCK_LATENCY_MS);
    });
  },
};
