import type { ConversationMessage } from "@/types/message";

export class ConversationServiceError extends Error {
  code: "not_found";

  constructor(code: "not_found", message: string) {
    super(message);
    this.code = code;
  }
}

const MOCK_LATENCY_MS = 500;

/**
 * Mock message threads keyed by booking id — mutable in-memory, like the
 * booking mocks, so sending a voice note or a document feels real within a
 * session. Seeded to match 25_Conversation's own reference bubbles for the
 * one booking that has a conversation going (booking-maths-confirmed keeps
 * an empty thread — nothing has been exchanged yet, exercising the empty state).
 */
const mockConversations: Record<string, ConversationMessage[]> = {
  "booking-python-pending": [
    {
      id: "msg-1",
      bookingId: "booking-python-pending",
      authorLabel: "Jean",
      isMine: false,
      type: "voice",
      durationLabel: "00:37",
      createdAt: "2026-09-17T08:00:00.000Z",
    },
    {
      id: "msg-2",
      bookingId: "booking-python-pending",
      authorLabel: "Vous",
      isMine: true,
      type: "voice",
      durationLabel: "00:42",
      createdAt: "2026-09-17T08:05:00.000Z",
    },
    {
      id: "msg-3",
      bookingId: "booking-python-pending",
      authorLabel: "Jean",
      isMine: false,
      type: "document",
      fileName: "exercice-python.pdf",
      fileSizeLabel: "2.1 Mo",
      createdAt: "2026-09-17T08:10:00.000Z",
    },
  ],
  // Matches 63_TutorConversation.html's own reference bubbles for the tutor's
  // confirmed Thomas/Python appointment (booking-thomas-confirmed).
  "booking-thomas-confirmed": [
    {
      id: "msg-t1",
      bookingId: "booking-thomas-confirmed",
      authorLabel: "Thomas",
      isMine: false,
      type: "voice",
      durationLabel: "00:42",
      createdAt: "2026-09-18T09:00:00.000Z",
    },
    {
      id: "msg-t2",
      bookingId: "booking-thomas-confirmed",
      authorLabel: "Vous",
      isMine: true,
      type: "voice",
      durationLabel: "00:35",
      createdAt: "2026-09-18T09:05:00.000Z",
    },
    {
      id: "msg-t3",
      bookingId: "booking-thomas-confirmed",
      authorLabel: "Vous",
      isMine: true,
      type: "document",
      fileName: "exercice.pdf",
      fileSizeLabel: "1.4 Mo",
      createdAt: "2026-09-18T09:10:00.000Z",
    },
  ],
};

export const ConversationService = {
  /**
   * Backend contract (not yet implemented server-side):
   *
   *   GET /bookings/:id/messages
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Response:  ConversationMessage[]
   *   Errors:    404 not_found
   *
   * Powers 25_Conversation's thread and 27_DocumentExchange's document list
   * (filtered to type "document" by the screen itself).
   */
  async getMessages(bookingId: string): Promise<ConversationMessage[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve([...(mockConversations[bookingId] ?? [])]), MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/messages
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Body:      { type: "voice", durationLabel: string }
   *   Response:  ConversationMessage
   *   Errors:    404 not_found, 422 validation_error, 500
   *
   * Powers 26_VoiceRecording's "Envoyer".
   */
  async sendVoiceMessage(bookingId: string, durationLabel: string): Promise<ConversationMessage> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const message: ConversationMessage = {
          id: `msg-${Date.now()}`,
          bookingId,
          authorLabel: "Vous",
          isMine: true,
          type: "voice",
          durationLabel,
          createdAt: new Date().toISOString(),
        };
        mockConversations[bookingId] = [...(mockConversations[bookingId] ?? []), message];
        resolve(message);
      }, MOCK_LATENCY_MS);
    });
  },

  /**
   * Backend contract (not yet implemented server-side):
   *
   *   POST /bookings/:id/messages
   *   Auth:      required (Bearer token, must be the tutor or beneficiary)
   *   Body:      { type: "document", fileName: string } (multipart upload in practice)
   *   Response:  ConversationMessage
   *   Errors:    404 not_found, 422 validation_error, 500
   *
   * Powers 27_DocumentExchange's "Ajouter un document". No document-picker
   * dependency is installed yet (see AGENTS.md §7) — this mocks the picked
   * file until one is added; screens/hooks won't need to change then.
   */
  async sendDocument(bookingId: string, fileName: string, fileSizeLabel: string): Promise<ConversationMessage> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const message: ConversationMessage = {
          id: `msg-${Date.now()}`,
          bookingId,
          authorLabel: "Vous",
          isMine: true,
          type: "document",
          fileName,
          fileSizeLabel,
          createdAt: new Date().toISOString(),
        };
        mockConversations[bookingId] = [...(mockConversations[bookingId] ?? []), message];
        resolve(message);
      }, MOCK_LATENCY_MS);
    });
  },
};
