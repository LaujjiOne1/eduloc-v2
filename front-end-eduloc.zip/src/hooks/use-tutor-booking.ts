import { useCallback, useEffect, useState } from "react";

import { BookingService, BookingServiceError } from "@/services/booking.service";
import type { Booking } from "@/types/booking";

export type TutorBookingState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; booking: Booking };

/** Loads a single booking request by id for RequestDetail/RequestAccepted. */
export function useTutorBooking(id: string | undefined) {
  const [state, setState] = useState<TutorBookingState>({ status: "loading" });

  const load = useCallback(async () => {
    if (!id) {
      setState({ status: "error", message: "Cette demande est introuvable." });
      return;
    }
    setState({ status: "loading" });
    try {
      const booking = await BookingService.getTutorBookingById(id);
      setState({ status: "success", booking });
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof BookingServiceError ? error.message : "Impossible de charger cette demande.",
      });
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  return { state, retry: load };
}
