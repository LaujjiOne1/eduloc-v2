import { useCallback, useEffect, useState } from "react";

import { NotificationService } from "@/services/notification.service";
import type { AppNotification } from "@/types/notification";

export type MyNotificationsState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "empty" }
  | { status: "success"; notifications: AppNotification[] };

/** Loads the signed-in user's notification feed for 33_Notifications. */
export function useMyNotifications() {
  const [state, setState] = useState<MyNotificationsState>({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const notifications = await NotificationService.getMyNotifications();
      setState(notifications.length > 0 ? { status: "success", notifications } : { status: "empty" });
    } catch {
      setState({ status: "error", message: "Impossible de charger vos notifications." });
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { state, retry: load };
}
