import { useCallback, useEffect, useState } from "react";

import { BookingService, CURRENT_BENEFICIARY_ID } from "@/services/booking.service";
import type { Booking } from "@/types/booking";

export type MyBookingsState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; bookings: Booking[] };

/**
 * Loads the signed-in beneficiary's own bookings — screens derive their own
 * pending/confirmed/history subsets so a single cancel/session action stays
 * consistent everywhere it's reflected (Dashboard preview, MyBookings tabs).
 */
export function useMyBookings() {
  const [state, setState] = useState<MyBookingsState>({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const bookings = await BookingService.getMyBookings(CURRENT_BENEFICIARY_ID);
      setState({ status: "success", bookings });
    } catch {
      setState({ status: "error", message: "Impossible de charger vos rendez-vous." });
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { state, retry: load };
}
