import { useCallback, useState } from "react";

import { OfferService, OfferServiceError } from "@/services/offer.service";
import type { CreateOfferInput, Offer, UpdateOfferInput } from "@/types/offer";

export type OfferActionState =
  | { status: "idle" }
  | { status: "saving" }
  | { status: "togglingStatus" }
  | { status: "error"; message: string };

export type OfferSaveInput =
  | { mode: "create"; tutorId: string; tutorName: string; tutorInitial: string; data: CreateOfferInput }
  | { mode: "edit"; offerId: string; data: UpdateOfferInput };

/** Powers 59_TutorOfferDetail's "Enregistrer" (create or edit) and "Désactiver/Réactiver l'offre". */
export function useOfferActions() {
  const [state, setState] = useState<OfferActionState>({ status: "idle" });

  const save = useCallback(async (input: OfferSaveInput): Promise<Offer | null> => {
    setState({ status: "saving" });
    try {
      const offer =
        input.mode === "create"
          ? await OfferService.createOffer(input.tutorId, input.tutorName, input.tutorInitial, input.data)
          : await OfferService.updateOffer(input.offerId, input.data);
      setState({ status: "idle" });
      return offer;
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof OfferServiceError ? error.message : "Impossible d'enregistrer cette offre.",
      });
      return null;
    }
  }, []);

  const toggleStatus = useCallback(async (offerId: string, isActive: boolean): Promise<Offer | null> => {
    setState({ status: "togglingStatus" });
    try {
      const offer = await OfferService.updateOfferStatus(offerId, isActive);
      setState({ status: "idle" });
      return offer;
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof OfferServiceError ? error.message : "Impossible de mettre à jour cette offre.",
      });
      return null;
    }
  }, []);

  return { state, save, toggleStatus };
}
