import { useCallback, useState } from "react";

import { ConversationService } from "@/services/conversation.service";
import type { ConversationMessage } from "@/types/message";

export type SendMessageState = { status: "idle" } | { status: "sending" } | { status: "error"; message: string };

/** Powers 26_VoiceRecording's "Envoyer" and 27_DocumentExchange's "Ajouter un document". */
export function useSendMessage() {
  const [state, setState] = useState<SendMessageState>({ status: "idle" });

  const sendVoice = useCallback(async (bookingId: string, durationLabel: string): Promise<ConversationMessage | null> => {
    setState({ status: "sending" });
    try {
      const message = await ConversationService.sendVoiceMessage(bookingId, durationLabel);
      setState({ status: "idle" });
      return message;
    } catch {
      setState({ status: "error", message: "Impossible d'envoyer le message vocal. Réessayez." });
      return null;
    }
  }, []);

  const sendDocument = useCallback(
    async (bookingId: string, fileName: string, fileSizeLabel: string): Promise<ConversationMessage | null> => {
      setState({ status: "sending" });
      try {
        const message = await ConversationService.sendDocument(bookingId, fileName, fileSizeLabel);
        setState({ status: "idle" });
        return message;
      } catch {
        setState({ status: "error", message: "Impossible d'envoyer le document. Réessayez." });
        return null;
      }
    },
    [],
  );

  return { state, sendVoice, sendDocument };
}
