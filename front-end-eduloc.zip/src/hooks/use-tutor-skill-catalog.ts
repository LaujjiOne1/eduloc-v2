import { useCallback, useEffect, useState } from "react";

import { TutorApplicationService } from "@/services/tutor-application.service";
import type { TutorSkill } from "@/types/tutor-application";

export type TutorSkillCatalogState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "empty" }
  | { status: "success"; skills: TutorSkill[] };

/** Loads the teachable-skill catalog for the 41_TutorSkills step. */
export function useTutorSkillCatalog() {
  const [state, setState] = useState<TutorSkillCatalogState>({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const skills = await TutorApplicationService.getSkillCatalog();
      setState(skills.length > 0 ? { status: "success", skills } : { status: "empty" });
    } catch {
      setState({ status: "error", message: "Impossible de charger les compétences." });
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { state, retry: load };
}
