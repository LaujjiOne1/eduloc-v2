import { useCallback, useEffect, useState } from "react";

import { BookingService } from "@/services/booking.service";
import { CURRENT_TUTOR_ID } from "@/services/tutor.service";
import type { Booking } from "@/types/booking";

export type TutorBookingsState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; bookings: Booking[] };

/**
 * Loads all of the signed-in tutor's bookings (any status) — screens derive
 * their own pending/confirmed subsets so a single accept/refuse action stays
 * consistent everywhere it's reflected (Dashboard stats, Requests tabs, Calendar).
 */
export function useTutorBookings() {
  const [state, setState] = useState<TutorBookingsState>({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const bookings = await BookingService.getTutorBookings(CURRENT_TUTOR_ID);
      setState({ status: "success", bookings });
    } catch {
      setState({ status: "error", message: "Impossible de charger vos demandes." });
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { state, retry: load };
}
