import { useCallback, useState } from "react";

import { TutorApplicationService, TutorApplicationServiceError } from "@/services/tutor-application.service";
import type { TutorApplication, TutorApplicationSubmission } from "@/types/tutor-application";

export type SubmitTutorApplicationState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; application: TutorApplication };

/** Powers the 49_TutorApplicationSummary screen's "Soumettre mon dossier" submission. */
export function useSubmitTutorApplication() {
  const [state, setState] = useState<SubmitTutorApplicationState>({ status: "idle" });

  const submit = useCallback(async (submission: TutorApplicationSubmission) => {
    setState({ status: "loading" });
    try {
      const application = await TutorApplicationService.submitApplication(submission);
      setState({ status: "success", application });
      return application;
    } catch (error) {
      setState({
        status: "error",
        message:
          error instanceof TutorApplicationServiceError
            ? error.message
            : "Impossible d'envoyer votre dossier. Réessayez.",
      });
      return null;
    }
  }, []);

  return { state, submit };
}
