import { useCallback, useEffect, useState } from "react";

import { ConversationService } from "@/services/conversation.service";
import type { ConversationMessage } from "@/types/message";

export type ConversationMessagesState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; messages: ConversationMessage[] };

/** Loads a booking's message thread — powers 25_Conversation and 27_DocumentExchange (filtered to documents there). */
export function useConversationMessages(bookingId: string | undefined) {
  const [state, setState] = useState<ConversationMessagesState>({ status: "loading" });

  const load = useCallback(async () => {
    if (!bookingId) {
      setState({ status: "error", message: "Cette conversation est introuvable." });
      return;
    }
    setState({ status: "loading" });
    try {
      const messages = await ConversationService.getMessages(bookingId);
      setState({ status: "success", messages });
    } catch {
      setState({ status: "error", message: "Impossible de charger la conversation." });
    }
  }, [bookingId]);

  useEffect(() => {
    load();
  }, [load]);

  return { state, reload: load };
}
