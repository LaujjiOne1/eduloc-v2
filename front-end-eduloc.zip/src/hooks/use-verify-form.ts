import { useCallback, useRef, useState } from "react";

import { AuthService, AuthServiceError } from "@/services/auth.service";

type ResendState = "idle" | "sending" | "sent";

const RESEND_RESET_DELAY_MS = 15_000;

/** Powers the 16_Verify screen: 6-digit code entry, submit, and a spam-guarded resend. */
export function useVerifyForm(email: string, onSuccess: () => void) {
  const [code, setCode] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resendState, setResendState] = useState<ResendState>("idle");
  const resendResetTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const submit = useCallback(async () => {
    if (isSubmitting) return;
    setFormError(null);
    if (!/^\d{6}$/.test(code)) {
      setFormError("Entrez les 6 chiffres du code.");
      return;
    }

    setIsSubmitting(true);
    try {
      await AuthService.verifyEmail({ email, code });
      onSuccess();
    } catch (error) {
      setFormError(
        error instanceof AuthServiceError ? error.message : "Une erreur est survenue. Réessayez.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }, [code, email, isSubmitting, onSuccess]);

  const resend = useCallback(async () => {
    if (resendState !== "idle") return;
    setFormError(null);
    setResendState("sending");
    try {
      await AuthService.resendVerificationCode({ email });
      setResendState("sent");
      resendResetTimer.current = setTimeout(() => setResendState("idle"), RESEND_RESET_DELAY_MS);
    } catch (error) {
      setResendState("idle");
      setFormError(
        error instanceof AuthServiceError ? error.message : "Impossible de renvoyer le code.",
      );
    }
  }, [email, resendState]);

  return {
    code,
    setCode,
    formError,
    isSubmitting,
    submit,
    resend,
    resendState,
    canSubmit: /^\d{6}$/.test(code) && !isSubmitting,
  };
}
