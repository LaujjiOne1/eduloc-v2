import { useCallback, useEffect, useState } from "react";

import { BookingService, BookingServiceError } from "@/services/booking.service";
import type { Booking } from "@/types/booking";

export type MyBookingState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "success"; booking: Booking };

/** Loads a single one of the signed-in beneficiary's bookings by id — 23/24 and the whole conversation/session sub-flow. */
export function useMyBooking(id: string | undefined) {
  const [state, setState] = useState<MyBookingState>({ status: "loading" });

  const load = useCallback(async () => {
    if (!id) {
      setState({ status: "error", message: "Ce rendez-vous est introuvable." });
      return;
    }
    setState({ status: "loading" });
    try {
      const booking = await BookingService.getMyBookingById(id);
      setState({ status: "success", booking });
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof BookingServiceError ? error.message : "Impossible de charger ce rendez-vous.",
      });
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  return { state, retry: load };
}
