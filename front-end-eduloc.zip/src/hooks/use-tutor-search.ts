import { useCallback, useEffect, useState } from "react";

import { TutorService } from "@/services/tutor.service";
import type { SearchCriteria } from "@/types/search";
import type { Tutor } from "@/types/tutor";

export type TutorsState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "empty" }
  | { status: "success"; tutors: Tutor[] };

/** Loads tutors matching the wizard's search criteria for the Results / ResultsMap steps. */
export function useTutorSearch(criteria: SearchCriteria) {
  const [state, setState] = useState<TutorsState>({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const tutors = await TutorService.searchTutors(criteria);
      setState(tutors.length > 0 ? { status: "success", tutors } : { status: "empty" });
    } catch {
      setState({ status: "error", message: "Impossible de charger les tuteurs." });
    }
  }, [criteria]);

  useEffect(() => {
    load();
  }, [load]);

  return { state, retry: load };
}
