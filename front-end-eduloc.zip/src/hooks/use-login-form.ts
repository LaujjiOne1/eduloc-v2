import { useCallback, useState } from "react";

import { AuthService, AuthServiceError } from "@/services/auth.service";
import type { AuthenticatedUser, OAuthProvider } from "@/types/auth";

type FieldErrors = Partial<Record<"email" | "password", string>>;

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function useLoginForm(onSuccess: (user: AuthenticatedUser) => void) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [providerPending, setProviderPending] = useState<OAuthProvider | null>(null);

  const validate = useCallback(() => {
    const errors: FieldErrors = {};
    if (!email.trim()) errors.email = "L'email est requis.";
    else if (!EMAIL_REGEX.test(email.trim())) errors.email = "Format d'email invalide.";
    if (!password) errors.password = "Le mot de passe est requis.";
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }, [email, password]);

  const submit = useCallback(async () => {
    if (isSubmitting || providerPending) return;
    setFormError(null);
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      const user = await AuthService.login({ email: email.trim(), password });
      onSuccess(user);
    } catch (error) {
      setFormError(
        error instanceof AuthServiceError ? error.message : "Une erreur est survenue. Réessayez.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }, [email, password, isSubmitting, providerPending, validate, onSuccess]);

  const continueWithProvider = useCallback(
    async (provider: OAuthProvider) => {
      if (isSubmitting || providerPending) return;
      setFormError(null);
      setProviderPending(provider);
      try {
        const user = await AuthService.loginWithProvider(provider);
        onSuccess(user);
      } catch (error) {
        setFormError(
          error instanceof AuthServiceError ? error.message : "Une erreur est survenue. Réessayez.",
        );
      } finally {
        setProviderPending(null);
      }
    },
    [isSubmitting, providerPending, onSuccess],
  );

  return {
    email,
    setEmail,
    password,
    setPassword,
    fieldErrors,
    formError,
    isSubmitting,
    providerPending,
    submit,
    continueWithProvider,
    canSubmit: email.trim().length > 0 && password.length > 0 && !isSubmitting && !providerPending,
  };
}
