import { useCallback, useState } from "react";

import { BookingService, BookingServiceError } from "@/services/booking.service";
import type { Booking } from "@/types/booking";

export type SessionActionState = { status: "idle" } | { status: "starting" } | { status: "completing" } | { status: "error"; message: string };

/**
 * Powers the session state transitions reachable from this screen group:
 * 29_SessionOTP's "Simuler : la séance démarre" (CONFIRMED → IN_PROGRESS) and
 * 30_SessionInProgress's "Terminer la séance" (IN_PROGRESS → COMPLETED).
 */
export function useSessionAction() {
  const [state, setState] = useState<SessionActionState>({ status: "idle" });

  const start = useCallback(async (bookingId: string): Promise<Booking | null> => {
    setState({ status: "starting" });
    try {
      const booking = await BookingService.startSession(bookingId);
      setState({ status: "idle" });
      return booking;
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof BookingServiceError ? error.message : "Impossible de démarrer la séance.",
      });
      return null;
    }
  }, []);

  const complete = useCallback(async (bookingId: string): Promise<Booking | null> => {
    setState({ status: "completing" });
    try {
      const booking = await BookingService.completeSession(bookingId);
      setState({ status: "idle" });
      return booking;
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof BookingServiceError ? error.message : "Impossible de terminer la séance.",
      });
      return null;
    }
  }, []);

  return { state, start, complete };
}
